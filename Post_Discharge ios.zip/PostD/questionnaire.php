<?php
$response = array(); // Initialize a response array

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    $id = $_POST["id"];
    $category = "";
    $text1 = $_POST["text1"];
    $text2 = $_POST["text2"];
    $text3 = $_POST["text3"];
    $text4 = $_POST["text4"];
    $text5 = $_POST["text5"];
    $text6 = $_POST["text6"];
    $text7 = $_POST["text7"];
    $text8 = $_POST["text8"];
    $text9 = $_POST["text9"];
    $text10 = $_POST["text10"];
    $text11 = $_POST["text11"];

    // Establish a connection to the database
    $conn = new mysqli("localhost", "root", "", "post");

    if ($conn->connect_error) {
        $response["status"] = "error";
        $response["message"] = "Connection failed: " . $conn->connect_error;
        $conn->close();
    } else {
        // Delete existing data for the given id
        $delete_query = "DELETE FROM questionnaire_doc WHERE id = '$id'";
        $conn->query($delete_query);

        for ($i = 1; $i <= 11; $i++) {
            if ($i >= 1 && $i <= 5) {
                $category = "General Symptoms";
            } else {
                $category = "Danger Symptoms";
            }
            // Insert new data
            $insert_query = "INSERT INTO questionnaire_doc (id, Question_category, Question) 
                             VALUES ('$id', '$category', '" . $_POST["text$i"] . "')";
            $conn->query($insert_query);
        }
        $response["status"] = "success";
        $response["message"] = "Data inserted successfully";
    }
} else {
    $response["status"] = "error";
    $response["message"] = "Invalid request method";
}
// Encode the response array to JSON and echo it
header('Content-Type: application/json; charset=UTF-8');
echo json_encode($response);
?>
