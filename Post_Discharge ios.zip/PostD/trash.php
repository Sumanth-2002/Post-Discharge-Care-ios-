<?php
require("conn.php");

$response = array();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve data from POST request
    $id = $_POST["id"];
    $name = $_POST["name"];
    $gender = $_POST["Gender"];
    $department = $_POST["Department"];
    $consultant = $_POST["Consultant"];
    $address = $_POST["Address"];
    $Doa = $_POST["Date_Of_Admission"];
    $Dod = $_POST["Date_Of_Discharge"];
    $diagnosis = $_POST["Diagnosis"];
    $chief = $_POST["Chief_Complaints"];
    $hipo = $_POST["History_of_present_illness"];
    $ph = $_POST["Past_History"];
    $ah = $_POST["Antennal_history"];
    $nh = $_POST["Natal_History"];
    $pn = $_POST["PostNatal_History"];
    $gm = $_POST["Gross_Motor"];
    $fm = $_POST["Fine_Motor"];
    $lan = $_POST["Language"];
    $sac = $_POST["Social_and_Congnitiont"];
    $ih = $_POST["Immunization_history"];
    $ant = $_POST["Anthropometry"];
    $weight = $_POST["Weight"];
    $height = $_POST["Height"];
    $heart_rate = $_POST["Heart_rate"];
    $temp = $_POST["Temperature"];
    $crt = $_POST["crt"];
    $rr = $_POST["rr"];
    $spo2 = $_POST["spo2"];
    $hte = $_POST["Head_to_Toe_Examination"];
    $ge = $_POST["General_Examination"];
    $se = $_POST["Systematic_Examination"];
    $Tg = $_POST["Treatment_Given"];
    $hsp = $_POST["Course_in_Hospital"];
    $picu = $_POST["Course_in_Picu"];
    $ward = $_POST["Course_in_ward"];
    $ad = $_POST["Advice_on_Discharge"];
    $review = $_POST["Review"];

   
    $deleteQueries = array(
        "DELETE FROM discharge_summary WHERE id = '$id'",
        "DELETE FROM chief_complaints WHERE id = '$id'",
        "DELETE FROM history_illness WHERE id = '$id'",
        "DELETE FROM development_history WHERE id = '$id'",
        "DELETE FROM immunization_history WHERE id = '$id'",
        "DELETE FROM vitals_at_admission WHERE id = '$id'",
        "DELETE FROM treatment WHERE id = '$id'",
        "DELETE FROM course_dis WHERE id = '$id'"
    );

    // Execute delete queries
    foreach ($deleteQueries as $deleteQuery) {
        if ($conn->query($deleteQuery) === TRUE) {
            // Deletion successful
        } else {
            $response["status"] = "error";
            $response["message"] = "Error deleting record: " . $conn->error;
            echo json_encode($response);
            exit(); // Terminate script execution
        }
    }

    $chiefQuery = "INSERT INTO chief_complaints (id, chief_complaints)
    VALUES (?, ?)
    ON DUPLICATE KEY UPDATE chief_complaints=?";
    $stmtChief = $conn->prepare($chiefQuery);
    $stmtChief->bind_param("sss", $id, $chief, $chief);
    if ($stmtChief->execute()) {
    $response["chief_status"] = "success";
    $response["chief_message"] = "Chief complaints updated successfully";
    } else {
    $response["chief_status"] = "error";
    $response["chief_message"] = "Error updating chief complaints: " . $stmtChief->error;
    }

    // Continue updating or inserting other data...

    // Close the prepared statements
    $stmtChief->close();

    $historyQuery = "INSERT INTO history_illness (id, Illness, Past_history, Antennal_history, Natal_history, Postnatal_history)
                     VALUES (?, ?, ?, ?, ?, ?)
                     ON DUPLICATE KEY UPDATE Illness=?, Past_history=?, Antennal_history=?, Natal_history=?, Postnatal_history=?";
    $stmtHistory = $conn->prepare($historyQuery);
    $stmtHistory->bind_param("sssssssssss", $id, $hipo, $ph, $ah, $nh, $pn, $hipo, $ph, $ah, $nh, $pn);
    if ($stmtHistory->execute()) {
        $response["history_status"] = "success";
        $response["history_message"] = "History of illness updated successfully";
    } else {
        $response["history_status"] = "error";
        $response["history_message"] = "Error updating history of illness: " . $stmtHistory->error;
    }

    // Continue updating or inserting other data...

    // Close the prepared statements
    $stmtHistory->close();

    $developmentQuery = "INSERT INTO development_history (id, Gross_Motor, Fine_Motor, Language, Social_and_Cognition)
                         VALUES (?, ?, ?, ?, ?)
                         ON DUPLICATE KEY UPDATE Gross_Motor=?, Fine_Motor=?, Language=?, Social_and_Cognition=?";
    $stmtDevelopment = $conn->prepare($developmentQuery);
    $stmtDevelopment->bind_param("sssssssss", $id, $gm, $fm, $lan, $sac, $gm, $fm, $lan, $sac);
    if ($stmtDevelopment->execute()) {
        $response["development_status"] = "success";
        $response["development_message"] = "Development history updated successfully";
    } else {
        $response["development_status"] = "error";
        $response["development_message"] = "Error updating development history: " . $stmtDevelopment->error;
    }
    $stmtDevelopment->close();

    $immunizationQuery = "INSERT INTO immunization_history (id, history, Anthropometry, weightt, height)
                          VALUES (?, ?, ?, ?, ?)
                          ON DUPLICATE KEY UPDATE history=?, Anthropometry=?, weightt=?, height=?";
    $stmtImmunization = $conn->prepare($immunizationQuery);
    $stmtImmunization->bind_param("sssssssss", $id, $ih, $ant, $weight, $height, $ih, $ant, $weight, $height);
    if ($stmtImmunization->execute()) {
        $response["immunization_status"] = "success";
        $response["immunization_message"] = "Immunization history updated successfully";
    } else {
        $response["immunization_status"] = "error";
        $response["immunization_message"] = "Error updating immunization history: " . $stmtImmunization->error;
    }
    $stmtImmunization->close();

        $vitalsQuery = "INSERT INTO vitals_at_admission (id, Heart_rate, Temperature, CRT, RR, SPO2)
        VALUES (?, ?, ?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE Heart_rate=?, Temperature=?, CRT=?, RR=?, SPO2=?";
    $stmtVitals = $conn->prepare($vitalsQuery);
    $stmtVitals->bind_param("sssssssssss", $id, $heart_rate, $temp, $crt, $rr, $spo2, $heart_rate, $temp, $crt, $rr, $spo2);
    if ($stmtVitals->execute()) {
    $response["vitals_status"] = "success";
    $response["vitals_message"] = "Vitals at admission updated successfully";
    } else {
    $response["vitals_status"] = "error";
    $response["vitals_message"] = "Error updating vitals at admission: " . $stmtVitals->error;
    }
    $stmtVitals->close();

    $treatmentQuery = "INSERT INTO treatment (id, Head_to_toe_examination, General_Examination, Systematic_Examination, Treatment_given)
                    VALUES (?, ?, ?, ?, ?)
                    ON DUPLICATE KEY UPDATE Head_to_toe_examination=?, General_Examination=?, Systematic_Examination=?, Treatment_given=?";
    $stmtTreatment = $conn->prepare($treatmentQuery);
    $stmtTreatment->bind_param("sssssssss", $id, $hte, $ge, $se, $Tg, $hte, $ge, $se, $Tg);
    if ($stmtTreatment->execute()) {
        $response["treatment_status"] = "success";
        $response["treatment_message"] = "Treatment data updated successfully";
    } else {
        $response["treatment_status"] = "error";
        $response["treatment_message"] = "Error updating treatment data: " . $stmtTreatment->error;
    }

    // Update or insert course data
    $courseQuery = "INSERT INTO course_dis (id, Course_in_Hospital, Course_in_PICU, Course_in_Ward, Advice_on_Discharge, Review)
                    VALUES (?, ?, ?, ?, ?, ?)
                    ON DUPLICATE KEY UPDATE Course_in_Hospital=?, Course_in_PICU=?, Course_in_Ward=?, Advice_on_Discharge=?, Review=?";
    $stmtCourse = $conn->prepare($courseQuery);
    $stmtCourse->bind_param("sssssssssss", $id, $hsp, $picu, $ward, $ad, $review, $hsp, $picu, $ward, $ad, $review);
    if ($stmtCourse->execute()) {
        $response["course_status"] = "success";
        $response["course_message"] = "Course data updated successfully";
    } else {
        $response["course_status"] = "error";
        $response["course_message"] = "Error updating course data: " . $stmtCourse->error;
    }

// Close the prepared statements
    $stmtTreatment->close();
    $stmtCourse->close();
    $conn->close();

} else {
    $response["status"] = "error";
    $response["message"] = "Invalid request method";
}


// Encode the response array to JSON and echo it
header('Content-Type: application/json; charset=UTF-8');
echo json_encode($response);
?>
