<?php
$conn = new mysqli("localhost", "root", "", "post");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$response = array();
$sql = "SELECT id, Name, Gender, Contact_No, Profile_Pic FROM patient_details";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $response["status"] = "success";
    $response["message"] = "Data retrieved successfully";
    $response['data'] = array();

    while ($row = $result->fetch_assoc()) {
        $imagePath = $row["Profile_Pic"];
        $data = array(
            "id" => strval($row["id"]),
            "Name" => $row["Name"],
            "Gender" => $row["Gender"],
            "Contact_No" => strval($row["Contact_No"]),
        );

        if (!empty($imagePath) && file_exists($imagePath)) {
            $data["patient_img"] = base64_encode(file_get_contents($imagePath));
        } else {
            error_log("Image not found or invalid path for ID: " . $row["id"]);
            $data["patient_img"] = "";
        }
        array_push($response['data'], $data);
    }
} else {
    $response["status"] = "error";
    $response["message"] = "No results found";
}

$conn->close();

echo json_encode($response);
?>
