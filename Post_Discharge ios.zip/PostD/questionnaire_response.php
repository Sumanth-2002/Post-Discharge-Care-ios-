<?php
$response = array(); // Initialize a response array

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    
    
    // Establish a connection to the database
    $conn = new mysqli("localhost", "root", "", "post");
    $id = $_POST["id"];
    $currentDate = $_POST["Date"];

    if ($conn->connect_error) {
        $response["status"] = "error";
        $response["message"] = "Connection failed: " . $conn->connect_error;
        $conn->close();
    } else {
        for ($i = 1; $i <= 11; $i++) {
            $symptom = $conn->real_escape_string($_POST["text$i"]);
            $responseValue = $conn->real_escape_string($_POST["r$i"]);

            $sql = "INSERT INTO questionnaire_response (id, date, symptom, response) 
                    VALUES ('$id', '$currentDate', '$symptom', '$responseValue')";

            if ($conn->query($sql) === TRUE) {
                $response["status"] = "success";
                $response["message"] = "Data inserted successfully";
            } else {
                $response["status"] = "error";
                $response["message"] = "Error: " . $sql . "<br>" . $conn->error;
            }
        }
        $conn->close();
    }
} else {
    $response["status"] = "error";
    $response["message"] = "Invalid request method";
}

// Encode the response array to JSON and echo it
header('Content-Type: application/json; charset=UTF-8');
echo json_encode($response);
?>
