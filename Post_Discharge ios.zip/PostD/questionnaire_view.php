<?php
require("conn.php");

$response = array();

// Check if ID is sent via POST
if(isset($_POST['id'])) {
    $id = $_POST['id'];

    // Query to select data based on id
    $query = "SELECT Question FROM questionnaire_doc WHERE id = $id";
    
    $result = mysqli_query($conn, $query);

    // Initialize an array to store the fetched questions
    $questions = array();

    if($result) {
        // Fetch associative array
        while ($row = mysqli_fetch_assoc($result)) {
            // Store fetched question into the array
            $questions[] = $row['Question'];
        }
        
        $response['status'] = 'success';
        $response['message'] = 'Data retrieved successfully';
        $response['questions'] = $questions;
    } else {
        // If query fails, return an error message
        $response['status'] = 'error';
        $response['message'] = 'Query failed';
    }
} else {
    // If id is not sent via POST, return an error message
    $response['status'] = 'error';
    $response['message'] = 'ID not provided';
}

// Return the response as JSON
header('Content-Type: application/json');
echo json_encode($response);
?>
