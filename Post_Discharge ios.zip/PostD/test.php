<?php
require("conn.php");

$response = array();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $images = $_FILES["images"];
    $id = $_POST["id"];
    // Other POST parameters...

    // Function to upload images and return their paths
    function uploadImages($fieldName) {
        $targetDirectory = "uploads/";
        $uploadedPaths = array();

        // Check if the field name exists and if it's an array
        if (isset($_FILES[$fieldName]) && is_array($_FILES[$fieldName]["name"])) {
            foreach ($_FILES[$fieldName]["name"] as $key => $value) {
                $targetFile = $targetDirectory . basename($_FILES[$fieldName]["name"][$key]);
                if (move_uploaded_file($_FILES[$fieldName]["tmp_name"][$key], $targetFile)) {
                    $uploadedPaths[] = $targetFile;
                } else {
                    $uploadedPaths[] = null;
                }
            }
        } elseif (isset($_FILES[$fieldName])) {
            // If there's only one file, treat it as an array
            $targetFile = $targetDirectory . basename($_FILES[$fieldName]["name"]);
            if (move_uploaded_file($_FILES[$fieldName]["tmp_name"], $targetFile)) {
                $uploadedPaths[] = $targetFile;
            } else {
                $uploadedPaths[] = null;
            }
        }

        return $uploadedPaths;
    }

    // Upload images
    $uploadedImagePaths = uploadImages("images");

    // Check if any images were uploaded successfully
    if (!empty($uploadedImagePaths)) {
        // Handle image paths and database operations
        // For simplicity, assuming only one image is uploaded in this example
        $imagePath = $uploadedImagePaths[0];

        // SQL query to insert or update image path
        $q1 = "SELECT * FROM dis_image WHERE patient_id='$id'";
        $result1 = mysqli_query($conn, $q1);
        if (mysqli_num_rows($result1) == 0) {
            // Insert image path
            $insertQuery = "INSERT INTO dis_image (patient_id, image) VALUES (?, ?)";
            $stmt = $conn->prepare($insertQuery);
            $stmt->bind_param("ss", $id, $imagePath);
            $stmt->execute();
            $stmt->close();
        } else {
            // Update image path
            $updateQuery = "UPDATE dis_image SET image=? WHERE patient_id=?";
            $stmt = $conn->prepare($updateQuery);
            $stmt->bind_param("ss", $imagePath, $id);
            $stmt->execute();
            $stmt->close();
        }

        // Other database operations...
        
        $response["status"] = "success";
        $response["message"] = "Data inserted successfully";
    } else {
        // No images uploaded or upload failed
        $response["status"] = "error";
        $response["message"] = "Image upload failed";
    }
} else {
    $response["status"] = "error";
    $response["message"] = "Invalid request method";
}

// Encode the response array to JSON and echo it
header('Content-Type: application/json; charset=UTF-8');
echo json_encode($response);
?>
