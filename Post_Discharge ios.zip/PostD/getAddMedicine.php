<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Connect to the database
    $conn = new mysqli("localhost", "root", "", "post");
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $id = $conn->real_escape_string($_POST['id']);
    // Use prepared statement to prevent SQL injection
    $sql = "SELECT * FROM medicine WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $id);  // Use "s" for a string parameter
    $stmt->execute();
    $result = $stmt->get_result();
    $response = array();

    if ($result->num_rows > 0) {
        $response["status"] = "success";
        $response["message"] = "Patient information ";
        
        // Fetch rows and add them to the 'data' key in the response array
        $response["data"] = array();
        while ($row = $result->fetch_assoc()) {
            $response["data"][] = $row;
        }
    } else {
        $response["status"] = "error";
        $response["message"] = "No records found.";
    }
    $stmt->close();
    $conn->close();
    echo json_encode($response);
} else {
    echo json_encode(array("status" => "error", "message" => "Invalid request."));
}
?>
