<?php
// Include your database connection file
require "conn.php";

// Initialize response array
$response = array();

// Check if the POST parameter 'id' is set
if (isset($_POST['id'])) {
    $id = $_POST['id'];

    // Prepare and execute the query
    $query = "SELECT Name, Gender, Department, Experience, Contact_Number, doc_profile FROM doctor_login WHERE id = $id";
    $result = mysqli_query($conn, $query);

    // Check for errors
    if (!$result) {
        $response['status'] = 'error';
        $response['message'] = 'Error: ' . mysqli_error($conn);
    } else {
        // Fetch data as an associative array
        $data = mysqli_fetch_assoc($result);

        // Close the database connection
        mysqli_close($conn);

        // Check if data was found
        if ($data) {
            // Convert image to byte string (base64-encoded)
            $imagePath = $data['doc_profile'];
            $imageData = base64_encode(file_get_contents($imagePath));

            // Add the image data to the $data array
            $data['doc_profile'] = $imageData;

            // Set status and message for success
            $response['status'] = 'success';
            $response['message'] = 'Data found';
            $response['data'] = array($data);
        } else {
            // Set status and message for no data found
            $response['status'] = 'error';
            $response['message'] = 'No data found for the given ID';
        }
    }
} else {
    // If 'id' is not set in the POST parameters
    $response['status'] = 'error';
    $response['message'] = 'ID parameter not set.';
}

// Return response in JSON format
echo json_encode($response, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
?>
