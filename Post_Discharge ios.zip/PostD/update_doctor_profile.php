<?php
// Include your database connection file
require "conn.php";

$response = array();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $targetDirectory = "uploads/";
    function uploadImages($fieldName) {
        global $targetDirectory;
        $result = [];
        // Check if the field name exists and if it's an array
        if (isset($_FILES[$fieldName]) && is_array($_FILES[$fieldName]["name"])) {
            foreach ($_FILES[$fieldName]["name"] as $key => $value) {
                $targetFile = $targetDirectory . basename($_FILES[$fieldName]["name"][$key]);
                if (move_uploaded_file($_FILES[$fieldName]["tmp_name"][$key], $targetFile)) {
                    $result[] = $targetFile;
                } else {
                    $result[] = null;
                }
            }
        } elseif (isset($_FILES[$fieldName])) {
            // If there's only one file, treat it as an array
            $targetFile = $targetDirectory . basename($_FILES[$fieldName]["name"]);
            if (move_uploaded_file($_FILES[$fieldName]["tmp_name"], $targetFile)) {
                $result[] = $targetFile;
            } else {
                $result[] = null;
            }
        }
        return $result;
    }
    // Retrieve form data
    $id = isset($_POST["id"]) ? $_POST["id"] : null;
    $name = isset($_POST["name"]) ? $_POST["name"] : null;
    $gender = isset($_POST["gender"]) ? $_POST["gender"] : null;
    $department = isset($_POST["department"]) ? $_POST["department"] : null;
    $experience = isset($_POST["experience"]) ? $_POST["experience"] : null;
    $contact = isset($_POST["contact"]) ? $_POST["contact"] : null;

    // Establish a connection to the database
    $conn = new mysqli("localhost", "root", "", "post");

    if ($conn->connect_error) {
        $response["status"] = "error";
        $response["message"] = "Connection failed: " . $conn->connect_error;
    } else {
        // Retrieve existing details if available
        $sqlSelect = "SELECT * FROM doctor_login WHERE id = $id";
        $resultSelect = $conn->query($sqlSelect);

        if ($resultSelect->num_rows > 0) {
            while ($row = $resultSelect->fetch_assoc()) {
                // Use existing details for fields not provided in the form
                if (empty($name)) {
                    $name = $row["Name"];
                }
                if (empty($department)) {
                    $department = $row["Department"];
                }
                if (empty($gender)) {
                    $gender = $row["Gender"];
                }
                if (empty($experience)) {
                    $experience = $row["Experience"];
                }
                if (empty($contact)) {
                    $contact = $row["Contact_Number"];
                }
            }
        }

        // Prepare and execute the update query
        $sqlUpdate = "UPDATE doctor_login SET 
            Name = '$name', 
            Department = '$department', 
            Gender = '$gender', 
            Experience = '$experience', 
            Contact_Number = '$contact'";

        // Append Image path to the query if available
        if (isset($_FILES["profile_pic"])) {
            $imagePath = uploadImages("profile_pic");
            if (!empty($imagePath[0])) {
                $sqlUpdate .= ", doc_profile = '" . $imagePath[0] . "'";
            }
        }

        $sqlUpdate .= " WHERE id = $id";

        $update = $conn->query($sqlUpdate);

        if ($update) {
            $response["status"] = "success";
            $response["message"] = "Data updated successfully";
        } else {
            $response["status"] = "error";
            $response["message"] = "Error: " . $sqlUpdate . "<br>" . $conn->error;
        }

        // Close the connection
        $conn->close();
    }
} else {
    $response["status"] = "error";
    $response["message"] = "Invalid request method";
}

// Encode the response array to JSON and echo it
echo json_encode($response);

// Function to upload images

?>
