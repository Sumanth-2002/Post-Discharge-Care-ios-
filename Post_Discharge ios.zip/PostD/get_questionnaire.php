<?php
require("conn.php");

if (!empty($_POST['id'])) {
    $id = intval($_POST['id']);

    $sql = "SELECT Question_Category, Question FROM questionnaire_doc WHERE id = ? ORDER BY Question_Category DESC";
    
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "i", $id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if ($result) {
        $response = array();

        while ($row = mysqli_fetch_assoc($result)) {
            $category = $row['Question_Category'];
            
            // Check if the category array already exists, if not, create it
            if (!array_key_exists($category, $response)) {
                $response[$category] = array();
            }

            // Append each row to the corresponding category array
            $response[$category][] = $row['Question'];
        }

        // Construct the final response array
        $finalResponse = array(
            'status' => 'success',
            'message' => 'Data found',
            'data' => $response
        );

        // Return JSON response with records separated by Question_Category
        header('Content-Type: application/json');
        echo json_encode($finalResponse);
    } else {
        echo json_encode(array('status' => 'error', 'message' => 'Patient not found for the given ID'));
    }
} else {
    echo json_encode(array('status' => 'error', 'message' => 'Failed to fetch patient details'));
}

mysqli_close($conn);
?>
