<?php
session_start();
$conn=mysqli_connect("localhost","root","");
mysqli_select_db($conn,"img");

  if(isset($_GET['add']))
   {
   
	   
	   if($_FILES['upload'])
	    {
			$on=$_FILES['upload']['name'];
			$sn=$_FILES['upload']['tmp_name'];			
			$dn="images/".$on;
			move_uploaded_file($sn,$dn);s
			
			$qry="INSERT INTO image (image_insertion)
			      VALUES ('$on')";
			$res=mysqli_query($conn,$qry);
			
			if($res==true)
			 $_SESSION['msg']="File Uploaded Successfully";
			else
			 $_SESSION['msg']="Could not upload File";
			 
			 header("location:".$_SERVER['PHP_SELF']);
			 exit();
			 
		}
   }

?>