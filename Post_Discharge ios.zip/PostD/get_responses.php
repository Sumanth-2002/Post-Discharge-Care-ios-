<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Connect to the database
    $conn = new mysqli("localhost", "root", "", "post");
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $id = $_POST["id"];
    $startDate = $_POST["startDate"];
    $endDate = $_POST["endDate"];

    // Use prepared statement for security
    $sql = "SELECT * FROM questionnaire_response WHERE id = ? AND date BETWEEN ? AND ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sss", $id, $startDate, $endDate);
    $stmt->execute();
    $result = $stmt->get_result();

    $response = array();

    if ($result) {
        // Fetch the data and store in an array
        $segregated_data = array();

        while ($row = $result->fetch_assoc()) {
            $date = $row['date'];
            $symptom = $row['symptom'];
            $responseValue = $row['response'];

            // Add extracted values with date as the key
            $segregated_data[$date][] = array(
                "symptom" => $symptom,
                "response" => $responseValue
            );
        }

        $data = array();
        foreach ($segregated_data as $date => $symptoms) {
            $data[] = array(
                "date" => $date,
                "resp" => $symptoms
            );
        }

        $response["status"] = "success";
        $response["message"] = "Patient data retrieved successfully.";
        $response["data"] = $data;
    } else {
        $response["status"] = "error";
        $response["message"] = "Error: " . $stmt->error; // Use prepared statement error
    }

    $stmt->close();
    $conn->close();
    echo json_encode($response);
} else {
    echo json_encode(array("status" => "error", "message" => "Invalid request."));
}
?>