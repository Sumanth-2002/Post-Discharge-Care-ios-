<?php
$response = array();
$conn = new mysqli("localhost", "root", "", "post");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve patient ID from the POST request
    $patientId = $_POST["id"];

    $response['status'] = "success";
    $response['message'] = "Data found";

    $response['id'] = $patientId;
    $sql1 = "select * from chief_complaints where id = $patientId";
    $stmt1 = mysqli_prepare($conn, $sql1);
    mysqli_stmt_execute($stmt1);
    $result1 = mysqli_stmt_get_result($stmt1);
    if ($result1->num_rows > 0) {
        $response['data']['chief_complaints'] = $result1->fetch_assoc();
    }

    $sql2 = "select * from vitals_at_admission where id = $patientId";
    $stmt2 = mysqli_prepare($conn, $sql2);
    mysqli_stmt_execute($stmt2);
    $result2 = mysqli_stmt_get_result($stmt2);
    if ($result2->num_rows > 0) {
        $response['data']['vitals_at_admission'] = $result2->fetch_assoc();
    }

    $sql3 = "select * from immunization_history where id = $patientId";
    $stmt3 = mysqli_prepare($conn, $sql3);
    mysqli_stmt_execute($stmt3);
    $result3 = mysqli_stmt_get_result($stmt3);
    if ($result3->num_rows > 0) {
        $response['data']['immunization_history'] = $result3->fetch_assoc();
    }

    $sql4 = "select * from development_history where id = $patientId";
    $stmt4 = mysqli_prepare($conn, $sql4);
    mysqli_stmt_execute($stmt4);
    $result4 = mysqli_stmt_get_result($stmt4);
    if ($result4->num_rows > 0) {
        $response['data']['development_history'] = $result4->fetch_assoc();
    }

    $sql5 = "select * from history_illness where id = $patientId";
    $stmt5 = mysqli_prepare($conn, $sql5);
    mysqli_stmt_execute($stmt5);
    $result5 = mysqli_stmt_get_result($stmt5);
    if ($result5->num_rows > 0) {
        $response['data']['history_illness'] = $result5->fetch_assoc();
    }

    $sql6 = "select * from treatment where id = $patientId";
    $stmt6 = mysqli_prepare($conn, $sql6);
    mysqli_stmt_execute($stmt6);
    $result6 = mysqli_stmt_get_result($stmt6);
    if ($result6->num_rows > 0) {
        $response['data']['treatment'] = $result6->fetch_assoc();
    }

    $sql7 = "select * from course_dis where id = $patientId";
    $stmt7 = mysqli_prepare($conn, $sql7);
    mysqli_stmt_execute($stmt7);
    $result7 = mysqli_stmt_get_result($stmt7);
    if ($result7->num_rows > 0) {
        $response['data']['course_dis'] = $result7->fetch_assoc();
    }
} else {
    $response['status'] = "error";
    $response['message'] = "'num' parameter not found in the request.";
    
}
$conn->close();
echo json_encode($response);
?>