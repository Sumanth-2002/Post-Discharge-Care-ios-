<?php
require "conn.php";

// Check if the request method is POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Assuming you have a table named 'report_time' with columns 'id', 'report_time', and 'report_date'
    $patientId = $_POST['id'];

    // Fetch all report times and dates for the given patient ID
    $sql = "SELECT report_time, date FROM report_time WHERE id = ?";
    
    // Use a prepared statement to prevent SQL injection
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $patientId);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Output data of each row
        $reportData = array();
        while ($row = $result->fetch_assoc()) {
            $reportData[] = array(
                'report_time' => $row["report_time"],
                'report_date' => $row["date"]
            );
        }

        // Return the response in the specified format
        $response = array(
            'status' => 'success',
            'message' => 'Data found',
            'data' => $reportData
        );

        // Return the response as a JSON-encoded string
        header('Content-Type: application/json');
        echo json_encode($response);
    } else {
        // Return an error response
        $response = array(
            'status' => 'error',
            'message' => 'No data found for the given ID',
            'data' => array()
        );

        // Return the response as a JSON-encoded string
        header('Content-Type: application/json');
        echo json_encode($response);
    }

    $stmt->close();
} else {
    // Return an error response for invalid request method
    $response = array(
        'status' => 'error',
        'message' => 'Invalid request method',
        'data' => array()
    );

    // Return the response as a JSON-encoded string
    header('Content-Type: application/json');
    echo json_encode($response);
}

$conn->close();
?>
