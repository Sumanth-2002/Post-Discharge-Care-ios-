<?php
$response = array(); // Initialize a response array

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    $id = $_POST["id"];
    $text = array();
    $text[] = $_POST["text1"];
    $text[] = $_POST["text2"];
    $text[] = $_POST["text3"];
    $text[] = $_POST["text4"];
    $text[] = $_POST["text5"];
    $text[] = $_POST["text6"];
    $text[] = $_POST["text7"];
    $text[] = $_POST["text8"];
    $text[] = $_POST["text9"];
    $text[] = $_POST["text10"];
    $text[] = $_POST["text11"];

    // Establish a connection to the database
    $conn = new mysqli("localhost", "root", "", "post");

    if ($conn->connect_error) {
        $response["status"] = "error";
        $response["message"] = "Connection failed: " . $conn->connect_error;
    } else {
        // Check if the ID already exists in the questionnaire_doc table
        $check_query = "SELECT * FROM questionnaire_doc WHERE id = '$id'";
        $check_result = $conn->query($check_query);

        if ($check_result && $check_result->num_rows > 0) {
            // If the ID exists, perform an update query
            for ($i = 0; $i < count($text); $i++) {
                $category = ($i < 5) ? "General Symptoms" : "Danger Symptoms";
                $update_sql = "UPDATE questionnaire_doc SET 
                                Question_category = '$category', 
                                Question = '" . $text[$i] . "' 
                                WHERE id = '$id'";
                $conn->query($update_sql);
            }
            $response["status"] = "success";
            $response["message"] = "Data updated successfully";
        } else {
            // If the ID doesn't exist, return an error
            $response["status"] = "error";
            $response["message"] = "ID does not exist in the database";
        }
        // Close the database connection
        $conn->close();
    }
} else {
    $response["status"] = "error";
    $response["message"] = "Invalid request method";
}

// Encode the response array to JSON and echo it
header('Content-Type: application/json; charset=UTF-8');
echo json_encode($response);
?>
