<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $targetDirectory = "uploads/";

    // Function to upload image and return the paths
    function uploadImages($fieldName)
    {
        global $targetDirectory;
        $result = [];

        // Check if the field name exists and if it's an array
        if (isset($_FILES[$fieldName]) && is_array($_FILES[$fieldName]["name"])) {
            foreach ($_FILES[$fieldName]["name"] as $key => $value) {
                $targetFile = $targetDirectory . basename($_FILES[$fieldName]["name"][$key]);
                if (move_uploaded_file($_FILES[$fieldName]["tmp_name"][$key], $targetFile)) {
                    $result[] = $targetFile;
                } else {
                    $result[] = null;
                }
            }
        } elseif (isset($_FILES[$fieldName])) {
            // If there's only one file, treat it as an array
            $targetFile = $targetDirectory . basename($_FILES[$fieldName]["name"]);
            if (move_uploaded_file($_FILES[$fieldName]["tmp_name"], $targetFile)) {
                $result[] = $targetFile;
            } else {
                $result[] = null;
            }
        }

        return $result;
    }

    // Connect to the database
    $conn = new mysqli("localhost", "root", "", "post");
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Get values from the POST request
    $id = $_POST['Id'];
    $password = $_POST['password'];
    $name = $_POST['Name'];
    $gender = $_POST['Gender'];
    $contactNo = $_POST['Contact_No'];
    $dateOfBirth = $_POST['Date_of_Birth'];
    $parentName = $_POST['Parent_Name'];
    $height = $_POST['Height'];
    $weight = $_POST['Weight'];
    $admittedOn = $_POST['Admitted_On'];
    $dischargeOn = $_POST['Discharge_On'];
    $imagePath1 = isset($_FILES["Profile_pic"]) ? uploadImages("Profile_pic") : null;

    // Check if the user already exists in the database
    $checkUserQuery = "SELECT * FROM patient_details WHERE Id = '$id'";
    $checkUserResult = $conn->query($checkUserQuery);

    if ($checkUserResult->num_rows > 0) {
        // User exists, do not add a new record
        $response["status"] = "error";
        $response["message"] = "User with ID '$id' already exists.";

    } else {
        // User does not exist, insert a new record
        $insertQuery = "INSERT INTO patient_details (Id, Name, Contact_No, Gender, Date_of_Birth, Parent_Name, Height, Weight, Admitted_On, Discharge_On, Profile_pic)
            VALUES ('$id', '$name', '$contactNo', '$gender', '$dateOfBirth', '$parentName', '$height', '$weight', '$admittedOn', '$dischargeOn', '" . implode(",", $imagePath1) . "')";

        $insertLoginQuery = "INSERT INTO login (Id, password) VALUES('$id', '$password')";

        if ($conn->query($insertQuery) === TRUE && $conn->query($insertLoginQuery) === TRUE) {
            $response["status"] = "success";
            $response["message"] = "New patient added successfully.";
        } else {
            $response["status"] = "error";
            $response["message"] = "Error adding new patient: " . $conn->error;
        }
    }

    $conn->close();

    // Encode the response array to JSON and echo it
    echo json_encode($response);
} else {
    // Invalid request
    echo json_encode(array("status" => "error", "message" => "Invalid request."));
}
?>
