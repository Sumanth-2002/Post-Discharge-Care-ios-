<?php
require("conn.php");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!empty($_POST['id'])) {
        $id = intval($_POST['id']);

        $sql = "SELECT * FROM patient_details WHERE id = ?";
        
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "i", $id);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);

        if ($result) {
            $row = mysqli_fetch_assoc($result);

            if ($row) {
                // Get the image path
                $profilePicPath = $row['Profile_Pic'];

                // Check if the image path is not empty and the file exists
                if (!empty($profilePicPath) && file_exists($profilePicPath)) {
                    // Read the image file and encode it to base64
                    $profilePicData = base64_encode(file_get_contents($profilePicPath));
                    $row['Profile_Pic'] = $profilePicData;
                } else {
                    // Log an error if the image path is empty or the file doesn't exist
                    error_log("Image not found or invalid path for ID: " . $id);
                    echo json_encode(array('error' => 'Image not found for the given ID'));
                    exit;
                }

                // Convert all values to string
                $row = array_map('strval', $row);

                // Return JSON response as an array
                header('Content-Type: application/json');
                echo json_encode(array('status' => 'success', 'message' => 'Data found', 'data' => array($row)));
            } else {
                echo json_encode(array('error' => 'Patient not found for the given ID'));
            }
        } else {
            echo json_encode(array('error' => 'Failed to fetch patient details'));
        }

        mysqli_stmt_close($stmt);
        mysqli_close($conn);
    } else {
        echo json_encode(array('error' => 'ID not provided'));
    }
} else {
    echo json_encode(array('error' => 'Invalid request method'));
}
?>
