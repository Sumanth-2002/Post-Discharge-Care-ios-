<?php
require "conn.php";
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
header('Content-Type: application/json; charset=UTF-8');
$response = array();

if (isset($_POST['id'])) {
    // Retrieve the 'num' parameter value
    $num = $_POST['id'];

    $sql = "SELECT image
            FROM dis_image 
            WHERE patient_id = $num";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if ($result->num_rows > 0) {
        $response['status'] = "success";
        $response['message'] = "Data found";
        $response['data'] = array();

        while ($row = $result->fetch_assoc()) {
            $imagePath1 = $row["image"];

            // Check if image paths are not empty before attempting to read and encode images
            if (!empty($imagePath1)) {
                $data["patient_img"] = base64_encode(file_get_contents($imagePath1));
            } else {
                $data["patient_img"] = ""; // Set to empty string or any default value
            }

            array_push($response['data'], $data);
        }
    } else {
        $response['status'] = "error";
        $response['message'] = "No results found";
    }
} else {
    // If 'num' parameter is not set, handle the error accordingly
    $response['status'] = "error";
    $response['message'] = "'num' parameter not found in the request.";
}

$conn->close();

// Convert PHP array to JSON and output the response
echo json_encode($response);
?>