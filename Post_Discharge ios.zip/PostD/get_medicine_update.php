<?php
$response = array(); // Initialize a response array

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id'];
    $Course_Name = ($_POST["Course_Name"]);


    // Validate and sanitize other input fields
    $Date1 = ($_POST["Date"]);
    
    $Medicine_Name = ($_POST["Medicine_Name"]);
    $Duration = ($_POST["Duration"]);
    $Frequency = ($_POST["Frequency"]);
    $Guidelines = ($_POST["Guidelines"]);
    
    // Establish a connection to the database
    $conn = new mysqli("localhost", "root", "", "post");
    if ($conn->connect_error) {
        $response["status"] = "error";
        $response["message"] = "Connection failed: " . $conn->connect_error;
    } else {
        // Prepare and execute a SELECT query
        $sql = "SELECT * FROM medicine WHERE id = '$id'"; // Surround $id with single quotes
        $result = $conn->query($sql);

        if ($result) {
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    // Use existing details for fields not provided in the form
                    if (empty($Date1)) {
                        $Date1 = $row["Date"];
                    }
                    if (empty($Course_Name)) {
                        $Course_Name = $row["Course_Name"];
                    }
                    if (empty($Medicine_Name)) {
                        $Medicine_Name = $row["Medicine_Name"];
                    }
                    if (empty($Duration)) {
                        $Duration = $row["Duration"];
                    }
                    if (empty($Frequency)) {
                        $Frequency = $row["Frequency"];
                    }
                    if (empty($Guidelines)) {
                        $Guidelines = $row["Guidelines"];
                    }
                }
            }
            // Prepare and execute an UPDATE query
            $sql_update = "UPDATE medicine SET 
            Medicine_Name = '$Medicine_Name',
            Duration = '$Duration',  
            Frequency = '$Frequency',
            Guidelines = '$Guidelines',
            Date = '$Date1' WHERE id = '$id' and  Course_Name = '$Course_Name'"; // Surround $id with single quotes
            echo $sql_update;
            if ($conn->query($sql_update) === TRUE) {
                $response["status"] = "success";
                $response["message"] = "Data updated successfully";
            } else {
                $response["status"] = "error";
                $response["message"] = "Error updating record: " . $conn->error;
            }
        } else {
            $response["status"] = "error";
            $response["message"] = "Error: " . $sql . "<br>" . $conn->error;
        }

        // Close the connection
        $conn->close();
    }
} else {
    $response["status"] = "error";
    $response["message"] = "Invalid request method";
}

// Encode the response array to JSON and echo it
echo json_encode($response);
?>
