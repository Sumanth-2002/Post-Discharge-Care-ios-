<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Connect to the database
    $conn = new mysqli("localhost", "root", "", "post");
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    // Insert patient information and image paths into the database
    $id = $_POST['id'];
    $date = $_POST['date'];
    $count = $_POST['count'];
    $sql = "INSERT INTO report_time (id, report_time, date) VALUES ('$id', '$count','$date')";

    $response = array();
    if ($conn->query($sql) === TRUE) {
        $response["status"] = "success";
        $response["message"] = "Patient information and images uploaded successfully.";
    } else {
        $response["status"] = "error";
        $response["message"] = "Error: " . $sql . "<br>" . $conn->error;
    }
    $conn->close();
    echo json_encode($response);
} else {
    echo json_encode(array("status" => "error", "message" => "Invalid request."));
}
?>
