<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Connect to the database
    $conn = new mysqli("localhost", "root", "", "post");
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    // Insert patient information and image paths into the database
    $currentDate = date("Y-m-d");
    $course_name = $_POST["course_name"];
    $id = $_POST["id"];
    $medicine_name = $_POST["medicine_name"];
    $course_duration= $_POST["course_duration"];
    $frequency= $_POST["frequency"];
    $guidelines= $_POST["guidelines"];
    $sql = "INSERT INTO medicine (id, Course_Name, Medicine_Name, Duration, Frequency, Guidelines, Date)
            VALUES ('$id', '$course_name', '$medicine_name', '$course_duration', '$frequency', '$guidelines', '$currentDate')";

    $response = array();
    if ($conn->query($sql) === TRUE) {
        $response["status"] = "success";
        $response["message"] = "Patient information and images uploaded successfully.";
    } else {
        $response["status"] = "error";
        $response["message"] = "Error: " . $sql . "<br>" . $conn->error;
    }
    $conn->close();
    echo json_encode($response);
} else {
    echo json_encode(array("status" => "error", "message" => "Invalid request."));
}
?>
