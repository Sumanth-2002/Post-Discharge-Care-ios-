<?php
$response = array();
$conn = new mysqli("localhost", "root", "", "post");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve patient ID from the POST request
    $patientId = $_POST["id"];

    $response['status'] = "success";
    $response['message'] = "Data found";

    $response['id'] = $patientId;
    $sql1 = "select * from treatment where id = $patientId";
    $stmt1 = mysqli_prepare($conn, $sql1);
    mysqli_stmt_execute($stmt1);
    $result1 = mysqli_stmt_get_result($stmt1);
    if ($result1->num_rows > 0) {
        $response['data']['treatmentDetails'] = $result1->fetch_assoc();
    }

    $sql2 = "select * from discharge_summary where id = $patientId";
    $stmt2 = mysqli_prepare($conn, $sql2);
    mysqli_stmt_execute($stmt2);
    $result2 = mysqli_stmt_get_result($stmt2);
    if ($result2->num_rows > 0) {
        $response['data']['dischargeSummary'] = $result2->fetch_assoc();
    }

    $sql3 = "select * from course_dis where id = $patientId";
    $stmt3 = mysqli_prepare($conn, $sql3);
    mysqli_stmt_execute($stmt3);
    $result3 = mysqli_stmt_get_result($stmt3);
    if ($result3->num_rows > 0) {
        $response['data']['courseDischarge'] = $result3->fetch_assoc();
    }
}
else {
    $response['status'] = "error";
    $response['message'] = "'num' parameter not found in the request.";
    
}
$conn->close();
echo json_encode($response);
?>


