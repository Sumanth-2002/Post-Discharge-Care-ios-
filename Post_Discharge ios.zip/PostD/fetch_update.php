<?php
$response = array(); // Initialize a response array

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id'];
    // Retrieve form data
    $targetDirectory = "uploads/";

    function uploadImages($fieldName) {
        global $targetDirectory;
        $result = [];
        // Check if the field name exists and if it's an array
        if (isset($_FILES[$fieldName]) && is_array($_FILES[$fieldName]["name"])) {
            foreach ($_FILES[$fieldName]["name"] as $key => $value) {
                $targetFile = $targetDirectory . basename($_FILES[$fieldName]["name"][$key]);
                if (move_uploaded_file($_FILES[$fieldName]["tmp_name"][$key], $targetFile)) {
                    $result[] = $targetFile;
                } else {
                    $result[] = null;
                }
            }
        } else if (isset($_FILES[$fieldName])) {
            // If there's only one file, treat it as an array
            $targetFile = $targetDirectory . basename($_FILES[$fieldName]["name"]);
            if (move_uploaded_file($_FILES[$fieldName]["tmp_name"], $targetFile)) {
                $result[] = $targetFile;
            } else {
                $result[] = null;
            }
        }
        return $result;
    }

    // Upload Image 1
    $imagePath1 = isset($_FILES["Profile_Pic"]) ? uploadImages("Profile_Pic") : null;
    $Name = $_POST["Name"];
    $Contact_No = $_POST["Contact_No"];
    $Gender = $_POST["Gender"];
    $Date_Of_Birth = $_POST["Date_Of_Birth"];
    $Height = $_POST["Height"];
    $Weight = $_POST["Weight"];
    $Parent_Name = $_POST["Parent_Name"];
    $Admitted_On = $_POST["Admitted_On"];
    $Discharge_On = $_POST["Discharge_On"];

    // Establish a connection to the database
    $conn = new mysqli("localhost", "root", "", "post");

    if ($conn->connect_error) {
        $response["status"] = "error";
        $response["message"] = "Connection failed: " . $conn->connect_error;
    } else {
        $sql = "SELECT * FROM patient_details WHERE id = $id";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                // Use existing details for fields not provided in the form
                if (empty($Name)) {
                    $Name = $row["Name"];
                }
                if (empty($Contact_No)) {
                    $Contact_No = $row["Contact_No"];
                }
                if (empty($Gender)) {
                    $Gender = $row["Gender"];
                }
                if (empty($Date_Of_Birth)) {
                    $Date_Of_Birth = $row["Date_Of_Birth"];
                }
                if (empty($Height)) {
                    $Height = $row["Height"];
                }
                if (empty($Weight)) {
                    $Weight = $row["Weight"];
                }
                if (empty($Parent_Name)) {
                    $Parent_Name = $row["Parent_Name"];
                }
                if (empty($Admitted_On)) {
                    $Admitted_On = $row["Admitted_On"];
                }
                if (empty($Discharge_On)) {
                    $Discharge_On = $row["Discharge_On"];
                }
            }
        }

        // Update query
        $sql = "UPDATE patient_details SET 
        Name = '$Name', 
        Contact_No = '$Contact_No', 
        Gender = '$Gender', 
        Date_Of_Birth = '$Date_Of_Birth', 
        Height = '$Height', 
        Weight = '$Weight', 
        Parent_Name = '$Parent_Name', 
        Admitted_On = '$Admitted_On', 
        Discharge_On = '$Discharge_On'";

        if (!empty($imagePath1[0])) {
            $sql .= ", Profile_Pic = '" . $imagePath1[0] . "'";
        }
        
        $sql .= " WHERE id = $id";

        // Execute the update query
        $update = $conn->query($sql);

        if ($update) {
            $response["status"] = "success";
            $response["message"] = "Data updated successfully";
        } else {
            $response["status"] = "error";
            $response["message"] = "Error: " . $sql . "<br>" . $conn->error;
        }

        // Close the connection
        $conn->close();
    }
} else {
    $response["status"] = "error";
    $response["message"] = "Invalid request method";
}

// Encode the response array to JSON and echo it
echo json_encode($response);
?>
