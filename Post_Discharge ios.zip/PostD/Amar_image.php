<?php
$conn = mysqli_connect("localhost", "root", "", "post");
$response = array();
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST["id"];
    $sql = "SELECT image FROM dis_image WHERE patient_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        $response["status"] = "success";
        $response["message"] = "Images found";
        $response["images"] = array();


        while ($row = $result->fetch_assoc()) {
            $imagePaths = explode(",", $row["image"]);
            foreach ($imagePaths as $path) {
                $imageData = file_get_contents($path);
                $base64Image = base64_encode($imageData);
                $response["images"][] = $base64Image;
            }
        }
    } else {
        $response["status"] = "error";
        $response["message"] = "No images found for the given patient ID";
    }
    $stmt->close();
    $conn->close();

} else {
    $response["status"] = "error";
    $response["message"] = "Invalid request method";
}
header('Content-Type: application/json; charset=UTF-8');
echo json_encode($response);
?>
