<?php
require "conn.php";

// Check if 'id' and 'password' are provided in the POST data
if (isset($_POST['id']) && isset($_POST['password'])) {
    // Trim leading and trailing spaces from 'id' and 'password'
    $id = trim(mysqli_real_escape_string($conn, $_POST['id']));
    $password = trim(mysqli_real_escape_string($conn, $_POST['password']));

    // Query to check if the provided 'id' and 'password' exist in the doctor_login table
    $sql = "SELECT Name FROM doctor_login WHERE id = '$id' AND password = '$password'";
    $result = mysqli_query($conn, $sql);

    if ($result) {
        // Check if any rows are returned
        if (mysqli_num_rows($result) > 0) {
            $response = array('status' => 'success');
            echo json_encode($response);
        } else {
            $response = array('status' => 'failure');
            echo json_encode($response);
        }
    } else {
        $response = array('status' => 'error');
        echo json_encode($response);
    }

    mysqli_free_result($result);
}

mysqli_close($conn);
?>
