<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
 // Set the content type to JSON

if (isset($_POST['id']) && isset($_POST['password'])) {
    require_once "conn.php";
    require_once "validate.php";
    $id = validate($_POST['id']);
    $password = validate($_POST['password']);
    $sql = "SELECT * FROM login WHERE id = '$id' AND password = '$password'";
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        session_start();
        $response = array('status' => 'success');
        echo json_encode($response);
    } else {
        $response = array('status' => 'failure');
        echo json_encode($response);
    }
}
?>
