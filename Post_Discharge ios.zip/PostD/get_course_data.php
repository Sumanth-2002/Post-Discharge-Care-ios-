<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Connect to the database
    $conn = new mysqli("localhost", "root", "", "post");
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $id = $_POST["id"]; // Added a semicolon here
    $sql = "SELECT * FROM medicine WHERE id = '$id'";
    $result = $conn->query($sql);

    $response = array();
    if ($result) {
        // Fetch the data and store it in the $data array
        while ($row = $result->fetch_assoc()) {
            $data[] = $row;
        }

        $response["status"] = "success";
        $response["message"] = "Patient data retreived successfully.";
        $response["data"] = $data;
    } else {
        $response["status"] = "error";
        $response["message"] = "Error: " . $sql . "<br>" . $conn->error;
    }
    $conn->close();
    echo json_encode($response);
} else {
    echo json_encode(array("status" => "error", "message" => "Invalid request."));
}
?>
