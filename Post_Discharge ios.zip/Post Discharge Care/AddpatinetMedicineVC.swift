//
//  AddpatinetMedicineVC.swift
//  Post Discharge Care
//
//  Created by Amar Dwarakacherla on 28/02/24.
//



//
//  AddMedicineVC.swift
//  Post Discharge Care
//
//  Created by Amar on 28/01/24.
//

import UIKit

class AddpatinetMedicineVC: UIViewController {
    
    var id: String?
    var patientId: String?
    var body = Data()

    @IBOutlet weak var CourseNameTF: UITextField!
    @IBOutlet weak var MedicineTF: UITextField!
    @IBOutlet weak var DurationTF: UITextField!
    @IBOutlet weak var FrequencyTF: UITextField!
    @IBOutlet weak var GuideLinesTF: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    @IBAction func backButton(_ sender: Any) {
//        navigationController?.popViewController(animated: true)
        for controller in self.navigationController!.viewControllers as Array {
                    if controller.isKind(of: AddPatientMedicationVC.self) {
                        self.navigationController!.popToViewController(controller, animated: true)
                        break
                    }
                }
//        let storyboard = UIStoryboard(name: "Main", bundle: nil)
//        let VC = storyboard.instantiateViewController(withIdentifier: "AddPatientMedicationVC") as! AddPatientMedicationVC
//        navigationController?.pushViewController(VC, animated: true)
//        VC.id = id
        
    }
    @IBAction func SaveBUtton(_ sender: Any) {
        GetAPI()
        print(CourseNameTF.text ?? "")
        print(MedicineTF.text ?? "")
        print(DurationTF.text ?? "")
        print(FrequencyTF.text ?? "")
        print(GuideLinesTF.text ?? "")
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let VC = storyboard.instantiateViewController(withIdentifier: "DoctorPatientCouseList") as! DoctorPatientCouseList
        navigationController?.pushViewController(VC, animated: true)
        VC.id = id
    }
}
extension AddpatinetMedicineVC {
    func GetAPI() {
        let apiURL = APIList.AddmedicineApi
        print(apiURL)
        let boundary = UUID().uuidString
        var request = URLRequest(url: URL(string: apiURL)!)
        request.httpMethod = "POST"
        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
            // Update formData to include the password
        let formData: [String: String] = [
                "id": "\(id ?? "123456789")",
                "course_name": "\(CourseNameTF.text ?? "Error")",
                "medicine_name": "\(MedicineTF.text ?? "Error")",
                "course_duration": "\(DurationTF.text ?? "Error")",
                "frequency": "\(FrequencyTF.text ?? "Error")",
                "guidelines": "\(GuideLinesTF.text ?? "Error")"
                
            ]
        for (key, value) in formData {
            body.append(contentsOf: "--\(boundary)\r\n".utf8)
            body.append(contentsOf: "Content-Disposition: form-data; name=\"\(key)\"\r\n\r\n".utf8)
            body.append(contentsOf: "\(value)\r\n".utf8)
        }
        body.append(contentsOf: "--\(boundary)--\r\n".utf8) // Close the request body
        request.httpBody = body
        let task = URLSession.shared.dataTask(with: request) { (data, response, error) in
            if let error = error {
                print("Error: \(error)")
                // Handle the error, e.g., show an alert to the user
                return
            }
            if let httpResponse = response as? HTTPURLResponse {
                print("Status code: \(httpResponse.statusCode)")

                if let data = data {
                    print("Response Data:", String(data: data, encoding: .utf8) ?? "")
                    // You can perform further processing here
                }
            }
        }
        task.resume()
    }
}




