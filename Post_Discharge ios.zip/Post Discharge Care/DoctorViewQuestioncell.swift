//
//  DoctorViewQuestioncell.swift
//  Post Discharge Care
//
//  Created by Amar on 02/02/24.
//

import UIKit

class DoctorViewQuestioncell: UITableViewCell {

    @IBOutlet weak var DateLabel: UILabel!
    @IBOutlet weak var l1: UILabel!
    @IBOutlet weak var r1: UILabel!
    @IBOutlet weak var l2: UILabel!
    @IBOutlet weak var r2: UILabel!
    @IBOutlet weak var l3: UILabel!
    @IBOutlet weak var r3: UILabel!
    @IBOutlet weak var l4: UILabel!
    @IBOutlet weak var r4: UILabel!
    @IBOutlet weak var l5: UILabel!
    @IBOutlet weak var r5: UILabel!
    @IBOutlet weak var l6: UILabel!
    @IBOutlet weak var r6: UILabel!
    @IBOutlet weak var l7: UILabel!
    @IBOutlet weak var r7: UILabel!
    @IBOutlet weak var l8: UILabel!
    @IBOutlet weak var r8: UILabel!
    @IBOutlet weak var l9: UILabel!
    @IBOutlet weak var r9: UILabel!
    @IBOutlet weak var l10: UILabel!
    @IBOutlet weak var r10: UILabel!
    @IBOutlet weak var l11: UILabel!
    @IBOutlet weak var r11: UILabel!
    
    
    
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
