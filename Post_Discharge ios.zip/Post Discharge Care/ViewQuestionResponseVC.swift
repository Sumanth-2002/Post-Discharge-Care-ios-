import UIKit

class ViewQuestionResponseVC: UIViewController {

    @IBOutlet weak var calender: UIDatePicker!
    @IBOutlet weak var calender2: UIDatePicker!
    @IBOutlet weak var PrintButton: UIButton!
    var Date1: String?
    var Date2: String?

    var id: String?
    var ViewData: ResponseDataModel!

    @IBOutlet weak var tableviewBox: UITableView! {
        didSet {
            tableviewBox.dataSource = self
            tableviewBox.delegate = self
        }
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        PrintButton.addTarget(self, action: #selector(printSelectedDate1), for: .touchUpInside)
        PrintButton.addTarget(self, action: #selector(printSelectedDate2), for: .touchUpInside)
    }

    @IBAction func ViewButton(_ sender: Any) {
        GetAPI()
    }

    @objc func printSelectedDate1() {
        let selectedDate = calender.date
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        let formattedDate = dateFormatter.string(from: selectedDate)
        Date1 = formattedDate
        print("Selected Date 1: \(formattedDate)")
    }

    @objc func printSelectedDate2() {
        let selectedDate = calender2.date
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        let formattedDate = dateFormatter.string(from: selectedDate)
        Date2 = formattedDate
        print("Selected Date 2: \(formattedDate)")
    }
    @IBAction func BackButton(_ sender: Any) {
//        self.dismiss(animated: true, completion: nil)
        self.navigationController?.popViewController(animated: true)
    }

    func GetAPI() {
        let apiURL = APIList.ViewQuestionResponseApi
        print(apiURL)

        let parameters: [String: String] = [
            "id": id ?? "12234",
            "startDate": Date1 ?? "2023-11-01",
            "endDate":  Date2 ?? "2024-02-02"
        ]

        APIHandler().postAPIValues(type: ResponseDataModel.self, apiUrl: apiURL, method: "POST", formData: parameters) { result in
            switch result {
            case .success(let data):
                DispatchQueue.main.async {
                    self.ViewData = data
                    print(self.ViewData ?? "","----->")
                    self.tableviewBox.reloadData()
                }
            case .failure(let error):
                print(error)
            }
        }
    }
}

extension ViewQuestionResponseVC: UITableViewDelegate, UITableViewDataSource {

    func numberOfSections(in tableView: UITableView) -> Int {
//        return 1 
        ViewData?.data.count ?? 0
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        guard let responseData = ViewData?.data[section].resp else {
            print("Invalid section index")
            return 0
        }
        print(responseData.count,"responseData.count")
        return responseData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "DoctorViewQuestioncell", for: indexPath) as! DoctorViewQuestioncell

        guard let responseData = ViewData?.data else {
            print("Invalid section index")
            return cell
        }

        if indexPath.section < responseData.count {
            let dataForRow = responseData[indexPath.section].resp

            if indexPath.row < dataForRow.count {
//                cell.DateLabel.text = responseData[indexPath.section].date
                cell.l1.text = "\(dataForRow[indexPath.row].symptom)"
//                cell.l2.text = "\(dataForRow[indexPath.row].symptom)"
                
                cell.r1.text = "\(dataForRow[indexPath.row].response)"
//                cell.r1.text = "\(dataForRow[indexPath.row].response)"
            }
        }

        return cell
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        guard let data = ViewData?.data[section].date else {
            return nil
        }
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy.MM.dd"
        
        guard let date = dateFormatter.date(from: data) else {
            return nil
        }
        
        dateFormatter.dateFormat = "MMM dd, yyyy" // Adjust date format as per your requirement
        let dateString = dateFormatter.string(from: date)
        
        let label = UILabel()
        label.frame = CGRect(x: 0, y: 0, width: tableView.bounds.width, height: 50)
        label.textAlignment = .center
        label.text = dateString
        
        return label
    }




    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 50
    }
    
}
