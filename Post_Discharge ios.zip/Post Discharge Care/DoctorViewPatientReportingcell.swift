//
//  DoctorViewPatientReportingcell.swift
//  Post Discharge Care
//
//  Created by Amar on 01/02/24.
//

import UIKit

class DoctorViewPatientReportingcell: UITableViewCell {

    @IBOutlet weak var CountLabel: UILabel!
    @IBOutlet weak var DateLabel: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
