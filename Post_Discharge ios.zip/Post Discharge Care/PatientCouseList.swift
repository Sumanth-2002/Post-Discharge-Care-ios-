//
//  PatientCouseList.swift
//  Post Discharge Care
//
//  Created by Amar on 09/01/24.
//

import UIKit
class PatientCouseList: UIViewController {

    var id: String?
    var Courseid: String?
    var Course: PateintCourseModel!
    var Time: PatientReportingTimeModel!
    @IBOutlet weak var tableview: UITableView!{
        didSet{
            tableview.delegate = self
            tableview.dataSource = self
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        GetAPI()
        
    }
    @IBAction func back(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
    func GetAPI() {
        let apiURL = APIList.CourseApi
        print(apiURL)
        // Prepare POST parameters if needed
        let parameters: [String: String] = [
            "id": id ?? "123"

        ]

        APIHandler().postAPIValues(type: PateintCourseModel.self, apiUrl: apiURL, method: "POST", formData: parameters) { result in
            switch result {
            case .success(let data):
                DispatchQueue.main.async {
                self.Course = data
//                print(self.dashboard?.data ?? "")
//                    print("Dashboard Data: \(self.dashboard.data ?? [])")
                    self.tableview.reloadData()
                }
            case .failure(let error):
                print(error)
            }
        }
    }
}
extension PatientCouseList: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return Course?.data.count ?? 0
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if let data = Course?.data, indexPath.row < data.count {
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "PatientMediceneVC") as! PatientMediceneVC
            vc.id = data[indexPath.row].id
            vc.Courseid = data[indexPath.row].courseName
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "PatientCouseListCell", for: indexPath) as! PatientCouseListCell

        if let data = Course?.data, indexPath.row < data.count {
            cell.CourseLabel.text = data[indexPath.row].courseName
        } else {
            cell.CourseLabel.text = "N/A"
        }

        return cell
    }
}
