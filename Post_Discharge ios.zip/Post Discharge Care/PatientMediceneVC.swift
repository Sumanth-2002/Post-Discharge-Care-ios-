import UIKit

class PatientMediceneVC: UIViewController {
    @IBOutlet weak var MedicineLabel: UILabel!
    @IBOutlet weak var DurationLabel: UILabel!
    @IBOutlet weak var FrequencyLabel: UILabel!
    @IBOutlet weak var GuidelineLabel: UILabel!

    var id: String?
    var Courseid: String?
    var Course: PateintCourseModel!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Call the GetAPI function to initiate the API request
        GetAPI()
    }
    @IBAction func BackButton(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
}

extension PatientMediceneVC {
    func GetAPI() {
        let apiURL = APIList.GetMedicineApi
        print(apiURL)
        // Prepare POST parameters if needed
        let parameters: [String: Any] = [
            "id": id ?? "123",
            "Course_Name": Courseid ?? "2"
            // Add your POST parameters here if required
            // "key1": value1,
            // "key2": value2,
        ]
        APIHandler().postAPIValues(type: PateintCourseModel.self, apiUrl: apiURL, method: "POST", formData: parameters) { result in
            switch result {
            case .success(let data):
                DispatchQueue.main.async {
                    self.Course = data
                    if let courseData = self.Course?.data.first {
                        // Assign values to your labels based on the retrieved data
                        self.MedicineLabel.text = courseData.medicineName
                        self.DurationLabel.text = courseData.duration
                        self.FrequencyLabel.text = courseData.frequency
                        self.GuidelineLabel.text = courseData.guidelines
                    } else {
                        print("Error loading")
                    }
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async {
                    let alert = UIAlertController(title: "Warning", message: "Something Went Wrong", preferredStyle: .alert)
                    alert.addAction(UIAlertAction(title: "Ok", style: .destructive) { _ in
                        print("API Error")
                    })
                    self.present(alert, animated: true, completion: nil)
                }
            }
        }
    }
}
