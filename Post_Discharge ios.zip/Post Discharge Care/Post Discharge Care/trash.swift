//
//  trash.swift
//  Post Discharge Care
//
//  Created by Amar on 08/01/24.
//

import Foundation
//import UIKit
//
//class DoctorViewPatientcell: UITableViewCell {
//
//    override func awakeFromNib() {
//        super.awakeFromNib()
//                        
//        
//        
//        
//        
//        
//        
//                // Add border to the cell
//        contentView.layer.borderWidth = 1
//        contentView.layer.borderColor = UIColor.lightGray.cgColor
//        contentView.layer.cornerRadius = 8 // Optional: Add corner radius for a rounded appearance
//    }
//
//    override func setSelected(_ selected: Bool, animated: Bool) {
//        super.setSelected(selected, animated: animated)
//
//        // Configure the view for the selected state
//    }
//
//}
