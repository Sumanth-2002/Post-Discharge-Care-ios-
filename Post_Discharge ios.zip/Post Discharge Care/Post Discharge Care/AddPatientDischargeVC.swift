//
//  AddPatientDischargeVC.swift
//  Post Discharge Care
//
//  Created by Amar on 09/01/24.
//

import UIKit

class AddPatientDischargeVC: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    var id: String?
    var name: String?
    var gender: String?
    var admitted: String?
    var discharge: String?
    
    @IBOutlet weak var idLabel: UILabel!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var GenderLabel: UILabel!
    @IBOutlet weak var Date_Of_AdmissionLabel: UILabel!
    @IBOutlet weak var Date_Of_DischargeLabel: UILabel!
    @IBOutlet weak var DepartmentTF: UITextField!
    @IBOutlet weak var ConsultantTF: UITextField!
    @IBOutlet weak var AddressTF: UITextField!
    @IBOutlet weak var Chief_ComplaintsTF: UITextField!
    @IBOutlet weak var History_of_present_illnessTF: UITextField!
    @IBOutlet weak var Past_HistoryTF: UITextField!
    @IBOutlet weak var Antennal_historyTF: UITextField!
    @IBOutlet weak var Natal_HistoryTF: UITextField!
    @IBOutlet weak var PostNatal_HistoryTF: UITextField!
    @IBOutlet weak var Gross_MotorTF: UITextField!
    @IBOutlet weak var Fine_MotorTF: UITextField!
    @IBOutlet weak var LanguageTF: UITextField!
    @IBOutlet weak var Social_and_CongnitiontTF: UITextField!
    @IBOutlet weak var Immunization_historyTF: UITextField!
    @IBOutlet weak var AnthropometryTF: UITextField!
    @IBOutlet weak var WeightTF: UITextField!
    @IBOutlet weak var HeightTF: UITextField!
    @IBOutlet weak var Heart_rateTF: UITextField!
    @IBOutlet weak var TemperatureTF: UITextField!
    @IBOutlet weak var crtTF: UITextField!
    @IBOutlet weak var rrTF: UITextField!
    @IBOutlet weak var spo2TF: UITextField!
    @IBOutlet weak var Head_to_Toe_ExaminationTF: UITextField!
    @IBOutlet weak var General_ExaminationTF: UITextField!
    @IBOutlet weak var Systematic_ExaminationTF: UITextField!
    @IBOutlet weak var Treatment_GivenTF: UITextField!
    @IBOutlet weak var Course_in_HospitalTF: UITextField!
    @IBOutlet weak var Course_in_PicuTF: UITextField!
    @IBOutlet weak var Course_in_wardTF: UITextField!
    @IBOutlet weak var Advice_on_DischargeTF: UITextField!
    @IBOutlet weak var ReviewTF: UITextField!
    
    var body = Data()
    var selectedImages: [UIImage] = []
    let imagePicker = UIImagePickerController()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.isNavigationBarHidden = true
        imagePicker.delegate = self
        imagePicker.allowsEditing = true
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard))
        self.view.addGestureRecognizer(tapGesture)
        idLabel.text = id
        nameLabel.text = name
        GenderLabel.text = gender
        Date_Of_DischargeLabel.text = discharge
        Date_Of_AdmissionLabel.text = admitted
    }
    
    @objc func dismissKeyboard() {
        view.endEditing(true)
    }
    
    @IBAction func selectImage1Tapped(_ sender: Any) {
        presentImagePicker()
    }
    
    @IBAction func BackButton(_ sender: Any) {
        for controller in self.navigationController!.viewControllers as Array {
            if controller.isKind(of: AddPatientNextVC.self) {
                self.navigationController!.popToViewController(controller, animated: true)
                break
            }
        }
    }
    
    @IBAction func SaveButton(_ sender: Any) {
        GetAPI()
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let VC = storyboard.instantiateViewController(withIdentifier: "AddPatientNextVC") as! AddPatientNextVC
        navigationController?.pushViewController(VC, animated: true)
        VC.id = id
    }
    
    func presentImagePicker() {
        let alert = UIAlertController(title: "Choose Image", message: nil, preferredStyle: .actionSheet)
        alert.addAction(UIAlertAction(title: "Camera", style: .default, handler: { _ in
            self.openCamera()
        }))
        alert.addAction(UIAlertAction(title: "Gallery", style: .default, handler: { _ in
            self.openGallery()
        }))
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        present(alert, animated: true, completion: nil)
    }
    
    func openCamera() {
        if UIImagePickerController.isSourceTypeAvailable(.camera) {
            imagePicker.sourceType = .camera
            present(imagePicker, animated: true, completion: nil)
        } else {
            print("Camera not available")
        }
    }
    
    func openGallery() {
        imagePicker.sourceType = .photoLibrary
        present(imagePicker, animated: true, completion: nil)
    }
    
    // UIImagePickerControllerDelegate methods
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let pickedImage = info[UIImagePickerController.InfoKey.editedImage] as? UIImage {
            selectedImages.append(pickedImage)
        }
        picker.dismiss(animated: true, completion: nil)
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
    }
}

extension AddPatientDischargeVC {
    func GetAPI() {
        let apiURL = APIList.AddDischargeApi
        print(apiURL)

        let boundary = UUID().uuidString
        var request = URLRequest(url: URL(string: apiURL)!)
        request.httpMethod = "POST"
        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")

        let formData: [String: String] = [
            "id": "\(id ?? "143" )",
            "name": "\(name ?? "Amar")",
            "Gender": "\(gender ?? "male")",
            "Address": "dda",
            "Diagnosis":"dsDS",
            "Date_Of_Admission": "\(admitted ?? "2024-02-02")",
            "Date_Of_Discharge": "\(discharge ?? "2024-02-02")",
            "Department": "\(DepartmentTF.text ?? "")",
            "Consultant": "\(ConsultantTF.text ?? "")",
            "Chief_Complaints": "\(Chief_ComplaintsTF.text ?? "")",
            "History_of_present_illness": "\(History_of_present_illnessTF.text ?? "")",
            "Past_History": "\(Past_HistoryTF.text ?? "")",
            "Antennal_history": "\(Antennal_historyTF.text ?? "")",
            "Natal_History": "\(Natal_HistoryTF.text ?? "")",
            "PostNatal_History": "\(PostNatal_HistoryTF.text ?? "")",
            "Gross_Motor": "\(Gross_MotorTF.text ?? "")",
            "Fine_Motor": "\(Fine_MotorTF.text ?? "")",
            "Language": "\(LanguageTF.text ?? "")",
            "Social_and_Congnitiont": "\(Social_and_CongnitiontTF.text ?? "")",
            "Immunization_history": "\(Immunization_historyTF.text ?? "")",
            "Anthropometry": "\(AnthropometryTF.text ?? "")",
            "Weight": "\(WeightTF.text ?? "")",
            "Height": "\(HeightTF.text ?? "")",
            "Heart_rate": "\(Heart_rateTF.text ?? "")",
            "Temperature": "\(TemperatureTF.text ?? "")",
            "crt": "\(crtTF.text ?? "")",
            "rr": "\(rrTF.text ?? "")",
            "spo2": "\(spo2TF.text ?? "")",
            "Head_to_Toe_Examination": "\(Head_to_Toe_ExaminationTF.text ?? "")",
            "General_Examination": "\(General_ExaminationTF.text ?? "")",
            "Systematic_Examination": "\(Systematic_ExaminationTF.text ?? "")",
            "Treatment_Given": "\(Treatment_GivenTF.text ?? "")",
            "Course_in_Hospital": "\(Course_in_HospitalTF.text ?? "")",
            "Course_in_Picu": "\(Course_in_PicuTF.text ?? "")",
            "Course_in_ward": "\(Course_in_wardTF.text ?? "")",
            "Advice_on_Discharge": "\(Advice_on_DischargeTF.text ?? "")",
            "Review": "\(ReviewTF.text ?? "")",
        ]

        for (key, value) in formData {
            body.append(contentsOf: "--\(boundary)\r\n".utf8)
            body.append(contentsOf: "Content-Disposition: form-data; name=\"\(key)\"\r\n\r\n".utf8)
            body.append(contentsOf: "\(value)\r\n".utf8)
        }

//        let fieldNames = ["images"]

        let fieldNames = selectedImages.indices.map { "images[\($0)]" }

        for (index, image) in selectedImages.enumerated() {
            let fieldName = fieldNames[index]
            let imageData = image.jpegData(compressionQuality: 0.8)!
            body.append(contentsOf: "--\(boundary)\r\n".utf8)
            body.append(contentsOf: "Content-Disposition: form-data; name=\"\(fieldName)\"; filename=\"\(UUID().uuidString).jpg\"\r\n".utf8)
            body.append(contentsOf: "Content-Type: image/jpeg\r\n\r\n".utf8)
            body.append(contentsOf: imageData)
            body.append(contentsOf: "\r\n".utf8)
        }


        body.append(contentsOf: "--\(boundary)--\r\n".utf8) // Close the request body
        request.httpBody = body

        let task = URLSession.shared.dataTask(with: request) { (data, response, error) in
            if let error = error {
                print("Error: \(error)")
                // Handle the error, e.g., show an alert to the user
                return
            }
            if let httpResponse = response as? HTTPURLResponse {
                print("Status code: \(httpResponse.statusCode)")
                if let data = data {
                    print("Response Data:", String(data: data, encoding: .utf8) ?? "")
                    // You can perform further processing here
                }
            }
        }
        task.resume()
    }
}
