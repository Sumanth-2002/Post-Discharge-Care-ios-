//
//  PatientDashboardCVcell.swift
//  Post Discharge Care
//
//  Created by Amar on 09/01/24.
//

import UIKit

class PatientDashboardCVcell: UICollectionViewCell {
    
    @IBOutlet weak var DateLabel: UILabel!
    @IBOutlet weak var ReportTime: UILabel!
    
}
