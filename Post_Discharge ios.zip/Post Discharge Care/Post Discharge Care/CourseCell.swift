//
//  CourseCell.swift
//  Post Discharge Care
//
//  Created by Amar on 02/02/24.
//

import UIKit

class CourseCell: UITableViewCell {

    @IBOutlet weak var courseName: UILabel!
    @IBOutlet weak var MedName: UILabel!
    @IBOutlet weak var Duration: UILabel!
    @IBOutlet weak var Frequency: UILabel!
    @IBOutlet weak var GuideLines: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        
    }

}
