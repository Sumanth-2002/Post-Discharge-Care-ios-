//
//  DoctorViewPatientVC.swift
//  Post Discharge Care
//
//  Created by Amar on 03/01/24.
//

import UIKit

class DoctorViewPatientVC: UIViewController {
    var id: String?
    var dashboard: DoctorViewPatientVCModel!
    var searching = false
    var filtered: [DashData] = []

    @IBOutlet weak var tableviewBox: UITableView!{
        didSet{
            tableviewBox.dataSource = self
            tableviewBox.delegate = self
       }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        getDashAPI()

    }
    
    @IBAction func backButton(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
    func getDashAPI() {
        let apiURL = APIList.dashURL
        print(apiURL)
        // Prepare POST parameters if needed
        let parameters: [String: String] = [:
            // Add your JSON parameters here if required
            // "key1": value1,
        ]

        APIHandler().postAPIValues(type: DoctorViewPatientVCModel.self, apiUrl: apiURL, method: "POST", formData: parameters) { result in
            switch result {
            case .success(let data):
                DispatchQueue.main.async {
                self.dashboard = data
//                print(self.dashboard?.data ?? "")
//                    print("Dashboard Data: \(self.dashboard.data ?? [])")
                    self.tableviewBox.reloadData()
                }
            case .failure(let error):
                print(error)
            }
        }
    }
}


extension DoctorViewPatientVC: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return searching ? filtered.count : dashboard?.data.count ?? 5
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "DViewPatientVC") as! DViewPatientVC
        let data = searching ? filtered[indexPath.row] : dashboard?.data[indexPath.row]
        vc.id = data?.id
        self.navigationController?.pushViewController(vc, animated: true)
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "DoctorViewPatientcell", for: indexPath) as! DoctorViewPatientcell
        DispatchQueue.main.async{ [self] in
            let data = searching ? filtered[indexPath.row] : dashboard?.data[indexPath.row]
            cell.nameLabel.text = data?.name
            cell.genderLabel.text = data?.gender
            cell.contactLabel.text = data?.contactNo
            cell.idLabel.text = data?.id
            id = data?.id
            if let imageDataString = data?.patientImg,
                      let imageData = Data(base64Encoded: imageDataString),
                      let image = UIImage(data: imageData) {
                       DispatchQueue.main.async {
                           cell.patient_img?.image = image
                           cell.patient_img?.contentMode = .scaleAspectFit
                              cell.patient_img?.clipsToBounds = true
                       }
                   }
        }
//        cell.selectionStyle = .default // Make sure this is set
        return cell
    }
    public func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 140
    }
}
extension DoctorViewPatientVC: UISearchBarDelegate {
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        if searchText.isEmpty {
            searching = false
            filtered.removeAll()
        } else {
            searching = true
            filtered = dashboard?.data.filter {
                $0.name.range(of: searchText, options: .caseInsensitive) != nil
            } ?? []
        }
        tableviewBox.reloadData()
    }
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        searchBar.text = ""
        searching = false
        filtered.removeAll()
        tableviewBox.reloadData()
    }
}


//extension DoctorViewPatientVC:UITableViewDelegate,UITableViewDataSource{
//    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//        return 5
//    }
//    
//    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
//        let cell = tableView.dequeueReusableCell(withIdentifier: "DoctorViewPatientcell") as! DoctorViewPatientcell
//        
//        return cell
//    }
//    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
//            // Set a specific height for the cells (for example, 100)
//            return 138
//        }
//    
//    
//}
