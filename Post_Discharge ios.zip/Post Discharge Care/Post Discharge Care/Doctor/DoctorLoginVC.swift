//
//  DoctorLoginVC.swift
//  Post Discharge Care
//
//  Created by Amar on 02/01/24.
//

import UIKit

class DoctorLoginVC: UIViewController {
    var login: DoctorLoginModel!

    @IBOutlet weak var roundimage: UIImageView!
    @IBOutlet weak var idTF: UITextField!
    @IBOutlet weak var passwordTF: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        roundimage.contentMode = .scaleToFill
        roundimage.clipsToBounds = true
        roundimage.layer.cornerRadius = self.roundimage.frame.height / 2
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard))
                self.view.addGestureRecognizer(tapGesture)
    }
    @objc func dismissKeyboard() {
            view.endEditing(true)
    }
    @IBAction func onlogin(_ sender: Any) {
        guard let enteredEmail = idTF.text, !enteredEmail.isEmpty,
              let enteredPassword = passwordTF.text, !enteredPassword.isEmpty else {
            let alert = UIAlertController(title: "Alert", message: "Email or password field is empty", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            present(alert, animated: true)
            return
        }
        
        postAPI()
    }
    func postAPI() {
        let apiURL = APIList.DoctorLogInURL
        print(apiURL)
        let formData = [
            "id": idTF.text ?? "",
            "password": passwordTF.text ?? ""
        ]
        APIHandler().postAPIValues(type: DoctorLoginModel.self, apiUrl: apiURL, method: "POST", formData: formData) { [weak self] result in
            DispatchQueue.main.async {
                guard let self = self else { return }
                switch result {
                case .success(let login):
                    print(login)
                    if login.status == "success" {
                        self.navigateToDashboard()
                    } else {
                        self.showAlert(title: "Error Login failed. Please try again.", message: "fail")
                    }
                case .failure(let error):
                    print(error)
                    self.showAlert(title: "Error", message: "Something went wrong. Please try again.")
                }
            }
        }
    }
    func showAlert(title: String, message: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        present(alert, animated: true)
    }
    
    func navigateToDashboard() {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let VC = storyboard.instantiateViewController(withIdentifier: "DoctorDashboardVC") as! DoctorDashboardVC
        navigationController?.pushViewController(VC, animated: true)
        VC.id = self.idTF.text
    }
}
