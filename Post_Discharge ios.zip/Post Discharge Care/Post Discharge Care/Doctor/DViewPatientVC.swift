//
//  DViewPatientVC.swift
//  Post Discharge Care
//
//  Created by Amar on 09/01/24.
//

import UIKit
struct PatienteData {
    var patientImage: UIImage?
}

class DViewPatientVC: UIViewController,UIImagePickerControllerDelegate, UINavigationControllerDelegate, UITextFieldDelegate {
    var selectedImages: [PatienteData] = []
    var body = Data()
    var selectedButtonIndex: Int = 0
    let imagePicker = UIImagePickerController()
    let boundary = "Boundary-\(UUID().uuidString)"
    @IBOutlet weak var pidTF: UITextField!
    @IBOutlet weak var NameTF: UITextField!
    @IBOutlet weak var ContactTF: UITextField!
    @IBOutlet weak var GenderTF: UITextField!
    @IBOutlet weak var DateOfBirthTF: UITextField!
    @IBOutlet weak var HeightTF: UITextField!
    @IBOutlet weak var WeightTF: UITextField!
    @IBOutlet weak var Parent: UITextField!
    @IBOutlet weak var AdmittedTF: UITextField!
    @IBOutlet weak var DischargeTF: UITextField!
    @IBOutlet weak var profileIMG: UIImageView!
    var id: String?
    var viewPatient: ViewPatientDetailsModel?
    override func viewDidLoad() {
        super.viewDidLoad()
        print(id ?? "");
        self.navigationController?.isNavigationBarHidden=true;
        GetAPI()
        imagePicker.delegate = self
        imagePicker.allowsEditing = true
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(uploadImageTapped))
        profileIMG.isUserInteractionEnabled = true
        profileIMG.addGestureRecognizer(tapGesture)
    }
    override func viewWillAppear(_ animated: Bool) {
        GetAPI()
    }
    @objc func dismissKeyboard() {
        view.endEditing(true)
    }
    func presentImagePicker(forIndex index: Int) {
        selectedButtonIndex = index
        let alert = UIAlertController(title: "Choose Image", message: nil, preferredStyle: .actionSheet)
        alert.addAction(UIAlertAction(title: "Camera", style: .default, handler: { _ in
            self.openCamera()
        }))
        alert.addAction(UIAlertAction(title: "Gallery", style: .default, handler: { _ in
            self.openGallery()
        }))
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        present(alert, animated: true, completion: nil)
    }

    @objc func uploadImageTapped() {
        presentImagePicker(forIndex: 0)
    }

    func openCamera() {
        if UIImagePickerController.isSourceTypeAvailable(.camera) {
            imagePicker.sourceType = .camera
            present(imagePicker, animated: true, completion: nil)
        } else {
            print("Camera not available")
        }
    }

    func openGallery() {
        imagePicker.sourceType = .photoLibrary
        present(imagePicker, animated: true, completion: nil)
    }

    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey: Any]) {
        if let pickedImage = info[UIImagePickerController.InfoKey.originalImage] as? UIImage {
            updateSelectedImages(with: pickedImage)
        }
        picker.dismiss(animated: true, completion: nil)
    }

    func updateSelectedImages(with image: UIImage) {
        var imageData = PatienteData()
        switch selectedButtonIndex {
        case 0:
            imageData.patientImage = image
            profileIMG.image = image
        default:
            break
        }
        while selectedImages.count <= selectedButtonIndex {
            selectedImages.append(PatienteData())
        }
        // Update the selected image data in the array
        selectedImages[selectedButtonIndex] = imageData
    }

    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
    }
    @IBAction func UpdateButton(_ sender: Any) {
        PostAPI()
    }
    @IBAction func ViewDischargeButton(_ sender: Any) {
        let VC = storyboard!.instantiateViewController(withIdentifier: "ViewDischargeVC") as! ViewDischargeVC
        navigationController?.pushViewController(VC, animated: true)
        VC.id = self.id
    }
    @IBAction func ViewMedicineButton(_ sender: Any) {
        let VC = storyboard!.instantiateViewController(withIdentifier: "DoctorPatientCouseList") as! DoctorPatientCouseList
        navigationController?.pushViewController(VC, animated: true)
        VC.id = self.id
        
    }
    @IBAction func ViewReportingButton(_ sender: Any) {
        let VC = storyboard!.instantiateViewController(withIdentifier: "PatientReportingVC") as! PatientReportingVC
        navigationController?.pushViewController(VC, animated: true)
        VC.id = self.id
    }
    @IBAction func ViewQuestionariesButton(_ sender: Any) {
        let VC = storyboard!.instantiateViewController(withIdentifier: "ViewQuestionResponseVC") as! ViewQuestionResponseVC
        navigationController?.pushViewController(VC, animated: true)
        VC.id = self.id
    }
    
    
    func GetAPI() {
        let apiURL = APIList.ViewPatientApi
        print(apiURL)

        // Prepare POST parameters if needed
        let parameters: [String: String] = [
            "id" : id ?? "12234"
            
            // "key1": value1,
            // "key2": value2,
        ]
        APIHandler().postAPIValues(type: ViewPatientDetailsModel.self, apiUrl: apiURL, method: "POST", formData: parameters) { result in
            switch result {
            case .success(let data):
                self.viewPatient = data
//                print(data)
                DispatchQueue.main.async { [self] in
                    if let patientData = self.viewPatient?.data.first {
                        self.NameTF.text=patientData.name
                        self.ContactTF.text = patientData.contactNo
                        self.pidTF.text = patientData.id
                        self.GenderTF.text = patientData.gender
                        self.DateOfBirthTF.text = patientData.dateOfBirth
                        self.HeightTF.text = patientData.height
                        self.WeightTF.text = patientData.weight
                        self.Parent.text = patientData.parentName
                        self.AdmittedTF.text = patientData.admittedOn
                        self.DischargeTF.text = patientData.dischargeOn
                        self.profileIMG.image = getImage(from: patientData.profilePic)
                    }
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async {
                    let alert = UIAlertController(title: "Warning", message: "Something Went Wrong", preferredStyle: .alert)
                    alert.addAction(UIAlertAction(title: "Ok", style: .destructive) { _ in
                        print("API Error")
                    })
                    self.present(alert, animated: true, completion: nil)
                }
            }
        }
    }
    func getImage(from imageDataString: String?) -> UIImage? {
        guard let imageDataString = imageDataString, let imageData = Data(base64Encoded: imageDataString) else {
            return nil
        }
        return UIImage(data: imageData)
    }
    func PostAPI() {
        let apiURL = APIList.UpdateViewPatientApi
        print(apiURL)
        
        var request = URLRequest(url: URL(string: apiURL)!)
        request.httpMethod = "POST"
        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
        
        let formData: [String: String] = [
            "id": id ?? "12234",
            "Name": NameTF.text ?? "",
            "Contact_No": ContactTF.text ?? "",
            "Gender": GenderTF.text ?? "",
            "Date_Of_Birth": DateOfBirthTF.text ?? "",
            "Height": HeightTF.text ?? "",
            "Weight": WeightTF.text ?? "",
            "Parent_Name": Parent.text ?? "",
            "Admitted_On": AdmittedTF.text ?? "",
            "Discharge_On": DischargeTF.text ?? ""
            // Add other form data fields here
        ]
        body = Data()
        for (key, value) in formData {
            body.append(contentsOf: "--\(boundary)\r\n".utf8)
            body.append(contentsOf: "Content-Disposition: form-data; name=\"\(key)\"\r\n\r\n".utf8)
            body.append(contentsOf: "\(value)\r\n".utf8)
        }
        
        let fieldNames = ["Profile_Pic"]
        for (index, image) in selectedImages.enumerated() {
            let fieldName = fieldNames[index]
            if let imageData = image.patientImage?.jpegData(compressionQuality: 0.8) {
                body.append(contentsOf: "--\(boundary)\r\n".utf8)
                body.append(contentsOf: "Content-Disposition: form-data; name=\"\(fieldName)\"; filename=\"\(UUID().uuidString).jpg\"\r\n".utf8)
                body.append(contentsOf: "Content-Type: image/jpeg\r\n\r\n".utf8)
                body.append(imageData)
                body.append(contentsOf: "\r\n".utf8)
            }
        }
        
        body.append(contentsOf: "--\(boundary)--\r\n".utf8)
        request.httpBody = body
        
        let task = URLSession.shared.dataTask(with: request) { (data, response, error) in
            if let error = error {
                print("Error: \(error)")
                return
            }
            if let httpResponse = response as? HTTPURLResponse {
                print("Status code: \(httpResponse.statusCode)")
                
                if let data = data {
                    print("Response Data:", String(data: data, encoding: .utf8) ?? "")
                    // You can perform further processing here
                }
            }
        }
        task.resume()
    }

    

    @IBAction func backButton(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }

}
