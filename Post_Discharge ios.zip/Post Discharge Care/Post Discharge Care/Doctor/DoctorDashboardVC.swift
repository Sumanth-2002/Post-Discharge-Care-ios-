//
//  DoctorDashboardVC.swift
//  Post Discharge Care
//
//  Created by Amar on 02/01/24.
//

import UIKit

class DoctorDashboardVC: UIViewController {
    var id: String?
    
    var getPatient : GetArrivalModel!
    @IBOutlet weak var collectionView: UICollectionView!

    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.isNavigationBarHidden = true
        collectionView.dataSource = self
        collectionView.delegate = self
        getAPI()
        
        
        
    }
    
    @IBAction func ViewPatientButton(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let VC = storyboard.instantiateViewController(withIdentifier: "DoctorViewPatientVC") as! DoctorViewPatientVC
        navigationController?.pushViewController(VC, animated: true)
        
        
    }
    @IBAction func AddPateintButton(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let VC = storyboard.instantiateViewController(withIdentifier: "AddPatientVC") as! AddPatientVC
        navigationController?.pushViewController(VC, animated: true)
        
        
        
    }
    @IBAction func Profile(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let VC = storyboard.instantiateViewController(withIdentifier: "DoctorProfileVC") as! DoctorProfileVC
        navigationController?.pushViewController(VC, animated: true)
        VC.id = self.id
    }
    func getAPI() {
        let apiURL = APIList.patientArrivalApi
        print(apiURL)
        let parameters: [String: String] = [:]
        
        APIHandler().postAPIValues(type: GetArrivalModel.self, apiUrl: apiURL, method: "POST", formData: parameters) { result in
            switch result {
            case .success(let data):
                DispatchQueue.main.async {
                    self.getPatient = data
                    self.collectionView.reloadData()
                    self.printPatientData()
                }
            case .failure(let error):
                print(error)
            }
        }
    }
    func printPatientData() {
        // Ensure getPatient is not nil
        guard let patient = getPatient else {
            print("No patient data available")
            return
        }
        print("Status: \(patient.status)")
        
        // Print each patient's information
        for patientData in patient.data {
            print("ID: \(patientData.id)")
            print("Name: \(patientData.name)")
            print("Gender: \(patientData.gender)")
            print("Contact No: \(patientData.contactNo)")
//            print("Profile Pic: \(patientData.profilePic)")
            print("-------------------")
        }
    }

}
extension DoctorDashboardVC: UICollectionViewDelegate, UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        print(getPatient?.data.count)
        return getPatient?.data.count ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "DoctorDashboardVCcell", for: indexPath) as! DoctorDashboardVCcell
        
        if let reportingData = getPatient?.data[indexPath.item] {
            cell.idLabel.text = reportingData.id
            cell.NameLabel.text = reportingData.name
            cell.ContactNameLabel.text = reportingData.contactNo
            cell.GenderLabel.text = reportingData.gender
            cell.ProfileImage.image = getImage(from: reportingData.profilePic)
            
        }
        return cell
    }
    
    
    func collectionView(collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAtIndexPath indexPath: NSIndexPath) -> CGSize {
        return CGSize(width: 300, height: 250.0)
//        self.view.frame.width
    }
    
    func getImage(from imageDataString: String?) -> UIImage? {
        guard let imageDataString = imageDataString, let imageData = Data(base64Encoded: imageDataString) else {
            return nil
        }
        return UIImage(data: imageData)
    }
}
