//
//  DoctorProfileVC.swift
//  Post Discharge Care
//
//  Created by Amar on 02/01/24.
//

import UIKit

class DoctorProfileVC: UIViewController {
    var id: String?
    var viewDoctor: ViewDoctorProfileModel?

    @IBOutlet weak var NameLabel: UILabel!
    @IBOutlet weak var GenderLabel: UILabel!
    @IBOutlet weak var DepartmentLabel: UILabel!
    @IBOutlet weak var ExperienceLabel: UILabel!
    @IBOutlet weak var ContactLabel: UILabel!
    @IBOutlet weak var profileImage: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard))
                self.view.addGestureRecognizer(tapGesture)
        GetAPI()
    }
    @objc func dismissKeyboard() {
            view.endEditing(true)
    }

    @IBAction func backButton(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
    @IBAction func EditButton(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let VC = storyboard.instantiateViewController(withIdentifier: "DoctorProfileEditVC") as! DoctorProfileEditVC
        navigationController?.pushViewController(VC, animated: true)
        VC.id = self.id
    }
    @IBAction func Logout(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let VC = storyboard.instantiateViewController(withIdentifier: "HomeVC") as! HomeVC
        navigationController?.pushViewController(VC, animated: true)
    }
    
    func GetAPI() {
        let apiURL = APIList.ViewDoctorApi
        print(apiURL)

        // Prepare POST parameters if needed
        let parameters: [String: String] = [
            "id" : id ?? "1890"
            // "key1": value1,
            // "key2": value2,
        ]
        APIHandler().postAPIValues(type: ViewDoctorProfileModel.self, apiUrl: apiURL, method: "POST", formData: parameters) { result in
            switch result {
            case .success(let data):
                self.viewDoctor = data
//                print(data)
                DispatchQueue.main.async { [self] in
                    if let patientData = self.viewDoctor?.data.first {
                        self.NameLabel.text=patientData.name
                        self.ContactLabel.text = patientData.contactNumber
                        self.GenderLabel.text = patientData.gender
                        self.ExperienceLabel.text = patientData.experience
                        self.DepartmentLabel.text = patientData.department
                        self.profileImage.image = getImage(from: patientData.docProfile)
                    }
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async {
                    let alert = UIAlertController(title: "Warning", message: "Something Went Wrong", preferredStyle: .alert)
                    alert.addAction(UIAlertAction(title: "Ok", style: .destructive) { _ in
                        print("API Error")
                    })
                    self.present(alert, animated: true, completion: nil)
                }
            }
        }
    }
    func getImage(from imageDataString: String?) -> UIImage? {
        guard let imageDataString = imageDataString, let imageData = Data(base64Encoded: imageDataString) else {
            return nil
        }
        return UIImage(data: imageData)
    }
    

}

