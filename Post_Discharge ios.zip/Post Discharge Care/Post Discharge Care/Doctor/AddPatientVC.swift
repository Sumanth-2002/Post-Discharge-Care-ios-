//
//  AddPatientVC.swift
//  Post Discharge Care
//
//  Created by Amar on 03/01/24.
//


import UIKit

class AddPatientVC: UIViewController,UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    
    var id: String?

    @IBOutlet weak var pidTF: UITextField!
    @IBOutlet weak var NameTF: UITextField!
    @IBOutlet weak var ContactTF: UITextField!
    @IBOutlet weak var GenderTF: UITextField!
    @IBOutlet weak var DateOfBirthTF: UITextField!
    @IBOutlet weak var HeightTF: UITextField!
    @IBOutlet weak var WeightTF: UITextField!
    @IBOutlet weak var Parent: UITextField!
    @IBOutlet weak var AdmittedTF: UITextField!
    @IBOutlet weak var DischargeTF: UITextField!
    @IBOutlet weak var profileIMG: UIImageView!
    
    var body = Data()
    var selectedImages: [UIImage] = []
    let imagePicker = UIImagePickerController()
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.isNavigationBarHidden = true
        imagePicker.delegate = self
        imagePicker.allowsEditing = true
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard))
                self.view.addGestureRecognizer(tapGesture)
       
    }
    @objc func dismissKeyboard() {
            view.endEditing(true)
        }
    
    @IBAction func selectImage1Tapped(_ sender: Any) {
        presentImagePicker()
    }
    func presentImagePicker() {
        let alert = UIAlertController(title: "Choose Image", message: nil, preferredStyle: .actionSheet)
        alert.addAction(UIAlertAction(title: "Camera", style: .default, handler: { _ in
            self.openCamera()
        }))
        alert.addAction(UIAlertAction(title: "Gallery", style: .default, handler: { _ in
            self.openGallery()
        }))
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        present(alert, animated: true, completion: nil)
    }
    
    func openCamera() {
        if UIImagePickerController.isSourceTypeAvailable(.camera) {
            imagePicker.sourceType = .camera
            present(imagePicker, animated: true, completion: nil)
        } else {
            print("Camera not available")
        }
    }
    
    func openGallery() {
        imagePicker.sourceType = .photoLibrary
        present(imagePicker, animated: true, completion: nil)
    }
    
    // UIImagePickerControllerDelegate methods
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let pickedImage = info[UIImagePickerController.InfoKey.editedImage] as? UIImage {
            selectedImages.append(pickedImage)
        }
        
        picker.dismiss(animated: true, completion: nil)
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
    }
    
    
    @IBAction func AddPatientbtn(_ sender: Any) {
        GetAPI()
        let storyBoard: UIStoryboard=UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "AddPatientNextVC") as! AddPatientNextVC
        self.navigationController?.pushViewController(vc, animated: true)
        vc.id = self.pidTF.text
        vc.name = self.NameTF.text
        vc.gender = self.GenderTF.text
        vc.admitted = self.AdmittedTF.text
        vc.discharge = self.DischargeTF.text
    }
    
    @IBAction func BackButton(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
    @IBAction func NextButton(_ sender: Any) {
        
        
    }
    
}


extension AddPatientVC {
    func GetAPI() {
        let apiURL = APIList.AddPatientApi     
        print(apiURL)

        let boundary = UUID().uuidString
        var request = URLRequest(url: URL(string: apiURL)!)
        request.httpMethod = "POST"
        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")

        let pid = pidTF.text ?? "Error"
            let password = String(pid.suffix(4))
        print(password)

            // Update formData to include the password
            var formData: [String: String] = [
                "Name": "\(NameTF.text ?? "Error")",
                "Id": "\(pid)",
                "password": "\(password)",  // Include the password here
                "Contact_No": "\(ContactTF.text ?? "Error")",
                "Gender": "\(GenderTF.text ?? "Error")",
                "Date_of_Birth": "\(DateOfBirthTF.text ?? "Error")",
                "Parent_Name": "\(Parent.text ?? "Error")",
                "Height": "\(HeightTF.text ?? "Error")",
                "Weight": "\(WeightTF.text ?? "Error")",
                "Discharge_On": "\(DischargeTF.text ?? "Error")",
                "Admitted_On": "\(AdmittedTF.text ?? "Error")"
                // "Profile_pic":""
            ]
        for (key, value) in formData {
            body.append(contentsOf: "--\(boundary)\r\n".utf8)
            body.append(contentsOf: "Content-Disposition: form-data; name=\"\(key)\"\r\n\r\n".utf8)
            body.append(contentsOf: "\(value)\r\n".utf8)
        }
        let fieldNames = ["Profile_pic"]
        for (index, image) in selectedImages.enumerated() {
            let fieldName = fieldNames[index]
            let imageData = image.jpegData(compressionQuality: 0.8)!
            body.append(contentsOf: "--\(boundary)\r\n".utf8)
            body.append(contentsOf: "Content-Disposition: form-data; name=\"\(fieldName)\"; filename=\"\(UUID().uuidString).jpg\"\r\n".utf8)
            body.append(contentsOf: "Content-Type: image/jpeg\r\n\r\n".utf8)
            body.append(contentsOf: imageData)
            body.append(contentsOf: "\r\n".utf8)
        }
        body.append(contentsOf: "--\(boundary)--\r\n".utf8) // Close the request body
        request.httpBody = body
        let task = URLSession.shared.dataTask(with: request) { (data, response, error) in
            if let error = error {
                print("Error: \(error)")
                // Handle the error, e.g., show an alert to the user
                return
            }
            if let httpResponse = response as? HTTPURLResponse {
                print("Status code: \(httpResponse.statusCode)")

                if let data = data {
                    print("Response Data:", String(data: data, encoding: .utf8) ?? "")
                    // You can perform further processing here
                }
            }
        }
        task.resume()
    }
}

