//
//  DoctorDashboardVCcell.swift
//  Post Discharge Care
//
//  Created by Amar on 09/01/24.
//

import UIKit

class DoctorDashboardVCcell: UICollectionViewCell {
    
    @IBOutlet weak var idLabel: UILabel!
    @IBOutlet weak var NameLabel: UILabel!
    @IBOutlet weak var ContactNameLabel: UILabel!
    @IBOutlet weak var GenderLabel: UILabel!
    @IBOutlet weak var ProfileImage: UIImageView!
}
