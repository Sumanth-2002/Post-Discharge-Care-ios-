//
//  PatientReportingVC.swift
//  Post Discharge Care
//
//  Created by Amar on 01/02/24.
//

import UIKit

class PatientReportingVC: UIViewController {
    var id: String?
    var Reporting: ViewReportingModel!
    //    var dashboard: DoctorViewPatientVCModel!

    @IBOutlet weak var tableviewBox: UITableView!{
        didSet{
            tableviewBox.dataSource = self
            tableviewBox.delegate = self
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        GetAPI()
        
    }
    @IBAction func backButton(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    func GetAPI() {
        let apiURL = APIList.ViewReportTimeApi
        print(apiURL)
        // Prepare POST parameters if needed
        let parameters: [String: String] = [
            "id": id ?? "12234"
            // "key1": value1,
        ]
        
        APIHandler().postAPIValues(type: ViewReportingModel.self, apiUrl: apiURL, method: "POST", formData: parameters) { result in
            switch result {
            case .success(let data):
                DispatchQueue.main.async {
                    self.Reporting = data
                    self.tableviewBox.reloadData()
                }
            case .failure(let error):
                print(error)
            }
        }
    }
}
extension PatientReportingVC:UITableViewDelegate, UITableViewDataSource
{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return Reporting?.data.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            let cell = tableView.dequeueReusableCell(withIdentifier: "DoctorViewPatientReportingcell", for: indexPath) as! DoctorViewPatientReportingcell
            
            if let reportingData = Reporting?.data, indexPath.row < reportingData.count {
                let dataForRow = reportingData[indexPath.row]
                cell.DateLabel.text = reportingData[indexPath.row].reportDate
                cell.CountLabel.text = reportingData[indexPath.row].reportTime
                
            }
            
            return cell
    }
    public func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 50
    }
}
