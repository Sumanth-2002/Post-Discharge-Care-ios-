//
//  ViewDischargeVC.swift
//  Post Discharge Care
//
//  Created by Amar on 01/02/24.
//




import UIKit

class ViewDischargeVC: UIViewController {

    
    var id: String?
    var name: String?
    var gender: String?
    var admittedOn: String?
    var dischargeOn: String?
//    var body = Data()
    
    var viewDetails: DoctorViewDischargeModel?
    @IBOutlet weak var pidLabel: UITextField!
    @IBOutlet weak var NameLabel: UILabel!
    @IBOutlet weak var GenderLabel: UILabel!
    @IBOutlet weak var DepartmentLabel: UITextView!
    @IBOutlet weak var Consultant: UITextView!
    @IBOutlet weak var review: UITextView!
    @IBOutlet weak var Advice: UITextView!
    @IBOutlet weak var ward: UITextView!
    @IBOutlet weak var courseinpicu: UITextView!
    @IBOutlet weak var courseinhospital: UITextView!
    @IBOutlet weak var treatment: UITextView!
    @IBOutlet weak var systematic: UITextView!
    @IBOutlet weak var general: UITextView!
    @IBOutlet weak var head: UITextView!
    @IBOutlet weak var immunization: UITextView!
    @IBOutlet weak var spo2: UITextView!
    @IBOutlet weak var rr: UITextView!
    @IBOutlet weak var crt: UITextView!
    @IBOutlet weak var temperature: UITextView!
    @IBOutlet weak var heartrate: UITextView!
    @IBOutlet weak var weight: UITextView!
    @IBOutlet weak var height: UITextView!
    @IBOutlet weak var anthropometry: UITextView!
    @IBOutlet weak var AddressLabel: UITextView!
    @IBOutlet weak var ChiefComplaintsLabel: UITextView!
    @IBOutlet weak var HisoryofpresentIllnes: UITextView!
    @IBOutlet weak var AntennalHistory: UITextView!
    @IBOutlet weak var pastHistory: UITextView!
    @IBOutlet weak var NatalHistory: UITextView!
    @IBOutlet weak var postnatalHistory: UITextView!
    @IBOutlet weak var Grossmotor: UITextView!
    @IBOutlet weak var finemotor: UITextView!
    @IBOutlet weak var language: UITextView!
    @IBOutlet weak var social: UITextView!

    override func viewDidLoad() {
        super.viewDidLoad()
        NameLabel.text = "Amar"

        GetAPI()
    }

    @IBAction func ViewImageButton(_ sender: Any) {
        let VC = storyboard!.instantiateViewController(withIdentifier: "ViewImageVC") as! ViewImageVC
        navigationController?.pushViewController(VC, animated: true)
        VC.id = self.id
        
        
    }
    @IBAction func SaveButton(_ sender: Any) {
        PostApi()
        let VC = storyboard!.instantiateViewController(withIdentifier: "DViewPatientVC") as! DViewPatientVC
        navigationController?.pushViewController(VC, animated: true)
        VC.id = self.id
        
    }
    @IBAction func backButton(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
}
extension ViewDischargeVC{
    func GetAPI() {
        let apiURL = APIList.ViewDoctorDischargeApi
//        print(apiURL)
        // Prepare POST parameters if needed
        let parameters: [String: String] = [
            "id" : id ?? "12234"
            // "key1": value1,
        ]
        APIHandler().postAPIValues(type: DoctorViewDischargeModel.self, apiUrl: apiURL, method: "POST", formData: parameters) { result in
            switch result {
            case .success(let data):
                self.viewDetails = data
                DispatchQueue.main.async { [self] in
                    if let patientData = self.viewDetails?.data {
                        self.pidLabel.text = " " + patientData.chiefComplaints.id
                        self.ChiefComplaintsLabel.text = " " +  patientData.chiefComplaints.chiefComplaints
                        self.HisoryofpresentIllnes.text = " " +    patientData.historyIllness.illness
                        self.pastHistory.text = " " +   patientData.historyIllness.pastHistory
                        self.AntennalHistory.text = " " +   patientData.historyIllness.antennalHistory
                        self.NatalHistory.text = " " +   patientData.historyIllness.natalHistory
                        self.postnatalHistory.text = " " +   patientData.historyIllness.postnatalHistory
                        self.Grossmotor.text = " " +   patientData.developmentHistory.grossMotor
                        self.finemotor.text = " " +   patientData.developmentHistory.fineMotor
                        self.language.text = " " +   patientData.developmentHistory.language
                        self.social.text = " " +   patientData.developmentHistory.socialAndCognition
                        self.immunization.text = " " +   patientData.immunizationHistory.history
                        self.anthropometry.text = " " +   patientData.immunizationHistory.anthropometry
                        self.height.text = " " +   patientData.immunizationHistory.height
                        self.weight.text = " " +   patientData.immunizationHistory.weightt
                        self.heartrate.text = " " +   patientData.vitalsAtAdmission.heartRate
                        self.temperature.text = " " +   patientData.vitalsAtAdmission.temperature
                        self.crt.text = " " +   patientData.vitalsAtAdmission.crt
                        self.rr.text = " " +   patientData.vitalsAtAdmission.rr
                        self.spo2.text = " " +   patientData.vitalsAtAdmission.spo2
                        self.head.text = " " +   patientData.treatment.headToToeExamination
                        self.general.text = " " +   patientData.treatment.generalExamination
                        self.systematic.text = " " +   patientData.treatment.systematicExamination
                        self.treatment.text = " " +   patientData.treatment.treatmentGiven
                        self.courseinpicu.text = " " +   patientData.courseDis.courseInPICU
                        self.courseinhospital.text = " " +   patientData.courseDis.courseInHospital
                        self.ward.text = " " +   patientData.courseDis.courseInWard
                        self.Advice.text = " " +   patientData.courseDis.adviceOnDischarge
                        self.review.text = " " +   patientData.courseDis.review
                        
                        
                        
//                        self.profile_Img.image = getImage(from: patientData.docProfile)
                    }
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async {
                    let alert = UIAlertController(title: "Warning", message: "Something Went Wrong", preferredStyle: .alert)
                    alert.addAction(UIAlertAction(title: "Ok", style: .destructive) { _ in
                        print("API Error")
                    })
                    self.present(alert, animated: true, completion: nil)
                }
            }
        }
    }
    func PostApi() {
        let apiURL = APIList.UpdateDischargeApi
        print(apiURL)

        let boundary = UUID().uuidString
        var request = URLRequest(url: URL(string: apiURL)!)
        request.httpMethod = "POST"
        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")

        var body = Data()

        let formData: [String: String] = [
            "id": "\(id ?? "143" )",
            "name": "\(name ?? "Amar")",
            "Gender": "\(gender ?? "male")",
            "Address": "dda",
            "Diagnosis":"dsDS",
            "Date_Of_Admission": "\(admittedOn ?? "2024-02-02")",
            "Date_Of_Discharge": "\(dischargeOn ?? "2024-02-02")",
            "Department": "\(DepartmentLabel.text ?? "")",
            "Consultant": "\(Consultant.text ?? "")",
            "Chief_Complaints": "\(ChiefComplaintsLabel.text ?? "")",
            "History_of_present_illness": "\(ChiefComplaintsLabel.text ?? "")",
            "Past_History": "\(pastHistory.text ?? "")",
            "Antennal_history": "\(AntennalHistory.text ?? "")",
            "Natal_History": "\(NatalHistory.text ?? "")",
            "PostNatal_History": "\(postnatalHistory.text ?? "")",
            "Gross_Motor": "\(Grossmotor.text ?? "")",
            "Fine_Motor": "\(finemotor.text ?? "")",
            "Language": "\(language.text ?? "")",
            "Social_and_Congnitiont": "\(social.text ?? "")",
            "Immunization_history": "\(immunization.text ?? "")",
            "Anthropometry": "\(anthropometry.text ?? "")",
            "Weight": "\(weight.text ?? "")",
            "Height": "\(height.text ?? "")",
            "Heart_rate": "\(heartrate.text ?? "")",
            "Temperature": "\(temperature.text ?? "")",
            "crt": "\(crt.text ?? "")",
            "rr": "\(rr.text ?? "")",
            "spo2": "\(spo2.text ?? "")",
            "Head_to_Toe_Examination": "\(head.text ?? "")",
            "General_Examination": "\(general.text ?? "")",
            "Systematic_Examination": "\(systematic.text ?? "")",
            "Treatment_Given": "\(treatment.text ?? "")",
            "Course_in_Hospital": "\(courseinhospital.text ?? "")",
            "Course_in_Picu": "\(courseinpicu.text ?? "")",
            "Course_in_ward": "\(ward.text ?? "")",
            "Advice_on_Discharge": "\(Advice.text ?? "")",
            "Review": "\(review.text ?? "")",
        ]

        for (key, value) in formData {
            body.append("--\(boundary)\r\n".data(using: .utf8)!)
            body.append("Content-Disposition: form-data; name=\"\(key)\"\r\n\r\n".data(using: .utf8)!)
            body.append("\(value)\r\n".data(using: .utf8)!)
        }

        body.append("--\(boundary)--\r\n".data(using: .utf8)!) // Close the request body
        request.httpBody = body

        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            guard let data = data, error == nil else {
                print("Error: \(error?.localizedDescription ?? "Unknown error")")
                return
            }

            if let httpResponse = response as? HTTPURLResponse {
                print("Status code: \(httpResponse.statusCode)")
                // Handle response status code or data if needed
            }

            if let responseString = String(data: data, encoding: .utf8) {
                print("Response data: \(responseString)")
                // Handle response data if needed
            }
        }

        task.resume()
    }

    func getImage(from imageDataString: String?) -> UIImage? {
        guard let imageDataString = imageDataString, let imageData = Data(base64Encoded: imageDataString) else {
            return nil
        }
        return UIImage(data: imageData)
    }
}
