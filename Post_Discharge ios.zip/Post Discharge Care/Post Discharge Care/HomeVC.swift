//
//  HomeVC.swift
//  Post Discharge Care
//
//  Created by Amar on 02/01/24.
//

import UIKit

class HomeVC: UIViewController {
    @IBOutlet weak var roundimage: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        roundimage.contentMode = .scaleToFill
        roundimage.clipsToBounds = true
        roundimage.layer.cornerRadius = self.roundimage.frame.height / 2
    }
    
    @IBAction func patientLoginBTN(_ sender: Any) {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "PatientLoginVC") as! PatientLoginVC
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    
    @IBAction func doctorLoginBTN(_ sender: Any) {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "DoctorLoginVC") as! DoctorLoginVC
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    
}
