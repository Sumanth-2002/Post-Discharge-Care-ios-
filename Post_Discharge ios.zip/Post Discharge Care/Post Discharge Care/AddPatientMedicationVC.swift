//
//  AddPatientMedicationVC.swift
//  Post Discharge Care
//
//  Created by Amar on 09/01/24.
//

import UIKit

class AddPatientMedicationVC: UIViewController {
    var id: String?
    var Course: ViewAddMedicineModel!
    
    @IBOutlet weak var HistoryTableView: UITableView!{
        didSet{
            HistoryTableView.dataSource = self
            HistoryTableView.delegate = self
        }
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        GetAPI()

        
    }
    override func viewWillAppear(_ animated: Bool) {
            super.viewWillAppear(animated)
            GetAPI() // Reload data from API every time the view will appear
        }
    @IBAction func BackButton(_ sender: Any) {
//        navigationController?.popViewController(animated: true)
        for controller in self.navigationController!.viewControllers as Array {
                    if controller.isKind(of: AddPatientNextVC.self) {
                        self.navigationController!.popToViewController(controller, animated: true)
                        break
                    }
                }
//        let VC = storyboard!.instantiateViewController(withIdentifier: "AddPatientNextVC") as! AddPatientNextVC
//        navigationController?.pushViewController(VC, animated: true)
//        VC.id = self.id
        
    }
    @IBAction func AddButton(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let VC = storyboard.instantiateViewController(withIdentifier: "AddMedicineVC") as! AddMedicineVC
        navigationController?.pushViewController(VC, animated: true)
        VC.id = id
    }
    
    func GetAPI() {
        let apiURL = APIList.viewAddMedicineApi
        print(apiURL)
        // Prepare POST parameters if needed
        let parameters: [String: String] = [
            "id": id ?? "55555"
            // "key1": value1,
        ]

        APIHandler().postAPIValues(type: ViewAddMedicineModel.self, apiUrl: apiURL, method: "POST", formData: parameters) { result in
            switch result {
            case .success(let data):
                DispatchQueue.main.async {
                self.Course = data
                    self.HistoryTableView.reloadData()
                }
            case .failure(let error):
                print(error)
            }
        }
    }

    
}
extension AddPatientMedicationVC: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return Course?.data.count ?? 0
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CourseCell", for: indexPath) as! CourseCell
        if let view = self.Course?.data[indexPath.row] {
            cell.courseName.text = view.courseName
            cell.MedName.text = view.medicineName
            cell.Duration.text = view.duration
            cell.Frequency.text = view.frequency
            cell.GuideLines.text = view.guidelines
        }
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 210
    }
}


