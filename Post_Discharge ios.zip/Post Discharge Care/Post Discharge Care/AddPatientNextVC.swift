//
//  AddPatientNextVC.swift
//  Post Discharge Care
//
//  Created by Amar on 09/01/24.
//

import UIKit

class AddPatientNextVC: UIViewController {
    
    
    var id : String?
    var name: String?
    var gender: String?
    var admitted: String?
    var discharge: String?

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    @IBAction func BackButton(_ sender: Any) {
//        navigationController?.popViewController(animated: true)
        for controller in self.navigationController!.viewControllers as Array {
                    if controller.isKind(of: AddPatientVC.self) {
                        self.navigationController!.popToViewController(controller, animated: true)
                        break
                    }
                }
    }
    @IBAction func DischargeSummaryButton(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let VC = storyboard.instantiateViewController(withIdentifier: "AddPatientDischargeVC") as! AddPatientDischargeVC
        navigationController?.pushViewController(VC, animated: true)
        VC.id = self.id ?? ""
        VC.name = self.name ?? ""
        VC.gender = self.gender ?? ""
        VC.admitted = self.admitted ?? ""
        VC.discharge = self.discharge ?? ""
        
    }
    
    @IBAction func MedicationButton(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let VC = storyboard.instantiateViewController(withIdentifier: "AddPatientMedicationVC") as! AddPatientMedicationVC
        navigationController?.pushViewController(VC, animated: true)
        VC.id = id
        
    }
    
    @IBAction func QuestionariesButton(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let VC = storyboard.instantiateViewController(withIdentifier: "AddPatientQuestionVC") as! AddPatientQuestionVC
        navigationController?.pushViewController(VC, animated: true)
        VC.id = id
        
    }
    
    @IBAction func ReportTimeButton(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let VC = storyboard.instantiateViewController(withIdentifier: "AddPatientReportTimeVC") as! AddPatientReportTimeVC
        navigationController?.pushViewController(VC, animated: true)
        VC.id = id
    }
}
