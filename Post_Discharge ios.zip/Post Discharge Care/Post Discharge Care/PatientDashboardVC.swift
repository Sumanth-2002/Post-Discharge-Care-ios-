//
//  PatientDashboardVC.swift
//  Post Discharge Care
//
//  Created by Amar on 09/01/24.
//

import UIKit

class PatientDashboardVC: UIViewController {
    var id: String?
    var ReportTime : ViewReportingModel!
    @IBOutlet weak var collectionView: UICollectionView!
    override func viewDidLoad() {
        super.viewDidLoad()
        collectionView.dataSource = self
        collectionView.delegate = self
        GetAPI()
    }
    @IBAction func ProfileButton(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let VC = storyboard.instantiateViewController(withIdentifier: "PatientMyProfileVC") as! PatientMyProfileVC
        navigationController?.pushViewController(VC, animated: true)
        VC.id = self.id
        
        
    }
    @IBAction func DischargeButton(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let VC = storyboard.instantiateViewController(withIdentifier: "DischargeSummaryVC") as! DischargeSummaryVC
        navigationController?.pushViewController(VC, animated: true)
        VC.id = self.id
    }
    @IBAction func MedicationButton(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let VC = storyboard.instantiateViewController(withIdentifier: "PatientCouseList") as! PatientCouseList
        navigationController?.pushViewController(VC, animated: true)
        VC.id = self.id
    }
    
    @IBAction func FallowUp(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let VC = storyboard.instantiateViewController(withIdentifier: "PFallowUp") as! PFallowUp
        navigationController?.pushViewController(VC, animated: true)
        VC.id = self.id
    }
    func GetAPI() {
            let apiURL = APIList.ViewReportTimeApi
            print(apiURL)
            let parameters: [String: String] = ["id": id ?? "12234"]
            
            APIHandler().postAPIValues(type: ViewReportingModel.self, apiUrl: apiURL, method: "POST", formData: parameters) { result in
                switch result {
                case .success(let data):
                    DispatchQueue.main.async {
                        self.ReportTime = data
                        self.collectionView.reloadData()
                    }
                case .failure(let error):
                    print(error)
                }
            }
        }
    
}


extension PatientDashboardVC: UICollectionViewDelegate, UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return ReportTime?.data.count ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "PatientDashboardCVcell", for: indexPath) as! PatientDashboardCVcell
        
        if let reportingData = ReportTime?.data[indexPath.item] {
            cell.DateLabel.text = reportingData.reportDate
            // Additional properties from reportingData can be used here
        }
        return cell
    }
}
