
import UIKit

struct PatientImageData {
    var DoctorImage: UIImage?
}

class DoctorProfileEditVC: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    var id: String?
    var selectedButtonIndex: Int = 0
    var viewDoctor: ViewDoctorProfileModel?
    var selectedImages: [UIImage] = []
    let imagePicker = UIImagePickerController()
    @IBOutlet weak var NameTF: UITextField!
    @IBOutlet weak var GenderTF: UITextField!
    @IBOutlet weak var DepartmentTF: UITextField!
    @IBOutlet weak var ExperineceTF: UITextField!
    @IBOutlet weak var ContactTF: UITextField!
    @IBOutlet weak var profile_Img: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        GetAPI()
        imagePicker.delegate = self
        imagePicker.allowsEditing = true
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard))
        self.view.addGestureRecognizer(tapGesture)
        profile_Img.addAction(for: .tap) {
            self.presentImagePicker(forIndex: 0)
        }
    }

    @objc func dismissKeyboard() {
        view.endEditing(true)
    }
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let pickedImage = info[UIImagePickerController.InfoKey.editedImage] as? UIImage {
            selectedImages.append(pickedImage)
            
            // Display the selected image in UIImageView
            profile_Img.image = pickedImage
        }

        picker.dismiss(animated: true, completion: nil)
    }

    func presentImagePicker(forIndex index: Int) {
        selectedButtonIndex = index
        let alert = UIAlertController(title: "Choose Image", message: nil, preferredStyle: .actionSheet)
        alert.addAction(UIAlertAction(title: "Camera", style: .default, handler: { _ in
            self.openCamera()
        }))
        alert.addAction(UIAlertAction(title: "Gallery", style: .default, handler: { _ in
            self.openGallery()
        }))
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        present(alert, animated: true, completion: nil)
    }

    func openCamera() {
        if UIImagePickerController.isSourceTypeAvailable(.camera) {
            imagePicker.sourceType = .camera
            present(imagePicker, animated: true, completion: nil)
        } else {
            print("Camera not available")
        }
    }

    func openGallery() {
        imagePicker.sourceType = .photoLibrary
        present(imagePicker, animated: true, completion: nil)
    }

    // UIImagePickerControllerDelegate methods
//    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
//        if let pickedImage = info[UIImagePickerController.InfoKey.editedImage] as? UIImage {
//            selectedImages.append(pickedImage)
//            // Reload UI or update any necessary views
//        }
//
//        picker.dismiss(animated: true, completion: nil)
//    }

    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
    }

    @IBAction func backButton(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }

    @IBAction func SaveButton(_ sender: Any) {
        GettAPI()

        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let homePageVC = storyboard.instantiateViewController(withIdentifier: "DoctorProfileVC") as! DoctorProfileVC
        navigationController?.pushViewController(homePageVC, animated: true)
    }

    func GetAPI() {
        let apiURL = APIList.ViewDoctorApi
        print(apiURL)
        // Prepare POST parameters if needed
        let parameters: [String: String] = [
            "id" : id ?? "1890"
            // "key1": value1,
        ]
        APIHandler().postAPIValues(type: ViewDoctorProfileModel.self, apiUrl: apiURL, method: "POST", formData: parameters) { result in
            switch result {
            case .success(let data):
                self.viewDoctor = data
                DispatchQueue.main.async { [self] in
                    if let patientData = self.viewDoctor?.data.first {
                        self.NameTF.text = patientData.name
                        self.ContactTF.text = patientData.contactNumber
                        self.GenderTF.text = patientData.gender
                        self.ExperineceTF.text = patientData.experience
                        self.DepartmentTF.text = patientData.department
                        self.profile_Img.image = getImage(from: patientData.docProfile)
                    }
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async {
                    let alert = UIAlertController(title: "Warning", message: "Something Went Wrong", preferredStyle: .alert)
                    alert.addAction(UIAlertAction(title: "Ok", style: .destructive) { _ in
                        print("API Error")
                    })
                    self.present(alert, animated: true, completion: nil)
                }
            }
        }
    }
    func getImage(from imageDataString: String?) -> UIImage? {
        guard let imageDataString = imageDataString, let imageData = Data(base64Encoded: imageDataString) else {
            return nil
        }
        return UIImage(data: imageData)
    }

    func GettAPI() {
        let apiURL = APIList.UpdateDoctorApi
        print(apiURL)
        let boundary = UUID().uuidString
        var request = URLRequest(url: URL(string: apiURL)!)
        request.httpMethod = "POST"
        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
        var body = Data()
        let formData: [String: String] = [
            "id": "\(id ?? "1890")",
            "name": "\(NameTF.text ?? "email")",
            "gender": "\(GenderTF.text ?? "password")",
            "department": "\(DepartmentTF.text ?? "designation")",
            "experience": "\(ExperineceTF.text ?? "designation")",
            "contact": "\(ContactTF.text ?? "designation")"
        ]
        for (key, value) in formData {
            body.append(contentsOf: "--\(boundary)\r\n".utf8)
            body.append(contentsOf: "Content-Disposition: form-data; name=\"\(key)\"\r\n\r\n".utf8)
            body.append(contentsOf: "\(value)\r\n".utf8)
        }
        for (index, imageData) in selectedImages.enumerated() {
            if let imageData = imageToData(imageData), let image = UIImage(data: imageData) {
                let fieldName: String
                switch index {
                case 0:
                    fieldName = "profile_pic"
                default:
                    continue
                }
                body.append(contentsOf: "--\(boundary)\r\n".utf8)
                body.append(contentsOf: "Content-Disposition: form-data; name=\"\(fieldName)\"; filename=\"\(UUID().uuidString).jpg\"\r\n".utf8)
                body.append(contentsOf: "Content-Type: image/jpeg\r\n\r\n".utf8)
                body.append(contentsOf: imageData)
                body.append(contentsOf: "\r\n".utf8)
            }
        }
        body.append(contentsOf: "--\(boundary)--\r\n".utf8)
        request.httpBody = body

        let task = URLSession.shared.dataTask(with: request) { (data, response, error) in
            // Handle the response
            if let data = data {
                print("Response Data:", String(data: data, encoding: .utf8) ?? "")
            }
            if let response = response {
                print("Response:", response)
            }
            if let error = error {
                print("Error:", error.localizedDescription)
            }
        }
        task.resume()
    }

    func imageToData(_ image: UIImage) -> Data? {
        return image.jpegData(compressionQuality: 0.8)
    }

    func getImage(from imageData: PatientImageData) -> UIImage? {
        if let patientImage = imageData.DoctorImage {
            return patientImage
        } else {
            return nil
        }
    }
}
