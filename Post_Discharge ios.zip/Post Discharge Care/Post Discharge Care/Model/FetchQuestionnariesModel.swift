//
//  FetchQuestionnariesModel.swift
//  Post Discharge Care
//
//  Created by Amar on 29/01/24.
//

//import Foundation
//// MARK: - Welcome
//struct FetchQuestionnariesModel: Codable {
//    let status, message: String
//    let data: QuestionData
//}
//
//// MARK: - DataClass
//struct QuestionData: Codable {
//    let general, danger: [String]
//}



struct FetchQuestionnariesModel: Codable {
    let status, message: String
    let data: DataClass
}

// MARK: - DataClass
struct DataClass: Codable {
    let generalSymptoms, dangerSymptoms: [String]

    enum CodingKeys: String, CodingKey {
        case generalSymptoms = "General Symptoms"
        case dangerSymptoms = "Danger Symptoms"
    }
}
