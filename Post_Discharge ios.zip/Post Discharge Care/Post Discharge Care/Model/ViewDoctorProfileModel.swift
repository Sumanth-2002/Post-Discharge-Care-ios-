//
//  ViewDoctorProfileModel.swift
//  Post Discharge Care
//
//  Created by Amar on 28/01/24.
//

import Foundation

// MARK: - Welcome
struct ViewDoctorProfileModel: Codable {
    let status, message: String
    let data: [DoctorData]
}

// MARK: - Datum
struct DoctorData: Codable {
    let name, gender, department, experience: String
    let contactNumber, docProfile: String

    enum CodingKeys: String, CodingKey {
        case name = "Name"
        case gender = "Gender"
        case department = "Department"
        case experience = "Experience"
        case contactNumber = "Contact_Number"
        case docProfile = "doc_profile"
    }
}
