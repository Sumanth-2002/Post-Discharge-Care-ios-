//
//  PateintViewDischargeModel.swift
//  Post Discharge Care
//
//  Created by Amar on 02/02/24.



// This file was generated from JSON Schema using quicktype, do not modify it directly.
// To parse the JSON, add this file to your project and do:
//
//   let welcome = try? JSONDecoder().decode(Welcome.self, from: jsonData)

import Foundation

// MARK: - Welcome
struct PateintViewDischargeModel: Codable {
    let status, message, id: String
    let data: DischargeData
}

// MARK: - DataClass
struct DischargeData: Codable {
    let treatmentDetails: TreatmentDetails
    let dischargeSummary: DischargeSummary
    let courseDischarge: CourseDischarge
}

// MARK: - CourseDischarge
struct CourseDischarge: Codable {
    let courseInHospital, courseInPICU, courseInWard, adviceOnDischarge: String
    let review: String

    enum CodingKeys: String, CodingKey {
        case courseInHospital = "Course_in_Hospital"
        case courseInPICU = "Course_in_PICU"
        case courseInWard = "Course_in_Ward"
        case adviceOnDischarge = "Advice_on_Discharge"
        case review = "Review"
    }
}

// MARK: - DischargeSummary
struct DischargeSummary: Codable {
    let id, name, sex, address: String
    let department, consultant, dateOfAdmission, dateOfDischarge: String
    let diagnosis: String

    enum CodingKeys: String, CodingKey {
        case id
        case name = "Name"
        case sex = "Sex"
        case address = "Address"
        case department = "Department"
        case consultant = "Consultant"
        case dateOfAdmission = "Date_of_admission"
        case dateOfDischarge = "Date_of_Discharge"
        case diagnosis = "Diagnosis"
    }
}

// MARK: - TreatmentDetails
struct TreatmentDetails: Codable {
    let id, headToToeExamination, generalExamination, systematicExamination: String
    let treatmentGiven: String

    enum CodingKeys: String, CodingKey {
        case id
        case headToToeExamination = "Head_to_toe_examination"
        case generalExamination = "General_Examination"
        case systematicExamination = "Systematic_Examination"
        case treatmentGiven = "Treatment_given"
    }
}


