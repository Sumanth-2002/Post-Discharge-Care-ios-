//
//  ViewPatientDetailsModel.swift
//  Post Discharge Care
//
//  Created by GANESH K on 27/01/24.
//



import Foundation

// MARK: - Welcome
struct ViewPatientDetailsModel: Codable {
    let status, message: String
    let data: [PatientData]
}

// MARK: - Datum
struct PatientData: Codable {
    let id, name, contactNo, gender: String
        let dateOfBirth, height, weight, parentName: String
        let admittedOn, dischargeOn, profilePic: String

        enum CodingKeys: String, CodingKey {
            case id
            case name = "Name"
            case contactNo = "Contact_No"
            case gender = "Gender"
            case dateOfBirth = "Date_Of_Birth"
            case height = "Height"
            case weight = "Weight"
            case parentName = "Parent_Name"
            case admittedOn = "Admitted_On"
            case dischargeOn = "Discharge_On"
            case profilePic = "Profile_Pic"
        }
    }
