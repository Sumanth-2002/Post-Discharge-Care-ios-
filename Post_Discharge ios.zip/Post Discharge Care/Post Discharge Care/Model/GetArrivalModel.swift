//
//  GetArrivalModel.swift
//  Post Discharge Care
//
//  Created by Amar Dwarakacherla on 12/02/24.
//


import Foundation

// MARK: - Welcome
struct GetArrivalModel: Codable {
    let status: String
    let data: [ArrivalData]
}

// MARK: - Datum
struct ArrivalData: Codable {
    let id, name, contactNo, gender: String
    let profilePic: String

    enum CodingKeys: String, CodingKey {
        case id
        case name = "Name"
        case contactNo = "Contact_No"
        case gender = "Gender"
        case profilePic = "Profile_Pic"
    }
}
