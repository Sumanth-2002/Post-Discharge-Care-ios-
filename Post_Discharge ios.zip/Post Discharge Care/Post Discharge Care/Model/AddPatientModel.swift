//
//  AddPatientModel.swift
//  Post Discharge Care
//
//  Created by Amar on 27/01/24.
//


import Foundation

// MARK: - Welcome
struct AddPatientModel:Codable{
    var status, message: String
}
