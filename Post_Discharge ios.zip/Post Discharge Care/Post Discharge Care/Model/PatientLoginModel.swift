//
//  PatientLoginModel.swift
//  Post Discharge Care
//
//  Created by Amar on 03/01/24.
//

import Foundation
struct PatientLoginModel: Codable {
    let status: String
}
