//
//  DoctorViewPatientVCModel.swift
//  Post Discharge Care
//
//  Created by Amar on 08/01/24.
//

import Foundation
struct DoctorViewPatientVCModel: Codable {
    let status, message: String
    let data: [DashData]
}

// MARK: - Datum
struct DashData: Codable {
    let id, name, gender, contactNo: String
    let patientImg: String

    enum CodingKeys: String, CodingKey {
        case id
        case name = "Name"
        case gender = "Gender"
        case contactNo = "Contact_No"
        case patientImg = "patient_img"
    }
}
