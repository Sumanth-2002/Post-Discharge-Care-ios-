//
//  PatientArrivingModel.swift
//  Post Discharge Care
//
//  Created by Amar on 05/02/24.
//

import Foundation

// MARK: - Welcome
struct PatientArrivingModel: Codable {
    let status: String
    let data: [patientD]
}

// MARK: - Datum
struct patientD: Codable {
    let id, name, contactNo, gender: String
    let profilePic: String

    enum CodingKeys: String, CodingKey {
        case id
        case name = "Name"
        case contactNo = "Contact_No"
        case gender = "Gender"
        case profilePic = "Profile_Pic"
    }
}

