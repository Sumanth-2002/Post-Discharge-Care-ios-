
//
//  PatientReportingTimeModel.swift
//  Post Discharge Care
//
//  Created by Amar on 02/02/24.
//

import Foundation

// MARK: - Welcome
struct PatientReportingTimeModel: Codable {
    let status, message: String
    let data: [ReportData]
}

// MARK: - Datum
struct ReportData: Codable {
    let reportTime, reportDate: String

    enum CodingKeys: String, CodingKey {
        case reportTime = "report_time"
        case reportDate = "report_date"
    }
}
