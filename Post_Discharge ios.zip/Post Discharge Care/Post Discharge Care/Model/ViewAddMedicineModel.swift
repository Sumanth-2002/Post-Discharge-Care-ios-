//
//  ViewAddMedicineModel.swift
//  Post Discharge Care
//
//  Created by Amar on 02/02/24.
//


import Foundation

// MARK: - Welcome
struct ViewAddMedicineModel: Codable {
    let status, message: String
    let data: [MedData]
}

// MARK: - Datum
struct MedData: Codable {
    let id, courseName, medicineName, duration: String
    let frequency, guidelines, date: String

    enum CodingKeys: String, CodingKey {
        case id
        case courseName = "Course_Name"
        case medicineName = "Medicine_Name"
        case duration = "Duration"
        case frequency = "Frequency"
        case guidelines = "Guidelines"
        case date = "Date"
    }
}

