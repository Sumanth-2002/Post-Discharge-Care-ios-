//
//  ResponseDataModel.swift
//  Post Discharge Care
//
//  Created by Amar on 02/02/24.
//

//import Foundation
//
//// MARK: - Welcome
//struct ResponseDataModel: Codable {
//    let status, message: String
//    let data: [String: [ResponseData]]
//}
//
//
//// MARK: - Datum
//struct ResponseData: Codable {
//    let date,symptom, response: String
//}

import Foundation

// MARK: - Welcome
struct ResponseDataModel: Codable {
    let status, message: String
    let data: [ResponseData]
}

// MARK: - Datum
struct ResponseData: Codable {
    let date: String
    let resp: [Resp]
}

// MARK: - Resp
struct Resp: Codable {
    let symptom, response: String
}



