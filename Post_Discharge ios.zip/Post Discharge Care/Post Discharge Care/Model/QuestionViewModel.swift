//
//  QuestionViewModel.swift
//  Post Discharge Care
//
//  Created by Amar Dwarakacherla on 21/02/24.
//


import Foundation

// MARK: - Welcome
struct QuestionViewModel: Codable {
    let status, message: String
        let questions: [String]
    }
