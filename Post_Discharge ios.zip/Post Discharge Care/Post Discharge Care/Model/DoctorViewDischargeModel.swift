//
//  DoctorViewDischargeModel.swift
//  Post Discharge Care
//
//  Created by Amar on 01/02/24.
//

import Foundation
// MARK: - Welcome
struct DoctorViewDischargeModel: Codable {
    let status, message, id: String
    let data: ViewData
}

// MARK: - DataClass
struct ViewData: Codable {
    let chiefComplaints: ChiefComplaints
    let vitalsAtAdmission: VitalsAtAdmission
    let immunizationHistory: ImmunizationHistory
    let developmentHistory: DevelopmentHistory
    let historyIllness: HistoryIllness
    let treatment: Treatment
    let courseDis: CourseDis

    enum CodingKeys: String, CodingKey {
        case chiefComplaints = "chief_complaints"
        case vitalsAtAdmission = "vitals_at_admission"
        case immunizationHistory = "immunization_history"
        case developmentHistory = "development_history"
        case historyIllness = "history_illness"
        case treatment
        case courseDis = "course_dis"
    }
}

// MARK: - ChiefComplaints
struct ChiefComplaints: Codable {
    let id, chiefComplaints: String

    enum CodingKeys: String, CodingKey {
        case id
        case chiefComplaints = "chief_complaints"
    }
}

// MARK: - CourseDis
struct CourseDis: Codable {
    let id: Int
    let courseInHospital, courseInPICU, courseInWard, adviceOnDischarge: String
    let review: String

    enum CodingKeys: String, CodingKey {
        case id
        case courseInHospital = "Course_in_Hospital"
        case courseInPICU = "Course_in_PICU"
        case courseInWard = "Course_in_Ward"
        case adviceOnDischarge = "Advice_on_Discharge"
        case review = "Review"
    }
}

// MARK: - DevelopmentHistory
struct DevelopmentHistory: Codable {
    let id, grossMotor, fineMotor, language: String
    let socialAndCognition: String

    enum CodingKeys: String, CodingKey {
        case id
        case grossMotor = "Gross_Motor"
        case fineMotor = "Fine_Motor"
        case language = "Language"
        case socialAndCognition = "Social_and_Cognition"
    }
}

// MARK: - HistoryIllness
struct HistoryIllness: Codable {
    let id, illness, pastHistory, antennalHistory: String
    let natalHistory, postnatalHistory: String

    enum CodingKeys: String, CodingKey {
        case id, illness
        case pastHistory = "Past_history"
        case antennalHistory = "Antennal_history"
        case natalHistory = "Natal_history"
        case postnatalHistory = "Postnatal_history"
    }
}

// MARK: - ImmunizationHistory
struct ImmunizationHistory: Codable {
    let id, history, anthropometry, weightt: String
    let height: String

    enum CodingKeys: String, CodingKey {
        case id, history
        case anthropometry = "Anthropometry"
        case weightt, height
    }
}

// MARK: - Treatment
struct Treatment: Codable {
    let id, headToToeExamination, generalExamination, systematicExamination: String
    let treatmentGiven: String

    enum CodingKeys: String, CodingKey {
        case id
        case headToToeExamination = "Head_to_toe_examination"
        case generalExamination = "General_Examination"
        case systematicExamination = "Systematic_Examination"
        case treatmentGiven = "Treatment_given"
    }
}

// MARK: - VitalsAtAdmission
struct VitalsAtAdmission: Codable {
    let id, heartRate, temperature, crt: String
    let rr, spo2: String

    enum CodingKeys: String, CodingKey {
        case id
        case heartRate = "Heart_rate"
        case temperature = "Temperature"
        case crt = "CRT"
        case rr = "RR"
        case spo2 = "SPO2"
    }
}

