//
//  ViewImageModel.swift
//  Post Discharge Care
//
//  Created by Amar on 05/02/24.
//

//import Foundation
//
//// MARK: - Welcome
//struct ViewImageModel: Codable {
//    let status, message: String
//    let data: [ImageData]
//}
//// MARK: - Datum
//struct ImageData: Codable {
//    let patientImg: String
//    enum CodingKeys: String, CodingKey {
//        case patientImg = "patient_img"
//    }
//}


import Foundation

// MARK: - Welcome
struct ViewImageModel: Codable {
    let status, message: String
    let images: [String]
}


