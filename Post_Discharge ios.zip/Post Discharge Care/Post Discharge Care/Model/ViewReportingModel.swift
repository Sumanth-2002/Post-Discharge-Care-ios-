//
//  ViewReportingModel.swift
//  Post Discharge Care
//
//  Created by Amar on 01/02/24.
//


import Foundation

// MARK: - Welcome
struct ViewReportingModel: Codable {
    let status, message: String
    let data: [ReportingData]
}

// MARK: - Datum
struct ReportingData: Codable {
    let reportTime, reportDate: String

    enum CodingKeys: String, CodingKey {
        case reportTime = "report_time"
        case reportDate = "report_date"
    }
}
