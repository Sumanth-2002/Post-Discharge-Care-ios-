import UIKit

class AddPatientReportTimeVC: UIViewController {
    @IBOutlet weak var calenderView: UIView!
    var id: String?
    var body = Data()
    var d1:String?
//    var Date : String?

    @IBOutlet weak var TimeTF: UITextField!
    let datePicker: UIDatePicker = UIDatePicker()

    override func viewDidLoad() {
        super.viewDidLoad()
        showDatePicker(tag: 0)
    }
    @IBAction func BackButton(_ sender: Any) {
        for controller in self.navigationController!.viewControllers as Array {
                    if controller.isKind(of: AddPatientNextVC.self) {
                        self.navigationController!.popToViewController(controller, animated: true)
                        break
                    }
                }
//        let storyboard = UIStoryboard(name: "Main", bundle: nil)
//        let VC = storyboard.instantiateViewController(withIdentifier: "AddPatientMedicationVC") as! AddPatientMedicationVC
//        navigationController?.pushViewController(VC, animated: true)
//        VC.id = id
    }
    func showDatePicker(tag: Int) {
        // Format Date
        datePicker.datePickerMode = .date
        if #available(iOS 13.4, *) {
            datePicker.preferredDatePickerStyle = .inline
        } else {
            datePicker.preferredDatePickerStyle = .wheels
        }
        // Set minimumDate to the current date
        datePicker.minimumDate = Date()

        let toolbar = UIToolbar()
        toolbar.sizeToFit()

        // done button & cancel button
        let doneButton = UIBarButtonItem(title: "Add Reporting Date", style: .done, target: self, action: #selector(self.donedatePicker(_:)))
        doneButton.tag = tag
        let spaceButton = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)

        toolbar.setItems([spaceButton, doneButton], animated: false)
        // Add the datePicker to the view
        view.addSubview(datePicker)
        view.addSubview(toolbar)
        // Add constraints or frame as needed
        datePicker.translatesAutoresizingMaskIntoConstraints = false
        toolbar.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            // Adjust the constraints as per your layout requirements
            datePicker.topAnchor.constraint(equalTo: calenderView.topAnchor),
            datePicker.leadingAnchor.constraint(equalTo: calenderView.leadingAnchor),
            datePicker.trailingAnchor.constraint(equalTo: calenderView.trailingAnchor),
            datePicker.bottomAnchor.constraint(equalTo: calenderView.bottomAnchor, constant: -10),
            toolbar.topAnchor.constraint(equalTo: datePicker.bottomAnchor),
            toolbar.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            toolbar.trailingAnchor.constraint(equalTo: view.trailingAnchor),
        ])
    }
    @objc func donedatePicker(_ sender: UIButton) {
        let formatter = DateFormatter()
        formatter.dateFormat = "dd-MM-YYYY"
        let date = formatter.string(from: datePicker.date)
        d1=date
        GetAPI()
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "AddPatientNextVC") as! AddPatientNextVC
        navigationController?.pushViewController(vc, animated: true)
//        vc.date = date
    }
}


extension AddPatientReportTimeVC {
    func GetAPI() {
        let apiURL = APIList.AddReportTimeApi
        print(apiURL)
        let boundary = UUID().uuidString
        var request = URLRequest(url: URL(string: apiURL)!)
        request.httpMethod = "POST"
        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
            // Update formData to include the password
            var formData: [String: String] = [
                "id": "\(id ?? "123456789")",
                "count": "\(TimeTF.text ?? "Error")",
                "date": "\(d1 ?? "Error")"
            ]
        for (key, value) in formData {
            body.append(contentsOf: "--\(boundary)\r\n".utf8)
            body.append(contentsOf: "Content-Disposition: form-data; name=\"\(key)\"\r\n\r\n".utf8)
            body.append(contentsOf: "\(value)\r\n".utf8)
        }
        body.append(contentsOf: "--\(boundary)--\r\n".utf8) // Close the request body
        request.httpBody = body
        let task = URLSession.shared.dataTask(with: request) { (data, response, error) in
            if let error = error {
                print("Error: \(error)")
                // Handle the error, e.g., show an alert to the user
                return
            }
            if let httpResponse = response as? HTTPURLResponse {
                print("Status code: \(httpResponse.statusCode)")

                if let data = data {
                    print("Response Data:", String(data: data, encoding: .utf8) ?? "")
                }
            }
        }
        task.resume()
    }
}




