//
//  ViewImageVC.swift
//  Post Discharge Care
//
//  Created by Amar on 05/02/24.
//

import UIKit

class ViewImageVC: UIViewController {
    var id: String?
    var viewImage: ViewImageModel?
    @IBOutlet weak var viewImageView: UIImageView! // Change the type to UIImageView
    var body = Data()
    @IBOutlet weak var Imagetableview: UITableView!{
        didSet{
            Imagetableview.delegate = self
            Imagetableview.dataSource = self
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.isNavigationBarHidden = true
        PostAPI()
    }

    @IBAction func BackButton(_ sender: Any) {
        navigationController?.popViewController(animated: true)
        
    }
    func PostAPI() {
        let apiURL = APIList.ImagesApi
        print(apiURL)
        
        // Prepare POST parameters
        let parameters: [String: String] = [
            "id": id ?? "143"
        ]

        APIHandler().postAPIValues(type: ViewImageModel.self, apiUrl: apiURL, method: "POST", formData: parameters) { result in
            switch result {
            case .success(let data):
                DispatchQueue.main.async {
                    // Handle the success response here
                    self.viewImage = data
                    self.Imagetableview.reloadData()
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async {
                    // Handle the failure response here
                    let alert = UIAlertController(title: "Warning", message: "Something Went Wrong", preferredStyle: .alert)
                    alert.addAction(UIAlertAction(title: "Ok", style: .destructive) { _ in
                        print("API Error")
                    })
                    self.present(alert, animated: true, completion: nil)
                }
            }
        }
    }

    func getImage(from imageDataString: String?) -> UIImage? {
        guard let imageDataString = imageDataString, let imageData = Data(base64Encoded: imageDataString) else {
            return nil
        }
        return UIImage(data: imageData)
    }
}
extension ViewImageVC: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewImage?.images.count ?? 0
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            let cell = tableView.dequeueReusableCell(withIdentifier: "ImageViewcell", for: indexPath) as! ImageViewcell
            
            if let imageData = viewImage?.images, indexPath.row < imageData.count {
                let dataForRow = imageData[indexPath.row]
                cell.ShowImage.image = getImage(from: imageData[indexPath.row])
                
            }
            
            return cell
    }
    public func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
        
    }
}
