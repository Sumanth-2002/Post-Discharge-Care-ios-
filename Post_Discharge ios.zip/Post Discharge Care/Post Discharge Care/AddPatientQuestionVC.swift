//
//  AddPatientQuestionVC.swift
//  Post Discharge Care
//
//  Created by Amar on 09/01/24.
//

import UIKit

class AddPatientQuestionVC: UIViewController {

    var id: String?
    var body = Data()
    @IBOutlet weak var GSq1TF: UITextField!
    @IBOutlet weak var GSq2TF: UITextField!
    @IBOutlet weak var GSq3TF: UITextField!
    @IBOutlet weak var GSq4TF: UITextField!
    @IBOutlet weak var GSq5TF: UITextField!
    @IBOutlet weak var DSq1TF: UITextField!
    @IBOutlet weak var DSq2TF: UITextField!
    @IBOutlet weak var DSq3TF: UITextField!
    @IBOutlet weak var DSq4TF: UITextField!
    @IBOutlet weak var DSq5TF: UITextField!
    @IBOutlet weak var DSq6TF: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBAction func BackButton(_ sender: Any) {
//        navigationController?.popViewController(animated: true)
        for controller in self.navigationController!.viewControllers as Array {
                    if controller.isKind(of: AddPatientNextVC.self) {
                        self.navigationController!.popToViewController(controller, animated: true)
                        break
                    }
                }
//        let storyboard = UIStoryboard(name: "Main", bundle: nil)
//        let VC = storyboard.instantiateViewController(withIdentifier: "AddPatientNextVC") as! AddPatientNextVC
//        navigationController?.pushViewController(VC, animated: true)
//        VC.id = id
        
    }
    
    @IBAction func SaveButton(_ sender: Any) {
        GetAPI()
//        navigationController?.popViewController(animated: true)
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let VC = storyboard.instantiateViewController(withIdentifier: "AddPatientNextVC") as! AddPatientNextVC
        navigationController?.pushViewController(VC, animated: true)
        VC.id = id
    }
    
    
}
extension AddPatientQuestionVC {
    func GetAPI() {
        let apiURL = APIList.AddQuestionnariesApi
        print(apiURL)

        let boundary = UUID().uuidString
        var request = URLRequest(url: URL(string: apiURL)!)
        request.httpMethod = "POST"
        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
            // Update formData to include the password
            var formData: [String: String] = [
                "id": "\(id ?? "123456789")",
                "text1": "\(GSq1TF.text ?? "Error")",
                "text2": "\(GSq2TF.text ?? "Error")",
                "text3": "\(GSq3TF.text ?? "Error")",
                "text4": "\(GSq4TF.text ?? "Error")",
                "text5": "\(GSq5TF.text ?? "Error")",
                "text6": "\(DSq1TF.text ?? "Error")",
                "text7": "\(DSq2TF.text ?? "Error")",
                "text8": "\(DSq3TF.text ?? "Error")",
                "text9": "\(DSq4TF.text ?? "Error")",
                "text10": "\(DSq6TF.text ?? "Error")",
                "text11": "\(DSq6TF.text ?? "Error")"
            ]
        for (key, value) in formData {
            body.append(contentsOf: "--\(boundary)\r\n".utf8)
            body.append(contentsOf: "Content-Disposition: form-data; name=\"\(key)\"\r\n\r\n".utf8)
            body.append(contentsOf: "\(value)\r\n".utf8)
        }
        body.append(contentsOf: "--\(boundary)--\r\n".utf8) // Close the request body
        request.httpBody = body
        let task = URLSession.shared.dataTask(with: request) { (data, response, error) in
            if let error = error {
                print("Error: \(error)")
                // Handle the error, e.g., show an alert to the user
                return
            }
            if let httpResponse = response as? HTTPURLResponse {
                print("Status code: \(httpResponse.statusCode)")

                if let data = data {
                    print("Response Data:", String(data: data, encoding: .utf8) ?? "")
                    // You can perform further processing here
                }
            }
        }
        task.resume()
    }
}


