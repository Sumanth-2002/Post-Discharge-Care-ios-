//
//  DoctorPatientMediceneVC.swift
//  Post Discharge Care
//
//  Created by Amar on 01/02/24.
//


import UIKit

class DoctorPatientMediceneVC: UIViewController {
    @IBOutlet weak var MedicineLabel: UITextView!
    @IBOutlet weak var DurationLabel: UITextView!
    @IBOutlet weak var FrequencyLabel: UITextView!
    @IBOutlet weak var GuidelineLabel: UITextView!

    var id: String?
    var Courseid: String?
    var Course: PateintCourseModel!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Call the GetAPI function to initiate the API request
        GetAPI()
    }
    @IBAction func BackButton(_ sender: Any) {
        for controller in self.navigationController!.viewControllers as Array {
                    if controller.isKind(of: DoctorPatientCouseList.self) {
                        self.navigationController!.popToViewController(controller, animated: true)
                        break
                    }
                }
//        let storyboard = UIStoryboard(name: "Main", bundle: nil)
//        let VC = storyboard.instantiateViewController(withIdentifier: "DoctorPatientCouseList") as! DoctorPatientCouseList
//        navigationController?.pushViewController(VC, animated: true)
//        VC.id = id
    }
    @IBAction func UpdateButton(_ sender: Any) {
        postAPI()
    }
    @IBAction func DeleteButton(_ sender: Any) {
        
    }
}

extension DoctorPatientMediceneVC {
    func GetAPI() {
        let apiURL = APIList.GetMedicineApi
        print(apiURL)
        // Prepare POST parameters if needed
        let parameters: [String: Any] = [
            "id": id ?? "123",
            "Course_Name": Courseid ?? "2"
            // Add your POST parameters here if required
            // "key1": value1,
        ]
        APIHandler().postAPIValues(type: PateintCourseModel.self, apiUrl: apiURL, method: "POST", formData: parameters) { result in
            switch result {
            case .success(let data):
                DispatchQueue.main.async {
                    self.Course = data
                    if let courseData = self.Course?.data.first {
                        // Assign values to your labels based on the retrieved data
                        self.MedicineLabel.text = courseData.medicineName
                        self.DurationLabel.text = courseData.duration
                        self.FrequencyLabel.text = courseData.frequency
                        self.GuidelineLabel.text = courseData.guidelines
                    } else {
                        print("Error loading")
                    }
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async {
                    let alert = UIAlertController(title: "Warning", message: "Something Went Wrong", preferredStyle: .alert)
                    alert.addAction(UIAlertAction(title: "Ok", style: .destructive) { _ in
                        print("API Error")
                    })
                    self.present(alert, animated: true, completion: nil)
                }
            }
        }
    }
    func postAPI() {
            // Prepare POST parameters if needed
            let parameters: [String: Any] = [
                "id": id ?? "18911  ",
                "Course_Name": Courseid ?? "dasd",
                "Date": "",
                "Medicine_Name": MedicineLabel.text ?? "",
                "Duration": DurationLabel.text ?? "",
                "Frequency": FrequencyLabel.text ?? "",
                "Guidelines": GuidelineLabel.text ?? ""
            ]
        let boundary = "Boundary-\(UUID().uuidString)"
            
            // Construct the request
            var request = URLRequest(url: URL(string: APIList.UpdateGetMedicineApi)!)
            request.httpMethod = "POST"
            request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
            
            // Construct the body of the request
            var body = Data()
            for (key, value) in parameters {
                body.append("--\(boundary)\r\n".data(using: .utf8)!)
                body.append("Content-Disposition: form-data; name=\"\(key)\"\r\n\r\n".data(using: .utf8)!)
                body.append("\(value)\r\n".data(using: .utf8)!)
            }
            
            // Finalize the body with boundary
            body.append("--\(boundary)--\r\n".data(using: .utf8)!)
            
            // Attach the body to the request
            request.httpBody = body
            
            // Perform the request
            let task = URLSession.shared.dataTask(with: request) { (data, response, error) in
                if let error = error {
                    print("Error: \(error)")
                    return
                }
                if let httpResponse = response as? HTTPURLResponse {
                    print("Status code: \(httpResponse.statusCode)")
                    
                    if let data = data {
                        print("Response Data:", String(data: data, encoding: .utf8) ?? "")
                        // You can perform further processing here
                    }
                }
            }
            task.resume()
        }
}

