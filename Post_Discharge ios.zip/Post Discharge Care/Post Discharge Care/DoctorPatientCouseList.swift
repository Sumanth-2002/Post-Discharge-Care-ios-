//
//  DoctorPatientCouseList.swift


import UIKit
class DoctorPatientCouseList: UIViewController {

    var id: String?
    var Courseid: String?
    var Course: PateintCourseModel!
    @IBOutlet weak var tableview: UITableView!{
        didSet{
            tableview.delegate = self
            tableview.dataSource = self
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        GetAPI()
        
    }
    func GetAPI() {
        let apiURL = APIList.CourseApi
        print(apiURL)
        // Prepare POST parameters if needed
        let parameters: [String: String] = [
            "id": id ?? "123"
            
            // "key1": value1,
        ]

        APIHandler().postAPIValues(type: PateintCourseModel.self, apiUrl: apiURL, method: "POST", formData: parameters) { result in
            switch result {
            case .success(let data):
                DispatchQueue.main.async {
                self.Course = data
                    self.tableview.reloadData()
                }
            case .failure(let error):
                print(error)
            }
        }
    }
    @IBAction func Add(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let VC = storyboard.instantiateViewController(withIdentifier: "AddpatinetMedicineVC") as! AddpatinetMedicineVC
        navigationController?.pushViewController(VC, animated: true)
        VC.id = id
    }
    @IBAction func BackButton(_ sender: Any) {
//        self.navigationController?.popViewController(animated: true)
        for controller in self.navigationController!.viewControllers as Array {
                    if controller.isKind(of: DViewPatientVC.self) {
                        self.navigationController!.popToViewController(controller, animated: true)
                        break
                    }
                }
        
    }
}
extension DoctorPatientCouseList: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return Course?.data.count ?? 0
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if let data = Course?.data, indexPath.row < data.count {
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "DoctorPatientMediceneVC") as! DoctorPatientMediceneVC
            vc.id = data[indexPath.row].id
            vc.Courseid = data[indexPath.row].courseName
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "DoctorPatientCouseListCell", for: indexPath) as! DoctorPatientCouseListCell

        if let data = Course?.data, indexPath.row < data.count {
            cell.CourseLabel.text = data[indexPath.row].courseName
        } else {
            cell.CourseLabel.text = "N/A"
        }

        return cell
    }
}

