//
//  VCcell.swift
//  Post Discharge Care
//
//  Created by Amar on 02/01/24.
//

import UIKit

class VCcell: UICollectionViewCell {
    
    
}
