//
//  Constant.swift
//  WeatherApp
//
//  Created by MAC-Air on 08/09/23.
//

import Foundation
import UIKit




struct APIList{
    static var ipAddress = "http://localhost/PostD/"
    static var DoctorLogInURL = ipAddress+"doctor_login.php"
    static var PatientLogInURL = ipAddress+"login.php"
    static var dashURL = ipAddress+"searchid.php"
    static var ViewPatientApi = ipAddress+"fetch.php"
    static var UpdateViewPatientApi = ipAddress+"fetch_update.php"
    static var AddPatientApi = ipAddress+"insert_patient.php"
    static var ViewDoctorApi = ipAddress+"get_doctorProfile.php"
    static var UpdateDoctorApi = ipAddress+"update_doctor_profile.php"
    static var AddQuestionnariesApi = ipAddress+"questionnaire.php"
    static var AddmedicineApi = ipAddress+"insert_medicine.php"
    static var AddReportTimeApi = ipAddress+"add_report.php"
    static var FetchQuestionApi = ipAddress+"get_questionnaire.php"
    static var QuestionResponseApi = ipAddress+"questionnaire_response.php"
    static var CourseApi = ipAddress+"get_course_data.php"
    static var GetMedicineApi = ipAddress+"get_medicine.php"
    static var UpdateGetMedicineApi = ipAddress+"get_medicine_update.php"
    static var AddDischargeApi = ipAddress+"tra.php"
    static var UpdateDischargeApi = ipAddress+"trash.php"
    static var ViewDoctorDischargeApi = ipAddress+"get_docDischarge.php"
    static var ViewReportTimeApi = ipAddress+"get_reportTime.php"
    static var ViewQuestionResponseApi = ipAddress+"get_responses.php"
    static var patientViewDischargeApi = ipAddress+"get_discharge.php"
    static var viewAddMedicineApi = ipAddress+"getAddMedicine.php"
    static var viewImageApi = ipAddress+"view_images.php"
    static var patientArrivalApi = ipAddress+"get_patientArrivingToday.php"
    static var ImagesApi = ipAddress+"Amar_image.php"
    static var QuesViewApi = ipAddress+"questionnaire_view.php"
}

