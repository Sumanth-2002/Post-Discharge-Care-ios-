//
//  DischargeSummaryVC.swift
//  Post Discharge Care
//
//  Created by SAIL on 23/01/24.
//

import UIKit

class DischargeSummaryVC: UIViewController {
    
    @IBOutlet weak var pid: UILabel!
    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var gender: UILabel!
    @IBOutlet weak var department: UILabel!
    @IBOutlet weak var consultant: UILabel!
    @IBOutlet weak var address: UILabel!
    @IBOutlet weak var admitted: UILabel!
    @IBOutlet weak var discharge: UILabel!
    @IBOutlet weak var disease: UILabel!
    @IBOutlet weak var treatmetn: UILabel!
    @IBOutlet weak var hospital: UILabel!
    @IBOutlet weak var picu: UILabel!
    @IBOutlet weak var ward: UILabel!
    @IBOutlet weak var advice: UILabel!
    @IBOutlet weak var review: UILabel!
    var id: String?
    var Discharge: PateintViewDischargeModel!
    override func viewDidLoad() {
        super.viewDidLoad()

        GetAPI()
    }
    @IBAction func BackButton(_ sender: Any) {
        navigationController?.popViewController(animated: true)
        
        
    }
    @IBAction func ImageButton(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let VC = storyboard.instantiateViewController(withIdentifier: "ViewImageVC") as! ViewImageVC
        navigationController?.pushViewController(VC, animated: true)
        VC.id = self.id
        
    }
}
extension DischargeSummaryVC {
    func GetAPI() {
        let apiURL = APIList.patientViewDischargeApi
        print(apiURL)
        // Prepare POST parameters if needed
        let parameters: [String: Any] = [
            "id": id ?? "12234",
            // "key1": value1,
        ]

        APIHandler().postAPIValues(type: PateintViewDischargeModel.self, apiUrl: apiURL, method: "POST", formData: parameters) { result in
            switch result {
            case .success(let data):
                DispatchQueue.main.async {
                    self.Discharge = data
                    if let courseData = self.Discharge?.data{
                        self.pid.text = courseData.dischargeSummary.id
                        self.name.text = courseData.dischargeSummary.name
                        self.gender.text = courseData.dischargeSummary.sex
                        self.department.text = courseData.dischargeSummary.department
                        self.consultant.text = courseData.dischargeSummary.consultant
                        self.address.text = courseData.dischargeSummary.address
                        self.admitted.text = courseData.dischargeSummary.dateOfAdmission
                        self.discharge.text = courseData.dischargeSummary.dateOfDischarge
                        self.disease.text = courseData.dischargeSummary.diagnosis
                        self.treatmetn.text = courseData.courseDischarge.courseInHospital
                        self.hospital.text = courseData.courseDischarge.courseInHospital
                        
                        self.picu.text = courseData.courseDischarge.courseInPICU
                        self.ward.text = courseData.courseDischarge.courseInWard
                        self.advice.text = courseData.courseDischarge.adviceOnDischarge
                        self.review.text = courseData.courseDischarge.review
                        
                    } else {
                        print("Error loading")
                    }
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async {
                    let alert = UIAlertController(title: "Warning", message: "Something Went Wrong", preferredStyle: .alert)
                    alert.addAction(UIAlertAction(title: "Ok", style: .destructive) { _ in
                        print("API Error")
                    })
                    self.present(alert, animated: true, completion: nil)
                }
            }
        }
    }
}

