//
//  ImageViewcell.swift
//  Post Discharge Care
//
//  Created by Amar Dwarakacherla on 19/02/24.
//

import UIKit

class ImageViewcell: UITableViewCell {

    @IBOutlet weak var ShowImage: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
