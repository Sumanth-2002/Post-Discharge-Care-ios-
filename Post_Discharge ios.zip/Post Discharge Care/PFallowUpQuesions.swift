//
//  PFallowUpQuesions.swift
//  Post Discharge Care
//
//  Created by SAIL on 23/01/24.
//

import UIKit

class PFallowUpQuesions: UIViewController {
    var d1: String?
    var Q1op: String?
    var Q2op: String?
    var Q3op: String?
    var Q4op: String?
    var Q5op: String?
    var Q6op: String?
    var Q7op: String?
    var Q8op: String?
    var Q9op: String?
    var Q10op: String?
    var Q11op: String?
    var id: String?
    var body = Data()
    @IBOutlet weak var DateLabel: UILabel!
    
    
    var Question: FetchQuestionnariesModel?
    @IBOutlet weak var q1: UILabel!
    @IBOutlet weak var q2: UILabel!
    @IBOutlet weak var q3: UILabel!
    @IBOutlet weak var q4: UILabel!
    @IBOutlet weak var q5: UILabel!
    
    @IBOutlet weak var q6: UILabel!
    @IBOutlet weak var q7: UILabel!
    @IBOutlet weak var q8: UILabel!
    @IBOutlet weak var q9: UILabel!
    @IBOutlet weak var q10: UILabel!
    @IBOutlet weak var q11: UILabel!
    
    
    
    @IBOutlet weak var Q1opt1: UIButton!
    @IBOutlet weak var Q1opt2: UIButton!
    
    @IBOutlet weak var Q2opt1: UIButton!
    @IBOutlet weak var Q2opt2: UIButton!
    
    @IBOutlet weak var Q3opt1: UIButton!
    @IBOutlet weak var Q3opt2: UIButton!
    
    @IBOutlet weak var Q4opt1: UIButton!
    @IBOutlet weak var Q4opt2: UIButton!
    
    @IBOutlet weak var Q5opt1: UIButton!
    @IBOutlet weak var Q5opt2: UIButton!
    
    @IBOutlet weak var Q6opt1: UIButton!
    @IBOutlet weak var Q6opt2: UIButton!
    
    @IBOutlet weak var Q7opt1: UIButton!
    @IBOutlet weak var Q7opt2: UIButton!
    
    @IBOutlet weak var Q8opt1: UIButton!
    @IBOutlet weak var Q8opt2: UIButton!
    
    @IBOutlet weak var Q9opt1: UIButton!
    @IBOutlet weak var Q9opt2: UIButton!
    
    @IBOutlet weak var Q10opt1: UIButton!
    @IBOutlet weak var Q10opt2: UIButton!
    
    @IBOutlet weak var Q11opt1: UIButton!
    @IBOutlet weak var Q11opt2: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print(d1 ?? "")
//        print(Q1op ?? "")
        GetAPI()
        DateLabel.text = d1
        
        
    }
    @IBAction func Q1opt1Action(_ sender: UIButton) {
        if sender.isSelected{
            sender.isSelected = false
            Q1opt2.isSelected = false
        }
        else
        {
            sender.isSelected = true
            Q1opt2.isSelected = false
        }
    }
    @IBAction func Q1opt2Action(_ sender: UIButton) {
        if sender.isSelected{
            sender.isSelected = false;
            Q1opt1.isSelected = false;
        }
        else
        {
            sender.isSelected = true;
            Q1opt1.isSelected = false;
        }
    }
    
    @IBAction func Q2opt1Action(_ sender: UIButton) {
        if sender.isSelected{
            sender.isSelected = false
            Q2opt2.isSelected = false
        }
        else
        {
            sender.isSelected = true
            Q2opt2.isSelected = false
        }
    }
    @IBAction func Q2opt2Action(_ sender: UIButton) {
        if sender.isSelected{
            sender.isSelected = false;
            Q2opt1.isSelected = false;
        }
        else
        {
            sender.isSelected = true;
            Q2opt1.isSelected = false;
        }
    }
    
    @IBAction func Q3opt1Action(_ sender: UIButton) {
        if sender.isSelected{
            sender.isSelected = false
            Q3opt2.isSelected = false
        }
        else
        {
            sender.isSelected = true
            Q3opt2.isSelected = false
        }
    }
    @IBAction func Q3opt2Action(_ sender: UIButton) {
        if sender.isSelected{
            sender.isSelected = false;
            Q3opt1.isSelected = false;
        }
        else
        {
            sender.isSelected = true;
            Q3opt1.isSelected = false;
        }
    }
    
    @IBAction func Q4opt1Action(_ sender: UIButton) {
        if sender.isSelected{
            sender.isSelected = false
            Q4opt2.isSelected = false
        }
        else
        {
            sender.isSelected = true
            Q4opt2.isSelected = false
        }
    }
    @IBAction func Q4opt2Action(_ sender: UIButton) {
        if sender.isSelected{
            sender.isSelected = false;
            Q4opt1.isSelected = false;
        }
        else
        {
            sender.isSelected = true;
            Q4opt1.isSelected = false;
        }
    }
    
    @IBAction func Q5opt1Action(_ sender: UIButton) {
        if sender.isSelected{
            sender.isSelected = false
            Q5opt2.isSelected = false
        }
        else
        {
            sender.isSelected = true
            Q5opt2.isSelected = false
        }
    }
    @IBAction func Q5opt2Action(_ sender: UIButton) {
        if sender.isSelected{
            sender.isSelected = false;
            Q5opt1.isSelected = false;
        }
        else
        {
            sender.isSelected = true;
            Q5opt1.isSelected = false;
        }
    }
    @IBAction func Q6opt1Action(_ sender: UIButton) {
        if sender.isSelected{
            sender.isSelected = false
            Q6opt2.isSelected = false
        }
        else
        {
            sender.isSelected = true
            Q6opt2.isSelected = false
        }
    }
    @IBAction func Q6opt2Action(_ sender: UIButton) {
        if sender.isSelected{
            sender.isSelected = false;
            Q6opt1.isSelected = false;
        }
        else
        {
            sender.isSelected = true;
            Q6opt1.isSelected = false;
        }
    }
    @IBAction func Q7opt1Action(_ sender: UIButton) {
        if sender.isSelected{
            sender.isSelected = false
            Q7opt2.isSelected = false
        }
        else
        {
            sender.isSelected = true
            Q7opt2.isSelected = false
        }
    }
    @IBAction func Q7opt2Action(_ sender: UIButton) {
        if sender.isSelected{
            sender.isSelected = false;
            Q7opt1.isSelected = false;
        }
        else
        {
            sender.isSelected = true;
            Q7opt1.isSelected = false;
        }
    }
    @IBAction func Q8opt1Action(_ sender: UIButton) {
        if sender.isSelected{
            sender.isSelected = false
            Q8opt2.isSelected = false
        }
        else
        {
            sender.isSelected = true
            Q8opt2.isSelected = false
        }
    }
    @IBAction func Q8opt2Action(_ sender: UIButton) {
        if sender.isSelected{
            sender.isSelected = false;
            Q8opt1.isSelected = false;
        }
        else
        {
            sender.isSelected = true;
            Q8opt1.isSelected = false;
        }
    }
    @IBAction func Q9opt1Action(_ sender: UIButton) {
        if sender.isSelected{
            sender.isSelected = false
            Q9opt2.isSelected = false
        }
        else
        {
            sender.isSelected = true
            Q9opt2.isSelected = false
        }
    }
    @IBAction func Q9opt2Action(_ sender: UIButton) {
        if sender.isSelected{
            sender.isSelected = false;
            Q9opt1.isSelected = false;
        }
        else
        {
            sender.isSelected = true;
            Q9opt1.isSelected = false;
        }
    }
    @IBAction func Q10opt1Action(_ sender: UIButton) {
        if sender.isSelected{
            sender.isSelected = false
            Q10opt2.isSelected = false
        }
        else
        {
            sender.isSelected = true
            Q10opt2.isSelected = false
        }
    }
    @IBAction func Q10opt2Action(_ sender: UIButton) {
        if sender.isSelected{
            sender.isSelected = false;
            Q10opt1.isSelected = false;
        }
        else
        {
            sender.isSelected = true;
            Q10opt1.isSelected = false;
        }
    }
    @IBAction func Q11opt1Action(_ sender: UIButton) {
        if sender.isSelected{
            sender.isSelected = false
            Q11opt2.isSelected = false
        }
        else
        {
            sender.isSelected = true
            Q11opt2.isSelected = false
        }
    }
    @IBAction func Q11opt2Action(_ sender: UIButton) {
        if sender.isSelected{
            sender.isSelected = false;
            Q11opt1.isSelected = false;
        }
        else
        {
            sender.isSelected = true;
            Q11opt1.isSelected = false;
        }
    }



    @IBAction func SaveButton(_ sender: Any) {
        print("SaveButton pressed")
            print(d1 ?? "")
        Q1op = Q1opt1.isSelected ? "Yes" : (Q1opt2.isSelected ? "No" : "")
        Q2op = Q2opt1.isSelected ? "Yes" : (Q2opt2.isSelected ? "No" : "")
            Q3op = Q3opt1.isSelected ? "Yes" : (Q3opt2.isSelected ? "No" : "")
            Q4op = Q4opt1.isSelected ? "Yes" : (Q4opt2.isSelected ? "No" : "")
            Q5op = Q5opt1.isSelected ? "Yes" : (Q5opt2.isSelected ? "No" : "")
            Q6op = Q6opt1.isSelected ? "Yes" : (Q6opt2.isSelected ? "No" : "")
            Q7op = Q7opt1.isSelected ? "Yes" : (Q7opt2.isSelected ? "No" : "")
            Q8op = Q8opt1.isSelected ? "Yes" : (Q8opt2.isSelected ? "No" : "")
            Q9op = Q9opt1.isSelected ? "Yes" : (Q9opt2.isSelected ? "No" : "")
            Q10op = Q10opt1.isSelected ? "Yes" : (Q10opt2.isSelected ? "No" : "")
            Q11op = Q11opt1.isSelected ? "Yes" : (Q11opt2.isSelected ? "No" : "")
        PostAPI()
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
                let VC = storyboard.instantiateViewController(withIdentifier: "PatientDashboardVC") as! PatientDashboardVC
                navigationController?.pushViewController(VC, animated: true)
                VC.id = id
        
    }
    @IBAction func back(_ sender: Any) {
        for controller in self.navigationController!.viewControllers as Array {
                    if controller.isKind(of: PFallowUp.self) {
                        self.navigationController!.popToViewController(controller, animated: true)
                        break
                    }
                }
        
    }
}
extension PFallowUpQuesions{
    func GetAPI() {
        let apiURL = APIList.FetchQuestionApi
        print(apiURL)
        // Prepare POST parameters if needed
        let parameters: [String: Any] = [
            "id" : id ?? "12234"
                                            // Add your POST parameters here if required
                                         // "key1": value1,
                                         // "key2": value2,
        ]
        APIHandler().postAPIValues(type: FetchQuestionnariesModel.self, apiUrl: apiURL, method: "POST", formData: parameters) { result in
            switch result {
            case .success(let data):
                DispatchQueue.main.async {
                    self.Question = data
                    if let QuesionData = self.Question?.data.self{
                        self.q1.text = QuesionData.generalSymptoms[0]
                        self.q2.text = QuesionData.generalSymptoms[1]
                        self.q3.text = QuesionData.generalSymptoms[2]
                        self.q4.text = QuesionData.generalSymptoms[3]
                        self.q5.text = QuesionData.generalSymptoms[4]
                        self.q6.text = QuesionData.dangerSymptoms[0]
                        self.q7.text = QuesionData.dangerSymptoms[1]
                        self.q8.text = QuesionData.dangerSymptoms[2]
                        self.q9.text = QuesionData.dangerSymptoms[3]
                        self.q10.text = QuesionData.dangerSymptoms[4]
                        self.q11.text = QuesionData.dangerSymptoms[5]
                    } else {
                        print("Error loading image.")
                    }
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async {
                    let alert = UIAlertController(title: "Warning", message: "Something Went Wrong", preferredStyle: .alert)
                    alert.addAction(UIAlertAction(title: "Ok", style: .destructive) { _ in
                        print("API Error")
                    })
                    self.present(alert, animated: true, completion: nil)
                }
            }
        }
    }
    func PostAPI() {
        let apiURL = APIList.QuestionResponseApi
        print(apiURL)

        let boundary = UUID().uuidString
        var request = URLRequest(url: URL(string: apiURL)!)
        request.httpMethod = "POST"
        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
            // Update formData to include the password
        let formData: [String: String] = [
                "id": "\(id ?? "12234")",
                "Date": "\(d1 ?? "2024-01-01")",
                "text1": "\(q1.text ?? "Error")",
                "text2": "\(q2.text ?? "Error")",
                "text3": "\(q3.text ?? "Error")",
                "text4": "\(q4.text ?? "Error")",
                "text5": "\(q5.text ?? "Error")",
                "text6": "\(q6.text ?? "Error")",
                "text7": "\(q7.text ?? "Error")",
                "text8": "\(q8.text ?? "Error")",
                "text9": "\(q9.text ?? "Error")",
                "text10": "\(q10.text ?? "Error")",
                "text11": "\(q11.text ?? "Error")",
                
                "r1": "\(Q1op ?? "Error")",
                "r2": "\(Q2op ?? "Error")",
                "r3": "\(Q3op ?? "Error")",
                "r4": "\(Q4op ?? "Error")",
                "r5": "\(Q5op ?? "Error")",
                "r6": "\(Q6op ?? "Error")",
                "r7": "\(Q7op ?? "Error")",
                "r8": "\(Q8op ?? "Error")",
                "r9": "\(Q9op ?? "Error")",
                "r10": "\(Q10op ?? "Error")",
                "r11": "\(Q11op ?? "Error")"
            ]
        for (key, value) in formData {
            body.append(contentsOf: "--\(boundary)\r\n".utf8)
            body.append(contentsOf: "Content-Disposition: form-data; name=\"\(key)\"\r\n\r\n".utf8)
            body.append(contentsOf: "\(value)\r\n".utf8)
        }
        body.append(contentsOf: "--\(boundary)--\r\n".utf8) // Close the request body
        request.httpBody = body
        let task = URLSession.shared.dataTask(with: request) { (data, response, error) in
            if let error = error {
                print("Error: \(error)")
                // Handle the error, e.g., show an alert to the user
                return
            }
            if let httpResponse = response as? HTTPURLResponse {
                print("Status code: \(httpResponse.statusCode)")

                if let data = data {
                    print("Response Data:", String(data: data, encoding: .utf8) ?? "")
                    // You can perform further processing here
                }
            }
        }
        task.resume()
    }
}
