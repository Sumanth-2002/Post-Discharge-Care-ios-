//
//  PFallowUp.swift
//  Post Discharge Care
//
//  Created by SAIL on 23/01/24.
//
import UIKit

class PFallowUp: UIViewController {
    
    @IBOutlet weak var calenderView: UIView!
    var id: String?
    let datePicker: UIDatePicker = UIDatePicker()

    override func viewDidLoad() {
        super.viewDidLoad()
        print(id ?? "")
//        print(date ?? "")
        showDatePicker(tag: 0)
    }

    @IBAction func BackButton(_ sender: Any) {
//        let storyboard = UIStoryboard(name: "Main", bundle: nil)
//        let vc = storyboard.instantiateViewController(withIdentifier: "PatientDashboardVC") as! PatientDashboardVC
//        navigationController?.pushViewController(vc, animated: true)
//        vc.id = self.id
        for controller in self.navigationController!.viewControllers as Array {
                    if controller.isKind(of: PatientDashboardVC.self) {
                        self.navigationController!.popToViewController(controller, animated: true)
                        break
                    }
                }
        
    }
    func showDatePicker(tag: Int) {
        // Formate Date
        datePicker.datePickerMode = .date

        if #available(iOS 13.4, *) {
            datePicker.preferredDatePickerStyle = .inline
        } else {
            datePicker.preferredDatePickerStyle = .wheels
        }
        let toolbar = UIToolbar()
        toolbar.sizeToFit()

        // done button & cancel button
        let doneButton = UIBarButtonItem(title: "Take Test", style: .done, target: self, action: #selector(self.donedatePicker(_:)))
        doneButton.tag = tag
        let spaceButton = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)

       
        toolbar.setItems([spaceButton, doneButton], animated: false)

        // Set minimumDate to the current date
        datePicker.minimumDate = Date()

        // Add the datePicker to the view
        view.addSubview(datePicker)
        view.addSubview(toolbar)

        // Add constraints or frame as needed
        datePicker.translatesAutoresizingMaskIntoConstraints = false
        toolbar.translatesAutoresizingMaskIntoConstraints = false

        NSLayoutConstraint.activate([
            // Adjust the constraints as per your layout requirements
            datePicker.topAnchor.constraint(equalTo: calenderView.topAnchor),
            datePicker.leadingAnchor.constraint(equalTo: calenderView.leadingAnchor),
            datePicker.trailingAnchor.constraint(equalTo: calenderView.trailingAnchor),
            datePicker.bottomAnchor.constraint(equalTo: calenderView.bottomAnchor, constant: -10),

            toolbar.topAnchor.constraint(equalTo: datePicker.bottomAnchor),
            toolbar.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            toolbar.trailingAnchor.constraint(equalTo: view.trailingAnchor),
        ])
    }

    @objc func donedatePicker(_ sender: UIButton) {
        let formatter = DateFormatter()
        formatter.dateFormat = "YYYY-MM-dd"
        let date = formatter.string(from: datePicker.date)
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "PFallowUpQuesions") as! PFallowUpQuesions
        navigationController?.pushViewController(vc, animated: true)
        vc.id = self.id
        vc.d1 = date
    }
}
