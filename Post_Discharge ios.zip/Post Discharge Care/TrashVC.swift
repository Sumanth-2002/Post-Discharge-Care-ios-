//
//  TrashVC.swift
//  Post Discharge Care
//
//  Created by SAIL on 25/01/24.
//

import UIKit

class TrashVC: UIViewController {
    
    @IBOutlet weak var opt1: UIButton!
    @IBOutlet weak var opt2: UIButton!
    @IBOutlet weak var opt3: UIButton!

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    @IBAction func opt1Action(_ sender: UIButton) {
        if sender.isSelected{
            sender.isSelected = false
            opt2.isSelected = false
            opt2.isSelected = false
        }
        else
        {
            sender.isSelected = true
            opt2.isSelected = false
        }
    }
    @IBAction func opt2Action(_ sender: UIButton) {
        if sender.isSelected{
            sender.isSelected = false;
            opt1.isSelected = false;
        }
        else
        {
            sender.isSelected = true;
            opt1.isSelected = false;
        }
        
    }
    @IBAction func opt3Action(_ sender: UIButton) {
        if sender.isSelected{
            sender.isSelected = false;
            opt1.isSelected = false;
        }
        else
        {
            sender.isSelected = true;
            opt1.isSelected = false;
        }
        
    }

}
