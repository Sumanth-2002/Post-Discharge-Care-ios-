//
//  DoctorPatientCouseListCell.swift
//  Post Discharge Care
//
//  Created by Amar on 01/02/24.
//

import UIKit

class DoctorPatientCouseListCell: UITableViewCell {
    @IBOutlet weak var CourseLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

       
    }

}
