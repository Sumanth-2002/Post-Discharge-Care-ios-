//
//  UpdatePatientQuestionVC.swift
//  Post Discharge Care
//
//  Created by Amar Dwarakacherla on 18/02/24.
//
//
//import UIKit
//
//class UpdatePatientQuestionVC: UIViewController {
//
//    override func viewDidLoad() {
//        super.viewDidLoad()
//
//        // Do any additional setup after loading the view.
//    }
//    
//
//}


//
//  AddPatientQuestionVC.swift
//  Post Discharge Care
//
//  Created by Amar on 09/01/24.
//

import UIKit

class UpdatePatientQuestionVC: UIViewController {

    var id: String?
    var body = Data()
    var QuesView: QuestionViewModel?
    @IBOutlet weak var GSq1TF: UITextField!
    @IBOutlet weak var GSq2TF: UITextField!
    @IBOutlet weak var GSq3TF: UITextField!
    @IBOutlet weak var GSq4TF: UITextField!
    @IBOutlet weak var GSq5TF: UITextField!
    @IBOutlet weak var DSq1TF: UITextField!
@IBOutlet weak var DSq2TF: UITextField!
    @IBOutlet weak var DSq3TF: UITextField!
    @IBOutlet weak var DSq4TF: UITextField!
    @IBOutlet weak var DSq5TF: UITextField!
    @IBOutlet weak var DSq6TF: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        GetAPI()
    }
    
    @IBAction func BackButton(_ sender: Any) {
//        navigationController?.popViewController(animated: true)
        for controller in self.navigationController!.viewControllers as Array {
                    if controller.isKind(of: AddPatientNextVC.self) {
                        self.navigationController!.popToViewController(controller, animated: true)
                        break
                    }
                }
//        let storyboard = UIStoryboard(name: "Main", bundle: nil)
//        let VC = storyboard.instantiateViewController(withIdentifier: "AddPatientNextVC") as! AddPatientNextVC
//        navigationController?.pushViewController(VC, animated: true)
//        VC.id = id
        
    }
    
    @IBAction func SaveButton(_ sender: Any) {
        postAPI()
//        navigationController?.popViewController(animated: true)
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let VC = storyboard.instantiateViewController(withIdentifier: "AddPatientNextVC") as! AddPatientNextVC
        navigationController?.pushViewController(VC, animated: true)
        VC.id = id
    }
    
    
}
extension UpdatePatientQuestionVC {
    func GetAPI() {
        let apiURL = APIList.QuesViewApi
        print(apiURL)

        // Prepare POST parameters if needed
        let parameters: [String: String] = [
            "id" : id ?? "12234"
            // "key1": value1,
            // "key2": value2,
        ]
        APIHandler().postAPIValues(type: QuestionViewModel.self, apiUrl: apiURL, method: "POST", formData: parameters) { result in
            switch result {
            case .success(let data):
                // Assign the retrieved data to the QuesView property
                self.QuesView = data
                
                // Check if there are questions in the data
                if let questions = self.QuesView?.questions {
                    DispatchQueue.main.async { [self] in
                        // Update the text fields with the questions
                        for (index, question) in questions.enumerated() {
                            switch index {
                            case 0:
                                self.GSq1TF.text = question
                            case 1:
                                self.GSq2TF.text = question
                            case 2:
                                self.GSq3TF.text = question
                            case 3:
                                self.GSq4TF.text = question
                            case 4:
                                self.GSq5TF.text = question
                            case 5:
                                self.DSq1TF.text = question
                            case 6:
                                self.DSq2TF.text = question
                            case 7:
                                self.DSq3TF.text = question
                            case 8:
                                self.DSq4TF.text = question
                            case 9:
                                self.DSq5TF.text = question
                            case 10:
                                self.DSq6TF.text = question
                            default:
                                break
                            }
                        }
                    }
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async {
                    let alert = UIAlertController(title: "Warning", message: "Something Went Wrong", preferredStyle: .alert)
                    alert.addAction(UIAlertAction(title: "Ok", style: .destructive) { _ in
                        print("API Error")
                    })
                    self.present(alert, animated: true, completion: nil)
                }
            }
        }
    }
    func postAPI() {
        let apiURL = APIList.AddQuestionnariesApi
        print(apiURL)

        let boundary = UUID().uuidString
        var request = URLRequest(url: URL(string: apiURL)!)
        request.httpMethod = "POST"
        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
            // Update formData to include the password
            var formData: [String: String] = [
                "id": "\(id ?? "12234")",
                "text1": "\(GSq1TF.text ?? "Error")",
                "text2": "\(GSq2TF.text ?? "Error")",
                "text3": "\(GSq3TF.text ?? "Error")",
                "text4": "\(GSq4TF.text ?? "Error")",
                "text5": "\(GSq5TF.text ?? "Error")",
                "text6": "\(DSq1TF.text ?? "Error")",
                "text7": "\(DSq2TF.text ?? "Error")",
                "text8": "\(DSq3TF.text ?? "Error")",
                "text9": "\(DSq4TF.text ?? "Error")",
                "text10": "\(DSq6TF.text ?? "Error")",
                "text11": "\(DSq6TF.text ?? "Error")"
            ]
        for (key, value) in formData {
            body.append(contentsOf: "--\(boundary)\r\n".utf8)
            body.append(contentsOf: "Content-Disposition: form-data; name=\"\(key)\"\r\n\r\n".utf8)
            body.append(contentsOf: "\(value)\r\n".utf8)
        }
        body.append(contentsOf: "--\(boundary)--\r\n".utf8) // Close the request body
        request.httpBody = body
        let task = URLSession.shared.dataTask(with: request) { (data, response, error) in
            if let error = error {
                print("Error: \(error)")
                // Handle the error, e.g., show an alert to the user
                return
            }
            if let httpResponse = response as? HTTPURLResponse {
                print("Status code: \(httpResponse.statusCode)")

                if let data = data {
                    print("Response Data:", String(data: data, encoding: .utf8) ?? "")
                    // You can perform further processing here
                }
            }
        }
        task.resume()
    }
}



