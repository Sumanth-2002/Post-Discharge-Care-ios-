//
//  PatientMyProfileVC.swift
//  Post Discharge Care
//
//  Created by Amar on 09/01/24.
//

import UIKit

class PatientMyProfileVC: UIViewController {
    var id: String?
    var viewPatient: ViewPatientDetailsModel?
    var body = Data()
    @IBOutlet weak var NameLabel: UILabel!
    @IBOutlet weak var GenderLabel: UILabel!
    @IBOutlet weak var DateOfBirthLabel: UILabel!
    @IBOutlet weak var ParentLabel: UILabel!
    @IBOutlet weak var ContactLabel: UILabel!
    @IBOutlet weak var ProfileImage: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.navigationController?.isNavigationBarHidden=true;
        GetAPI()
    }
    

    @IBAction func LogoutButton(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let VC = storyboard.instantiateViewController(withIdentifier: "HomeVC") as! HomeVC
        navigationController?.pushViewController(VC, animated: true)
        
    }
    @IBAction func backButton(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
    func GetAPI() {
        let apiURL = APIList.ViewPatientApi
        print(apiURL)

        // Prepare POST parameters if needed
        let parameters: [String: String] = [
            "id" : id ?? "733720"
            // "key1": value1,
            // "key2": value2,
        ]
        APIHandler().postAPIValues(type: ViewPatientDetailsModel.self, apiUrl: apiURL, method: "POST", formData: parameters) { result in
            switch result {
            case .success(let data):
                self.viewPatient = data
//                print(data)
                DispatchQueue.main.async { [self] in
                    if let patientData = self.viewPatient?.data.first {
                        self.NameLabel.text=patientData.name
                        self.ContactLabel.text = patientData.contactNo
                        self.GenderLabel.text = patientData.gender
                        self.DateOfBirthLabel.text = patientData.dateOfBirth
                        self.ParentLabel.text = patientData.parentName
                        self.ProfileImage.image = getImage(from: patientData.profilePic)
                    }
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async {
                    let alert = UIAlertController(title: "Warning", message: "Something Went Wrong", preferredStyle: .alert)
                    alert.addAction(UIAlertAction(title: "Ok", style: .destructive) { _ in
                        print("API Error")
                    })
                    self.present(alert, animated: true, completion: nil)
                }
            }
        }
    }
    func getImage(from imageDataString: String?) -> UIImage? {
        guard let imageDataString = imageDataString, let imageData = Data(base64Encoded: imageDataString) else {
            return nil
        }
        return UIImage(data: imageData)
    }
    

}
