-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: May 08, 2024 at 01:19 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `post`
--

-- --------------------------------------------------------

--
-- Table structure for table `chief_complaints`
--

CREATE TABLE `chief_complaints` (
  `id` text NOT NULL,
  `chief_complaints` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `chief_complaints`
--

INSERT INTO `chief_complaints` (`id`, `chief_complaints`) VALUES
('949194', 'amar chanbdra hiv patients , doctor told they shouldnt have hopes on their lives'),
('009mlm', 'kjk'),
('123', '1'),
('205', 'dsdas'),
('12', '1'),
('20251', '12'),
('143', '1'),
('143', '1'),
('123456', 'Wawa'),
('1234', '1'),
('1234', '1'),
('1234', '1'),
('1234', '1'),
('733720', '1'),
('1432', '1'),
('1432', '1'),
('1432', '1'),
('010101', '1'),
('010101', '1'),
('010101', '1'),
('12234', '  Hello World'),
('55555', 'Having pain in thought');

-- --------------------------------------------------------

--
-- Table structure for table `course_dis`
--

CREATE TABLE `course_dis` (
  `id` bigint(20) NOT NULL,
  `Course_in_Hospital` text NOT NULL,
  `Course_in_PICU` text NOT NULL,
  `Course_in_Ward` text NOT NULL,
  `Advice_on_Discharge` text NOT NULL,
  `Review` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `course_dis`
--

INSERT INTO `course_dis` (`id`, `Course_in_Hospital`, `Course_in_PICU`, `Course_in_Ward`, `Advice_on_Discharge`, `Review`) VALUES
(949194, 'amar chanbdra hiv patients , doctor told they shouldnt have hopes on their lives', 'amar chanbdra hiv patients , doctor told they shouldnt have hopes on their lives', 'amar chanbdra hiv patients , doctor told they shouldnt have hopes on their lives', 'amar chanbdra hiv patients , doctor told they shouldnt have hopes on their lives', 'amar chanbdra hiv patients , doctor told they shouldnt have hopes on their lives'),
(123, '1', '1', '1', '1', '1'),
(205, '1212', '1221', '1212', '1212', ''),
(12, '1', '1', '1', '1', '1,'),
(20251, '12', '12', '21', '12', '21,'),
(143, '1', '1', '1', '1', '11'),
(143, '1', '1', '1', '1', '11'),
(123456, 'qw', 'qw', 'qw', 'qwq', 'w'),
(1234, '1', '1', '1', '1', '1'),
(1234, '1', '1', '1', '1', '1'),
(1234, '1', '1', '1', '1', '1'),
(1234, '1', '1', '1', '1', '1'),
(733720, '1', '1', '1', '1', '1'),
(1432, '1', '1', '1', '1', '1'),
(1432, '1', '1', '1', '1', '1'),
(1432, '1', '1', '1', '1', '1'),
(10101, '1', '1', '1', '1', '1'),
(10101, '1', '1', '1', '1', '1'),
(10101, '1', '1', '1', '1', '1'),
(12234, '   he is diagnosed with the serious disordet thathe is diagnosed with the serious disordet that', '   he is diagnosed with the serious disordet thathe is diagnosed with the serious disordet that', '   he is diagnosed with the serious disordet thathe is diagnosed with the serious disordet that', '  Nice mankkk', '   he is diagnosed with the serious disordet thathe is diagnosed with the serious disordet that		'),
(55555, 'Taken', 'have been alloted', 'para', 'take rest for 5 days', 'Need to attend regularly');

-- --------------------------------------------------------

--
-- Table structure for table `development_history`
--

CREATE TABLE `development_history` (
  `id` text NOT NULL,
  `Gross_Motor` text NOT NULL,
  `Fine_Motor` text NOT NULL,
  `Language` text NOT NULL,
  `Social_and_Cognition` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `development_history`
--

INSERT INTO `development_history` (`id`, `Gross_Motor`, `Fine_Motor`, `Language`, `Social_and_Cognition`) VALUES
('949194', 'hi', 'nn', 'jn', 'n'),
('009mlm', 'lm', 'lmlm', 'lml', 'ml'),
('123', '1', '1', '1', '1'),
('205', 'ddasd', 'dasd', 'dsda', 'dsada'),
('12', '1', '1', '1', '1'),
('20251', '12', '12', '12', '12'),
('143', '1', '1', '1', '1'),
('143', '1', '1', '1', '1'),
('123456', 'wqwq', 'wqwqw', 'wqwqw', 'wqwqw'),
('1234', '1', '1', '1', '1'),
('1234', '1', '1', '1', '1'),
('1234', '1', '1', '1', '1'),
('1234', '1', '1', '1', '1'),
('733720', '1', '1', '1', '1'),
('1432', '1', '1', '1', '1'),
('1432', '1', '1', '1', '1'),
('1432', '1', '1', '1', '1'),
('010101', '1', '1', '1', '1'),
('010101', '1', '1', '1', '1'),
('010101', '1', '1', '1', '1'),
('12234', '   a', '   b', '   c', '   d'),
('55555', '23', '24', '21', 'Yes');

-- --------------------------------------------------------

--
-- Table structure for table `discharge_summary`
--

CREATE TABLE `discharge_summary` (
  `id` text NOT NULL,
  `Name` text NOT NULL,
  `Sex` text NOT NULL,
  `Address` text NOT NULL,
  `Department` text NOT NULL,
  `Consultant` text NOT NULL,
  `Date_of_admission` text NOT NULL,
  `Date_of_Discharge` text NOT NULL,
  `Diagnosis` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `discharge_summary`
--

INSERT INTO `discharge_summary` (`id`, `Name`, `Sex`, `Address`, `Department`, `Consultant`, `Date_of_admission`, `Date_of_Discharge`, `Diagnosis`) VALUES
('949194', 'sumanth', 'male', 'NEFKN', 'dihi', 'hro', '13/10/2023', '22/11/2023', 'dengue'),
('009mlm', 'ijiojlm', 'jlml', 'kjmlm', 'jijml', 'kjml', '2023-11-10', '2023-12-10', 'kjl'),
('123', '1', '1', '1', '1', '1', '1', '1', '1'),
('205', 'dasd', 'dsad', 'dsad', 'dasd', 'dsada', 'dasda', 'dasd', 'dasd'),
('12', 'Ame', 'Ame', '', '11', '1', '2024-02-02', '2024-02-02', ''),
('20251', 'ame', 'male', '', '12', '12', '2024-02-02', '2024-02-02', ''),
('143', 'Amar', 'male', 'dda', '1', '1', '2024-02-02', '2024-02-02', 'dsDS'),
('143', 'Amar', 'male', 'dda', '1', '1', '2024-02-02', '2024-02-02', 'dsDS'),
('123456', 'Samjiii', '321312', 'dda', 'carqw', 'wwwq', '2024-02-02', '2024-02-02', 'dsDS'),
('', '', '', '', '', '', '', '', ''),
('', '', '', '', '', '', '', '', ''),
('', '', '', '', '', '', '', '', ''),
('1234', '', '', '', '', '', '', '', ''),
('1234', '', '', '', '', '', '', '', ''),
('1234', '', '', '', '', '', '', '', ''),
('1234', '1', '1', '1', '1', '1', '2024-02-02', '2024-02-02', '1'),
('1234', '1', '1', '1', '1', '1', '2024-02-02', '2024-02-02', '1'),
('1234', '1', '1', '1', '1', '1', '2024-02-02', '2024-02-02', '1'),
('1234', '', '1', '1', '1', '1', '2024-02-02', '2024-02-02', '1'),
('1234', '', '', '1', '1', '1', '2024-02-02', '2024-02-02', '1'),
('733720', '', '', '1', '1', '1', '', '2024-02-02', '1'),
('1432', '', '', '1', '1', '1', '', '2024-02-02', '1'),
('1432', '', '', '1', '1', '1', '', '2024-02-02', '1'),
('1432', '', '', '1', '1', '1', '', '2024-02-02', '1'),
('010101', '', '', '1', '1', '1', '', '2024-02-02', '1'),
('010101', '', '', '1', '1', '1', '', '2024-02-02', '1'),
('010101', '', '', '1', '1', '1', '', '2024-02-02', '1'),
('010101', '', '', '1', '1', '1', '', '2024-02-02', '1'),
('010101', '1', '1', '1', '1', '1', '', '2024-02-02', '1'),
('010101', '1', '1', '1', '1', '1', '', '2024-02-02', '1'),
('010101', '1', '1', '1', '1', '1', '2024-02-02', '2024-02-02', '1'),
('55555', 'Harsha', 'Male', 'dda', 'Medicine', 'Geetha', '2024-02-02', '2024-02-05', 'dsDS');

-- --------------------------------------------------------

--
-- Table structure for table `dis_image`
--

CREATE TABLE `dis_image` (
  `patient_id` bigint(20) NOT NULL,
  `image` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `dis_image`
--

INSERT INTO `dis_image` (`patient_id`, `image`) VALUES
(12234, 'uploads/alzheimers-and-montreal-cognitive-assessment-moca-98617-5bb7c858c9e77c0051582af1-fotor-20240212104540.jpg'),
(949194, 'uploads/949194img1.jpg'),
(12234, 'uploads/alzheimers-and-montreal-cognitive-assessment-moca-98617-5bb7c858c9e77c0051582af1-fotor-20240212104540.jpg'),
(12234, 'uploads/alzheimers-and-montreal-cognitive-assessment-moca-98617-5bb7c858c9e77c0051582af1-fotor-20240212104540.jpg'),
(12234, 'uploads/alzheimers-and-montreal-cognitive-assessment-moca-98617-5bb7c858c9e77c0051582af1-fotor-20240212104540.jpg'),
(9, 'uploads/009mlmimg1.jpg'),
(123, 'uploads/1.png'),
(12, 'uploads/5c0264b219d4258d8f7e63c6489eed67.jpg'),
(12, 'uploads/5c0264b219d4258d8f7e63c6489eed67.jpg'),
(23, 'uploads/IMG_5782.PNG'),
(23, 'uploads/IMG_8380.heic'),
(23, 'uploads/alzheimers-and-montreal-cognitive-assessment-moca-98617-5bb7c858c9e77c0051582af1-fotor-20240212104540.jpg'),
(23, 'uploads/alzheimers-and-montreal-cognitive-assessment-moca-98617-5bb7c858c9e77c0051582af1-fotor-20240212104540.jpg'),
(23, 'uploads/alzheimers-and-montreal-cognitive-assessment-moca-98617-5bb7c858c9e77c0051582af1-fotor-20240212104540.jpg'),
(23, 'uploads/alzheimers-and-montreal-cognitive-assessment-moca-98617-5bb7c858c9e77c0051582af1-fotor-20240212104540.jpg'),
(122, 'uploads/alzheimers-and-montreal-cognitive-assessment-moca-98617-5bb7c858c9e77c0051582af1-fotor-20240212104540.jpg'),
(15, 'uploads/E2503BD7-3651-4607-800E-E4717F0FFEC2.jpg'),
(6300, 'uploads/30F7C265-492C-42D2-94D1-53F59790C740.jpg'),
(205, 'uploads/fdd9fb6d98f4d6426afbba0688aa8762.jpg'),
(205, 'uploads/fdd9fb6d98f4d6426afbba0688aa8762.jpg'),
(2003, 'uploads/99D7A73E-E8D1-490E-A361-33782B711BC7.jpg'),
(2001, 'uploads/368F6DF1-D439-47D8-AF58-0C14EB5772F0.jpg'),
(12, 'uploads/C80DE46F-940E-4E71-A0BD-7A78345A9982.jpg'),
(12, 'uploads/A2CFE81B-C6D1-4814-912A-27273596781E.jpg'),
(12, 'uploads/531A7E95-BCCF-45EB-945B-794F76BAF927.jpg'),
(12, 'uploads/3AA7FC37-6ABE-4EC0-AFC5-54B402791E97.jpg'),
(205, 'uploads/fdd9fb6d98f4d6426afbba0688aa8762.jpg'),
(12, 'uploads/8475D368-0613-4A4F-BE22-F0B85BD2F94C.jpg'),
(12, 'uploads/C6E34CEF-EC37-4206-9AAF-2CE59FC0B001.jpg'),
(12, 'uploads/2DC5789B-2971-438D-84BB-A8CFD1F0AE41.jpg'),
(12, 'uploads/70066CA5-2F49-4DE5-B285-78D47908ACD1.jpg'),
(12, 'uploads/F13DD93C-7F39-4007-82ED-C1E559DF9577.jpg'),
(12, 'uploads/D55C96C3-A227-403F-AB96-B438BCCDE5F5.jpg'),
(20251, 'uploads/C1498C6C-874E-4833-B836-6716D6457C35.jpg'),
(143, 'uploads/6104E112-795E-46E0-A58D-B855DF525798.jpg'),
(143, 'uploads/61B0E741-4F3D-4F65-B9F5-F3E0B20007E4.jpg'),
(123456, 'uploads/DC17D832-75F8-400C-AB8D-2E7B88CA6765.jpg'),
(1234, 'uploads/WhatsApp Image 2024-02-26 at 9.50.46 AM.jpeg'),
(1234, 'uploads/WhatsApp Image 2024-02-26 at 9.50.46 AM.jpeg'),
(1234, 'uploads/WhatsApp Image 2024-02-26 at 9.50.46 AM.jpeg'),
(1234, 'uploads/WhatsApp Image 2024-02-26 at 9.50.46 AM.jpeg'),
(733720, 'uploads/WhatsApp Image 2024-02-26 at 9.50.46 AM.jpeg'),
(1432, 'uploads/WhatsApp Image 2024-02-26 at 9.50.46 AM.jpeg'),
(1432, 'uploads/WhatsApp Image 2024-02-26 at 9.50.46 AM.jpeg'),
(1432, 'uploads/WhatsApp Image 2024-02-26 at 9.50.46 AM.jpeg'),
(10101, 'uploads/WhatsApp Image 2024-02-26 at 9.50.46 AM.jpeg'),
(10101, 'uploads/WhatsApp Image 2024-02-26 at 9.50.46 AM.jpeg'),
(55555, 'uploads/B229AEBC-0342-4E34-A172-5ED22F2EC759.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `doctor_login`
--

CREATE TABLE `doctor_login` (
  `id` text NOT NULL,
  `password` text NOT NULL,
  `Name` text NOT NULL,
  `Gender` text NOT NULL,
  `Department` text NOT NULL,
  `Experience` text NOT NULL,
  `Contact_Number` text NOT NULL,
  `doc_profile` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `doctor_login`
--

INSERT INTO `doctor_login` (`id`, `password`, `Name`, `Gender`, `Department`, `Experience`, `Contact_Number`, `doc_profile`) VALUES
('1890', 'hi', 'Amar', 'Female', 'Pediatrics', '3 years', '9876543210', 'uploads/D9785AC6-45D3-4D1B-BD9D-B4D5714AEACF.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `history_illness`
--

CREATE TABLE `history_illness` (
  `id` text NOT NULL,
  `illness` text NOT NULL,
  `Past_history` text NOT NULL,
  `Antennal_history` text NOT NULL,
  `Natal_history` text NOT NULL,
  `Postnatal_history` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `history_illness`
--

INSERT INTO `history_illness` (`id`, `illness`, `Past_history`, `Antennal_history`, `Natal_history`, `Postnatal_history`) VALUES
('949194', 'amar chanbdra hiv patients , doctor told they shouldnt have hopes on their lives', 'amar chanbdra hiv patients , doctor told they shouldnt have hopes on their lives', 'amar chanbdra hiv patients , doctor told they shouldnt have hopes on their lives', 'amar chanbdra hiv patients , doctor told they shouldnt have hopes on their lives', 'amar chanbdra hiv patients , doctor told they shouldnt have hopes on their lives'),
('009mlm', 'jk', 'jlml', 'lmlm', 'lmlmlm', 'lmlm'),
('123', '1', '1', '1', '1', '1'),
('205', 'dsa', 'ewqeqw', 'dasdsa', 'sdsa', 'dasdad'),
('12', '1', '1', '1', '1', '1'),
('20251', '12', '12', '1212', '1', '12'),
('143', '1', '1', '1', '1', '1'),
('143', '1', '1', '1', '1', '1'),
('123456', 'wqwq', 'wqw', 'wqwq', 'wqwq', 'wqwq'),
('1234', '1', '1', '1', '1', '1'),
('1234', '1', '1', '1', '1', '1'),
('1234', '1', '1', '1', '1', '1'),
('1234', '1', '1', '1', '1', '1'),
('733720', '1', '1', '1', '1', '1'),
('1432', '1', '1', '1', '1', '1'),
('1432', '1', '1', '1', '1', '1'),
('1432', '1', '1', '1', '1', '1'),
('010101', '1', '1', '1', '1', '1'),
('010101', '1', '1', '1', '1', '1'),
('010101', '1', '1', '1', '1', '1'),
('12234', '  Hello World', ' nothing', '   he is diagnosed with the serious disordet thathe is diagnosed with the serious disordet that', '   he is diagnosed with the serious disordet thathe is diagnosed with the serious disordet that', '   he is diagnosed with the serious disordet thathe is diagnosed with the serious disordet that'),
('55555', 'None', 'None', 'Yes', 'Yes', 'Yes');

-- --------------------------------------------------------

--
-- Table structure for table `image`
--

CREATE TABLE `image` (
  `image_insertion` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `image`
--

INSERT INTO `image` (`image_insertion`) VALUES
('uploads/1000000035.jpg'),
('uploads/1000000036.jpg'),
('uploads/1000000035.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `immunization_history`
--

CREATE TABLE `immunization_history` (
  `id` text NOT NULL,
  `history` text NOT NULL,
  `Anthropometry` text NOT NULL,
  `weightt` text NOT NULL,
  `height` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `immunization_history`
--

INSERT INTO `immunization_history` (`id`, `history`, `Anthropometry`, `weightt`, `height`) VALUES
('949194', 'amar chanbdra hiv patients , doctor told they shouldnt have hopes on their lives', 'Excellent', 'j', 'kk'),
('123', '1', '1', '1', '1'),
('205', 'dsda', 'dsadas', '12', '21'),
('12', '1', '1', '1', '1'),
('20251', '12', '12', '12', '12'),
('143', '1', '1', '1', '1'),
('143', '1', '1', '1', '1'),
('123456', 'wqwqw', 'wqwqw', 'wqwqw', 'wqwqw'),
('1234', '1', '1', '1', '1'),
('1234', '1', '1', '1', '1'),
('1234', '1', '1', '1', '1'),
('1234', '1', '1', '1', '1'),
('733720', '1', '1', '1', '1'),
('1432', '1', '1', '1', '1'),
('1432', '1', '1', '1', '1'),
('1432', '1', '1', '1', '1'),
('010101', '1', '1', '1', '1'),
('010101', '1', '1', '1', '1'),
('010101', '1', '1', '1', '1'),
('12234', '   he is diagnosed with the serious disordet thathe is diagnosed with the serious disordet that', '   Excellent', '   24', '   34'),
('55555', 'having illness', 'antipodes', '70', '160');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `id` bigint(20) NOT NULL,
  `password` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `password`) VALUES
(0, '0000'),
(1432, '1432'),
(1920, '1920'),
(2001, '2001'),
(2003, '2003'),
(2024, '2024'),
(6300, '6300'),
(8000, '8000'),
(11111, '1111'),
(12234, '2234'),
(14322, '1432'),
(15081, '5081'),
(20200, '0200'),
(20251, '0251'),
(55555, '5555'),
(89000, '9000'),
(90909, '0909'),
(101010, '1010'),
(123456, '3456'),
(733720, '3720'),
(777777, '7777'),
(800000, '0000'),
(909090, '9090'),
(1221312, '1312'),
(8888888, '8888'),
(9999000, '9000'),
(9999990, '9990'),
(9999999, '9999'),
(25252525, '2525'),
(55555555, '5555'),
(192011072, '1072'),
(7337207416, '7416'),
(24242442424, '2424');

-- --------------------------------------------------------

--
-- Table structure for table `medicine`
--

CREATE TABLE `medicine` (
  `id` text NOT NULL,
  `Course_Name` text NOT NULL,
  `Medicine_Name` text NOT NULL,
  `Duration` text NOT NULL,
  `Frequency` text NOT NULL,
  `Guidelines` text NOT NULL,
  `Date` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `medicine`
--

INSERT INTO `medicine` (`id`, `Course_Name`, `Medicine_Name`, `Duration`, `Frequency`, `Guidelines`, `Date`) VALUES
('', '', '', '', '', '', ''),
('', '', '', '', '', '', ''),
('', '', '', '', '', '', ''),
('', '', '', '', '', '', ''),
('18911', 'dasd', 'Amar', 'None', 'None', 'Hello', '2024-01-28'),
('18911', 'dasd', 'Amar', 'None', 'None', 'Hello', '2024-01-28'),
('18911', 'dasd', 'Amar', 'None', 'None', 'Hello', '2024-01-28'),
('18911', 'dasd', 'Amar', 'None', 'None', 'Hello', '2024-01-28'),
('18911', 'dasd', 'Amar', 'None', 'None', 'Hello', '2024-01-28'),
('18911', 'dasd', 'Amar', 'None', 'None', 'Hello', '2024-01-28'),
('18911', 'dasd', 'Amar', 'None', 'None', 'Hello', '2024-01-28'),
('', '', '', '', '', '', '2024-01-28'),
('18911', 'dasd', 'Amar', 'None', 'None', 'Hello', '2024-01-28'),
('18911', 'dasd', 'Amar', 'None', 'None', 'Hello', '2024-01-28'),
('123', '1', 'das', 'das', 'dasd', 'dsa', 'dasda'),
('123', '2', 'Amar', 'None', 'None', 'Ama', 'dasda'),
('12234', 'none', 'Hello', 'nine', 'none', 'none', ''),
('123456789', 'dada', 'das', 'das', 'dasd', 'dsa', 'dasda'),
('123456789', 'dada', 'das', 'das', 'dasd', 'dsa', 'dasda'),
('123456789', 'dada', 'das', 'das', 'dasd', 'dsa', 'dasda'),
('123456789', 'dada', 'das', 'das', 'dasd', 'dsa', 'dasda'),
('123456789', 'dada', 'das', 'das', 'dasd', 'dsa', 'dasda'),
('123456789', 'dada', 'das', 'das', 'dasd', 'dsa', 'dasda'),
('123456789', 'dada', 'das', 'das', 'dasd', 'dsa', 'dasda'),
('123456789', '3213', '312313', '3213', '3212', '', '2024-02-28'),
('123456789', 'fdfa', 'dada', 'fdfa', 'fdfa', '', '2024-02-28'),
('123456789', 'dasda', 'dasd', 'dasda', 'dasd', '', '2024-02-28'),
('123456789', 'dsad', 'dasdas', 'dsad', 'dasda', '', '2024-02-28'),
('123456789', '3213', '32131', '3213', '321312', '', '2024-02-28'),
('123456', '', '', '', '', '', '2024-02-28'),
('123456', '', '', '', '', '', '2024-02-28'),
('123456', '', '', '', '', '', '2024-02-28'),
('123456', '', '', '', '', '', '2024-02-28'),
('00000', '321312', '3213', '321312', '32131', '', '2024-02-28'),
('00000', '431431', '4143', '431431', '431414', '', '2024-02-28'),
('00000', '43112', '1341', '43112', '43141', '', '2024-02-28'),
('00000', '3123', '3312', '3123', '321', '', '2024-02-28'),
('00000', 'dasda', '321', 'dasda', 'dasd', '', '2024-02-28'),
('11111', '4', 'Line', '4', 'Need to take', '231', '2024-02-28'),
('11111', '5MONTHS', 'Line', '5MONTHS', '4', '321312', '2024-02-28'),
('11111', '3', '2', '3', '4', '', '2024-02-28'),
('11111', '3', '2', '3', '4', '', '2024-02-28'),
('123456', '1', '2', '3', '4', '5', '2024-02-28'),
('11111', '3', '2', '3', '4', '', '2024-02-28'),
('12234', '1', '2', '3', '4', '5', '2024-02-28'),
('12234', 'Paracetamol', 'Paracetamol', 'First 3 Months', 'once a day', 'After meal', '2024-04-08'),
('55555', 'Paracetmol', 'Paracetmol', '1 week', '2 times a day', 'After Breakfast', '2024-04-09'),
('55555', 'Morphine ', 'Morphine ', '2nd week', 'once a day', 'After Lunch', '2024-04-09');

-- --------------------------------------------------------

--
-- Table structure for table `patient_details`
--

CREATE TABLE `patient_details` (
  `id` bigint(20) NOT NULL,
  `Name` text NOT NULL,
  `Contact_No` bigint(20) NOT NULL,
  `Gender` text NOT NULL,
  `Date_Of_Birth` date NOT NULL,
  `Height` text NOT NULL,
  `Weight` text NOT NULL,
  `Parent_Name` text NOT NULL,
  `Admitted_On` date NOT NULL,
  `Discharge_On` date NOT NULL,
  `Profile_Pic` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `patient_details`
--

INSERT INTO `patient_details` (`id`, `Name`, `Contact_No`, `Gender`, `Date_Of_Birth`, `Height`, `Weight`, `Parent_Name`, `Admitted_On`, `Discharge_On`, `Profile_Pic`) VALUES
(12234, 'Ama', 9876543211, 'male', '2023-11-04', '590cms', '78kg', 'suresh', '2023-11-10', '2023-12-01', 'uploads/FA69DFF4-5D37-4839-B045-FADEE170B00B.jpg'),
(733720, 'amar', 7337207416, 'male', '2002-07-24', '55kg', '45', 'vijaya', '2023-11-10', '2023-12-01', 'profile_pics/733720.jpg'),
(733720, 'amar', 7337207416, 'male', '2002-07-24', '55kg', '45', 'vijaya', '2023-11-10', '2023-12-01', 'profile_pics/733720.jpg'),
(800000, 'amar', 7337207416, 'male', '2002-07-24', '55kg', '60kh', 'vijaya', '2023-11-10', '2023-12-01', 'profile_pics/800000.jpg'),
(9999999, 'chandra', 8977897789, 'Male', '2002-07-14', '185cm', '55kg', 'Peer', '2023-11-10', '2023-12-11', 'profile_pics/9999999.jpg'),
(9999990, 'doc', 9999986688, 'Male', '0000-00-00', '138cm', '55kg', 'Suresh', '2023-11-10', '2023-12-11', 'profile_pics/9999990.jpg'),
(8888888, 'Amar', 7777888899, 'Male', '2002-07-14', '158cm', '77kg', 'pp', '2023-11-10', '2023-12-11', 'profile_pics/8888888.jpg'),
(89000, 'ojoj', 9991110000, 'jjoi', '2023-11-02', '98', '99', '0800', '2023-11-19', '2023-12-11', 'profile_pics/89000.jpg'),
(20200, 'ooj', 9866540000, 'knkn', '2002-11-10', '155cm', '55kg', 'ni', '2023-11-10', '2023-12-11', 'profile_pics/20200.jpg'),
(909090, 'ikkn', 9220007777, 'jojo', '2002-11-10', '9898', '989', 'knini', '2023-11-10', '2023-12-10', 'profile_pics/909090.jpg'),
(8000, 'kjoj', 9330002222, 'kbkb', '0000-00-00', '99cmg', '88kg', 'suresh', '2023-11-10', '2023-12-11', 'profile_pics/8000.jpg'),
(9999000, 'ojoj', 9990002222, 'male', '0000-00-00', '080nn', '99kj', 'nfo', '2023-11-10', '2023-12-11', 'profile_pics/9999000.jpg'),
(777777, 'ihih', 9876600000, 'mlaml', '2002-11-07', 'kn', 'inkn', 'jb jb', '2023-11-10', '2023-12-11', 'profile_pics/777777.jpg'),
(90909, 'ojoj', 9202222299, 'mkmkm', '2002-11-10', '678cm', '88kg', 'kjnknk', '2023-11-10', '2023-12-10', 'profile_pics/090909.jpg'),
(12234, 'Ama', 9876543211, 'male', '2023-11-04', '590cms', '78kg', 'suresh', '2023-11-10', '2023-12-01', 'uploads/FA69DFF4-5D37-4839-B045-FADEE170B00B.jpg'),
(12234, 'Ama', 9876543211, 'male', '2023-11-04', '590cms', '78kg', 'suresh', '2023-11-10', '2023-12-01', 'uploads/FA69DFF4-5D37-4839-B045-FADEE170B00B.jpg'),
(12234, 'Ama', 9876543211, 'male', '2023-11-04', '590cms', '78kg', 'suresh', '2023-11-10', '2023-12-01', 'uploads/FA69DFF4-5D37-4839-B045-FADEE170B00B.jpg'),
(12234, 'Ama', 9876543211, 'male', '2023-11-04', '590cms', '78kg', 'suresh', '2023-11-10', '2023-12-01', 'uploads/FA69DFF4-5D37-4839-B045-FADEE170B00B.jpg'),
(12234, 'Ama', 9876543211, 'male', '2023-11-04', '590cms', '78kg', 'suresh', '2023-11-10', '2023-12-01', 'uploads/FA69DFF4-5D37-4839-B045-FADEE170B00B.jpg'),
(123245, 'AME', 7333733, 'male', '2023-10-10', '23', '23', 'name', '2023-10-10', '2023-10-10', ''),
(1234, 'a', 312321, '3123', '2023-10-10', '232', '31', '321', '2023-10-10', '2023-10-10', ''),
(1234, 'a', 312321, '3123', '2023-10-10', '232', '31', '321', '2023-10-10', '2023-10-10', ''),
(12234, 'Ama', 9876543211, 'male', '2023-11-04', '590cms', '78kg', 'suresh', '2023-11-10', '2023-12-01', 'uploads/FA69DFF4-5D37-4839-B045-FADEE170B00B.jpg'),
(12345, 'ame', 321, '3213', '2023-10-10', '231', '32', '3131', '2023-10-10', '2023-10-10', 'uploads/6446A871-7A73-4630-9947-EB839EFFA8BF.jpg'),
(12234, 'Ama', 9876543211, 'male', '2023-11-04', '590cms', '78kg', 'suresh', '2023-11-10', '2023-12-01', 'uploads/FA69DFF4-5D37-4839-B045-FADEE170B00B.jpg'),
(12234, 'Ama', 9876543211, 'male', '2023-11-04', '590cms', '78kg', 'suresh', '2023-11-10', '2023-12-01', 'uploads/FA69DFF4-5D37-4839-B045-FADEE170B00B.jpg'),
(12234, 'Ama', 9876543211, 'male', '2023-11-04', '590cms', '78kg', 'suresh', '2023-11-10', '2023-12-01', 'uploads/FA69DFF4-5D37-4839-B045-FADEE170B00B.jpg'),
(12234, 'Ama', 9876543211, 'male', '2023-11-04', '590cms', '78kg', 'suresh', '2023-11-10', '2023-12-01', 'uploads/FA69DFF4-5D37-4839-B045-FADEE170B00B.jpg'),
(12234, 'Ama', 9876543211, 'male', '2023-11-04', '590cms', '78kg', 'suresh', '2023-11-10', '2023-12-01', 'uploads/FA69DFF4-5D37-4839-B045-FADEE170B00B.jpg'),
(12234, 'Ama', 9876543211, 'male', '2023-11-04', '590cms', '78kg', 'suresh', '2023-11-10', '2023-12-01', 'uploads/FA69DFF4-5D37-4839-B045-FADEE170B00B.jpg'),
(12234, 'Ama', 9876543211, 'male', '2023-11-04', '590cms', '78kg', 'suresh', '2023-11-10', '2023-12-01', 'uploads/FA69DFF4-5D37-4839-B045-FADEE170B00B.jpg'),
(12234, 'Ama', 9876543211, 'male', '2023-11-04', '590cms', '78kg', 'suresh', '2023-11-10', '2023-12-01', 'uploads/FA69DFF4-5D37-4839-B045-FADEE170B00B.jpg'),
(12234, 'Ama', 9876543211, 'male', '2023-11-04', '590cms', '78kg', 'suresh', '2023-11-10', '2023-12-01', 'uploads/FA69DFF4-5D37-4839-B045-FADEE170B00B.jpg'),
(12234, 'Ama', 9876543211, 'male', '2023-11-04', '590cms', '78kg', 'suresh', '2023-11-10', '2023-12-01', 'uploads/FA69DFF4-5D37-4839-B045-FADEE170B00B.jpg'),
(12234, 'Ama', 9876543211, 'male', '2023-11-04', '590cms', '78kg', 'suresh', '2023-11-10', '2023-12-01', 'uploads/FA69DFF4-5D37-4839-B045-FADEE170B00B.jpg'),
(12234, 'Ama', 9876543211, 'male', '2023-11-04', '590cms', '78kg', 'suresh', '2023-11-10', '2023-12-01', 'uploads/FA69DFF4-5D37-4839-B045-FADEE170B00B.jpg'),
(12234, 'Ama', 9876543211, 'male', '2023-11-04', '590cms', '78kg', 'suresh', '2023-11-10', '2023-12-01', 'uploads/FA69DFF4-5D37-4839-B045-FADEE170B00B.jpg'),
(12234, 'Ama', 9876543211, 'male', '2023-11-04', '590cms', '78kg', 'suresh', '2023-11-10', '2023-12-01', 'uploads/FA69DFF4-5D37-4839-B045-FADEE170B00B.jpg'),
(12234, 'Ama', 9876543211, 'male', '2023-11-04', '590cms', '78kg', 'suresh', '2023-11-10', '2023-12-01', 'uploads/FA69DFF4-5D37-4839-B045-FADEE170B00B.jpg'),
(1223, '31231', 231, '31231', '2023-10-10', '23', '23', '231', '2023-10-10', '2023-10-10', 'uploads/1.png'),
(1432, '31231', 231, '31231', '2023-10-10', '23', '23', '231', '2023-10-10', '2023-10-10', 'uploads/1.png'),
(1432, '31231', 231, '31231', '2023-10-10', '23', '23', '231', '2023-10-10', '2023-10-10', 'uploads/1.png'),
(1432, '31231', 231, '31231', '2023-10-10', '23', '23', '231', '2023-10-10', '2023-10-10', 'uploads/1.png'),
(14322, '31231', 231, '31231', '2023-10-10', '23', '23', '231', '2023-10-10', '2023-10-10', 'uploads/1.png'),
(192011072, 'Amar', 7337207416, 'Male', '2024-10-10', '23', '34', 'Kumar', '2024-10-10', '2024-10-10', 'uploads/E1807F21-F62C-4DB7-8DF1-50A0A2EBE67C.jpg'),
(55555555, '31', 3213, '3213', '2024-10-10', '32', '32', 'Vija', '2024-10-10', '2024-10-10', 'uploads/3FA95625-FD0F-4A16-8D50-6353ECF4C409.jpg'),
(101010, '010101', 1, '1', '2024-10-14', '1', '1', '1', '2024-10-14', '2024-10-14', 'uploads/0359D75D-6F66-4E0E-9514-D66551A76D51.jpg'),
(24242442424, '1', 1, '1', '2024-10-10', '1', '1', '1', '2024-10-10', '2024-10-10', 'uploads/BCA7243D-9E8B-4603-AEEC-D24428C91DBB.jpg'),
(25252525, '1', 1, '1', '2024-12-12', '1', '1', '1', '2024-12-12', '2024-12-12', 'uploads/E22BC6F7-8F85-48B5-BD72-C8879BD6C2D1.jpg'),
(7337207416, 'AME', 3123, '3123', '2024-10-10', '34', '34', 'bada', '2024-10-10', '2024-10-10', 'uploads/76881DEA-2045-48E6-9B10-1422A5E7B33A.jpg'),
(15081, 'Amari', 7337207416, 'Male', '2024-02-02', '30', '30', 'Am', '2024-02-02', '2024-02-02', 'uploads/E5A87BAD-325B-4770-BD3E-B70CE3AC1E53.jpg'),
(1920, 'Amelia', 31231, '3121312', '2024-02-02', '23', '20', '21312', '2024-02-02', '2024-02-02', 'uploads/57BBBAA7-D96F-4BA8-A21D-FA66A8D5EF0E.jpg'),
(6300, 'Ame', 413431, 'rear', '2024-02-02', '12', '312', '21312', '2024-02-02', '2024-02-02', 'uploads/61A8A664-3AE7-4688-A3D6-B57984761B91.jpg'),
(2003, 'bot', 1212, 'male', '2024-02-02', '12', '12', 'na', '2024-02-02', '2024-02-02', 'uploads/1F51DE2D-AC82-48A5-A2E2-8768F2C5EEFD.jpg'),
(2001, '231', 23, '213', '2024-02-02', '12', '21', '12', '2024-02-02', '2024-02-02', 'uploads/F5FCD26B-D45E-4251-850A-26978237D84F.jpg'),
(2024, 'amar', 231231231, 'male', '2024-02-02', '23', '23', 'dada das', '2024-02-02', '2024-02-02', 'uploads/49CC3B19-36C0-4017-B918-38E37E406776.jpg'),
(20251, 'ame', 231, 'male', '2024-02-02', '23', '23', 'dsad', '2024-02-02', '2024-02-02', 'uploads/741FE49E-9D66-4379-9DE3-C62D529D0572.jpg'),
(123456, 'Samjiii', 321312, '321312', '2024-02-02', '231', '321', '321321', '2024-02-02', '2024-02-02', 'uploads/CE9D7EF9-93C9-471B-88E4-7B0D0EF43BB1.jpg'),
(0, '12121', 2121, '21211', '2024-02-02', '1212`2', '121', '2121', '2024-02-02', '2024-02-02', 'uploads/471FEB29-8792-44BA-A156-EE0D3D673FE0.jpg'),
(11111, '2121', 2121, '1212', '2024-02-02', '231', '321', '321', '2024-02-02', '2024-02-02', 'uploads/FE57E566-BABE-4AD3-8304-0722DF270B19.jpg'),
(1221312, '12312', 21312, '21312', '2024-02-03', '12', '12', '12121', '2024-02-03', '2024-02-03', 'uploads/4208A88F-8E6F-40EB-B23D-BE4EB410A27C.jpg'),
(55555, 'Harsha', 9949641880, 'Male', '2003-02-02', '160', '70', 'Sekhar', '2024-02-02', '2024-02-05', 'uploads/8455535A-5181-42CF-9246-9469598B969A.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `questionnaire_doc`
--

CREATE TABLE `questionnaire_doc` (
  `id` bigint(20) NOT NULL,
  `Question_category` text NOT NULL,
  `Question` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `questionnaire_doc`
--

INSERT INTO `questionnaire_doc` (`id`, `Question_category`, `Question`) VALUES
(90909, 'danger', 'Abnormal Body Movements'),
(90909, 'general', 'Not Drinking'),
(90909, 'danger', 'Fast Breathing'),
(90909, 'general', 'Unconsciouness'),
(90909, 'danger', 'Fever with rash'),
(90909, 'general', 'Lethargy'),
(90909, 'danger', 'Fatigue'),
(90909, 'general', 'Convulsions'),
(90909, 'danger', 'Irritable'),
(90909, 'general', 'Vomits Everything'),
(90909, 'danger', 'Ear with discharge/pain'),
(1890, 'none', 'none'),
(0, '', ''),
(0, 'asadas', 'dsdadsa'),
(1891, 'asadas', 'dsdadsa'),
(18911, 'General Symptoms', '1'),
(18911, 'General Symptoms', '2'),
(18911, 'General Symptoms', '3'),
(18911, 'General Symptoms', '4'),
(18911, 'General Symptoms', '5'),
(18911, 'Danger Symptoms', '6'),
(18911, 'Danger Symptoms', '7'),
(18911, 'Danger Symptoms', '8'),
(18911, 'Danger Symptoms', '9'),
(18911, 'Danger Symptoms', '10'),
(18911, 'Danger Symptoms', '11'),
(18911, 'General Symptoms', '1'),
(18911, 'General Symptoms', '2'),
(18911, 'General Symptoms', '3'),
(18911, 'General Symptoms', '4'),
(18911, 'General Symptoms', '5'),
(18911, 'Danger Symptoms', '6'),
(18911, 'Danger Symptoms', '7'),
(18911, 'Danger Symptoms', '8'),
(18911, 'Danger Symptoms', '9'),
(18911, 'Danger Symptoms', '10'),
(18911, 'Danger Symptoms', '11'),
(18911, 'General Symptoms', 'dasd'),
(18911, 'General Symptoms', 'sdadsadsa'),
(18911, 'General Symptoms', 'das'),
(18911, 'General Symptoms', 'das'),
(18911, 'General Symptoms', 'sdada'),
(18911, 'Danger Symptoms', 'sada'),
(18911, 'Danger Symptoms', 'dsada'),
(18911, 'Danger Symptoms', 'sadas'),
(18911, 'Danger Symptoms', 'sadas'),
(18911, 'Danger Symptoms', 'dasd'),
(18911, 'Danger Symptoms', 'dsasd'),
(123456789, 'General Symptoms', '23123'),
(123456789, 'General Symptoms', '3213'),
(123456789, 'General Symptoms', '3213'),
(123456789, 'General Symptoms', '32131'),
(123456789, 'General Symptoms', '32131'),
(123456789, 'Danger Symptoms', '32131'),
(123456789, 'Danger Symptoms', '32131'),
(123456789, 'Danger Symptoms', '32131'),
(123456789, 'Danger Symptoms', '321321'),
(123456789, 'Danger Symptoms', '31231'),
(123456789, 'Danger Symptoms', '31231'),
(123456789, 'General Symptoms', '23123'),
(123456789, 'General Symptoms', '3213'),
(123456789, 'General Symptoms', '3213'),
(123456789, 'General Symptoms', '32131'),
(123456789, 'General Symptoms', '32131'),
(123456789, 'Danger Symptoms', '32131'),
(123456789, 'Danger Symptoms', '32131'),
(123456789, 'Danger Symptoms', '32131'),
(123456789, 'Danger Symptoms', '321321'),
(123456789, 'Danger Symptoms', '31231'),
(123456789, 'Danger Symptoms', '31231'),
(123456789, 'General Symptoms', ''),
(123456789, 'General Symptoms', ''),
(123456789, 'General Symptoms', ''),
(123456789, 'General Symptoms', ''),
(123456789, 'General Symptoms', ''),
(123456789, 'Danger Symptoms', ''),
(123456789, 'Danger Symptoms', ''),
(123456789, 'Danger Symptoms', ''),
(123456789, 'Danger Symptoms', ''),
(123456789, 'Danger Symptoms', ''),
(123456789, 'Danger Symptoms', ''),
(123456789, 'General Symptoms', ''),
(123456789, 'General Symptoms', ''),
(123456789, 'General Symptoms', ''),
(123456789, 'General Symptoms', ''),
(123456789, 'General Symptoms', ''),
(123456789, 'Danger Symptoms', ''),
(123456789, 'Danger Symptoms', ''),
(123456789, 'Danger Symptoms', ''),
(123456789, 'Danger Symptoms', ''),
(123456789, 'Danger Symptoms', ''),
(123456789, 'Danger Symptoms', ''),
(123456789, 'General Symptoms', ''),
(123456789, 'General Symptoms', ''),
(123456789, 'General Symptoms', ''),
(123456789, 'General Symptoms', ''),
(123456789, 'General Symptoms', ''),
(123456789, 'Danger Symptoms', ''),
(123456789, 'Danger Symptoms', ''),
(123456789, 'Danger Symptoms', ''),
(123456789, 'Danger Symptoms', ''),
(123456789, 'Danger Symptoms', ''),
(123456789, 'Danger Symptoms', ''),
(20251, 'General Symptoms', 'hi'),
(20251, 'General Symptoms', 'hi'),
(20251, 'General Symptoms', 'hi'),
(20251, 'General Symptoms', 'hiihihhi'),
(20251, 'General Symptoms', 'hihihi'),
(20251, 'Danger Symptoms', 'high'),
(20251, 'Danger Symptoms', 'ihihih'),
(20251, 'Danger Symptoms', 'hihihi'),
(20251, 'Danger Symptoms', 'hihihi'),
(20251, 'Danger Symptoms', 'hihih'),
(20251, 'Danger Symptoms', 'hihih'),
(12234, 'General Symptoms', ''),
(12234, 'General Symptoms', '1'),
(12234, 'General Symptoms', 'das'),
(12234, 'General Symptoms', 'das'),
(12234, 'General Symptoms', 'dasd'),
(12234, 'Danger Symptoms', 'ok'),
(12234, 'Danger Symptoms', 'okkk'),
(12234, 'Danger Symptoms', 'ok'),
(12234, 'Danger Symptoms', '1432'),
(12234, 'Danger Symptoms', 'hello'),
(12234, 'Danger Symptoms', 'hello'),
(123456, 'General Symptoms', 'nice '),
(123456, 'General Symptoms', 'sunbath '),
(123456, 'General Symptoms', 'dsa'),
(123456, 'General Symptoms', 'hello '),
(123456, 'General Symptoms', 'harsha'),
(123456, 'Danger Symptoms', 'pavan'),
(123456, 'Danger Symptoms', 'geetha'),
(123456, 'Danger Symptoms', 'cami'),
(123456, 'Danger Symptoms', 'line'),
(123456, 'Danger Symptoms', 'vikki'),
(123456, 'Danger Symptoms', 'vikki'),
(1221312, 'General Symptoms', '2321'),
(1221312, 'General Symptoms', '21'),
(1221312, 'General Symptoms', '23131'),
(1221312, 'General Symptoms', '2131'),
(1221312, 'General Symptoms', '213123'),
(1221312, 'Danger Symptoms', '12312'),
(1221312, 'Danger Symptoms', '321'),
(1221312, 'Danger Symptoms', '12321'),
(1221312, 'Danger Symptoms', '32131'),
(1221312, 'Danger Symptoms', '31322'),
(1221312, 'Danger Symptoms', '31322'),
(55555, 'General Symptoms', 'Not Drinking'),
(55555, 'General Symptoms', 'Unconsciousness'),
(55555, 'General Symptoms', 'Lethargy'),
(55555, 'General Symptoms', 'Convulsions'),
(55555, 'General Symptoms', 'Vomits Everything'),
(55555, 'Danger Symptoms', 'Abnormal Body Movements'),
(55555, 'Danger Symptoms', 'Fast Breathing'),
(55555, 'Danger Symptoms', 'Fever with rash'),
(55555, 'Danger Symptoms', 'Fatigue'),
(55555, 'Danger Symptoms', 'Ear with discharge/pain'),
(55555, 'Danger Symptoms', 'Ear with discharge/pain');

-- --------------------------------------------------------

--
-- Table structure for table `questionnaire_response`
--

CREATE TABLE `questionnaire_response` (
  `id` text NOT NULL,
  `date` date NOT NULL,
  `symptom` text NOT NULL,
  `response` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `questionnaire_response`
--

INSERT INTO `questionnaire_response` (`id`, `date`, `symptom`, `response`) VALUES
('12234', '2023-11-29', 'Not Drinking', 'Yes'),
('12234', '2023-11-29', 'Unconsciouness', 'No'),
('12234', '2023-11-29', 'Lethargy', 'No'),
('12234', '2023-11-29', 'Convulsions', 'No'),
('12234', '2023-11-29', 'Vomits Everything', 'No'),
('12234', '2023-11-29', 'Abnormal Body Movements', 'Yes'),
('12234', '2023-11-29', 'Fast Breathing', 'No'),
('12234', '2023-11-29', 'Fever with rash', 'Yes'),
('12234', '2023-11-29', 'Fatigue', 'No'),
('12234', '2023-11-29', 'Irritable', 'No'),
('12234', '2023-11-29', 'Ear with discharge/pain', 'No'),
('12234', '2024-01-29', '', ''),
('12234', '2024-01-29', '', ''),
('12234', '2024-01-29', '', ''),
('12234', '2024-01-29', '', ''),
('12234', '2024-01-29', '', ''),
('12234', '2024-01-29', '', ''),
('12234', '2024-01-29', '', ''),
('12234', '2024-01-29', '', ''),
('12234', '2024-01-29', '', ''),
('12234', '2024-01-29', '', ''),
('12234', '2024-01-29', '', ''),
('12234', '2024-10-10', '2', ''),
('12234', '2024-10-10', '3', ''),
('12234', '2024-10-10', '4', ''),
('12234', '2024-10-10', '1', ''),
('12234', '2024-10-10', '', ''),
('12234', '2024-10-10', '', ''),
('12234', '2024-10-10', '', ''),
('12234', '2024-10-10', '', ''),
('12234', '2024-10-10', '', ''),
('12234', '2024-10-10', '', ''),
('12234', '2024-10-10', '', ''),
('12234', '2024-02-14', 'Not Drinking', 'Yes'),
('12234', '2024-02-14', 'Unconsciouness', 'Yes'),
('12234', '2024-02-14', 'Lethargy', 'Yes'),
('12234', '2024-02-14', 'Convulsions', 'Yes'),
('12234', '2024-02-14', 'Vomits Everything', 'Yes'),
('12234', '2024-02-14', 'Abnormal Body Movements', 'Yes'),
('12234', '2024-02-14', 'Fast Breathing', 'Yes'),
('12234', '2024-02-14', 'Fever with rash', 'Yes'),
('12234', '2024-02-14', 'Fatigue', 'Yes'),
('12234', '2024-02-14', 'Irritable', 'Yes'),
('12234', '2024-02-14', 'Ear with discharge/pain', 'Yes'),
('12234', '2024-02-18', 'Abnormal Body Moments his i', 'Yes'),
('12234', '2024-02-18', 'Abnormal Body Moments his i', 'No'),
('12234', '2024-02-18', 'Abnormal Body Moments his i', 'Yes'),
('12234', '2024-02-18', 'Abnormal Body Moments his i', 'Yes'),
('12234', '2024-02-18', 'Abnormal Body Moments his i', 'Yes'),
('12234', '2024-02-18', 'Abnormal Body Moments his i', 'Yes'),
('12234', '2024-02-18', 'Abnormal Body Moments his i', 'Yes'),
('12234', '2024-02-18', 'Abnormal Body Moments his i', ''),
('12234', '2024-02-18', 'Abnormal Body Moments his i', ''),
('12234', '2024-02-18', 'Abnormal Body Moments his i', ''),
('12234', '2024-02-18', 'Abnormal Body Moments his i', ''),
('12234', '2024-02-20', 'Abnormal Body Moments his i', ''),
('12234', '2024-02-20', 'Abnormal Body Moments his i', ''),
('12234', '2024-02-20', 'Abnormal Body Moments his i', ''),
('12234', '2024-02-20', 'Abnormal Body Moments his i', ''),
('12234', '2024-02-20', 'Abnormal Body Moments his i', ''),
('12234', '2024-02-20', 'Abnormal Body Moments his i', ''),
('12234', '2024-02-20', 'Abnormal Body Moments his i', ''),
('12234', '2024-02-20', 'Abnormal Body Moments his i', ''),
('12234', '2024-02-20', 'Abnormal Body Moments his i', ''),
('12234', '2024-02-20', 'Abnormal Body Moments his i', ''),
('12234', '2024-02-20', 'Abnormal Body Moments his i', ''),
('12234', '2024-02-20', 'Abnormal Body Moments his i', ''),
('12234', '2024-02-20', 'Abnormal Body Moments his i', ''),
('12234', '2024-02-20', 'Abnormal Body Moments his i', ''),
('12234', '2024-02-20', 'Abnormal Body Moments his i', ''),
('12234', '2024-02-20', 'Abnormal Body Moments his i', ''),
('12234', '2024-02-20', 'Abnormal Body Moments his i', ''),
('12234', '2024-02-20', 'Abnormal Body Moments his i', ''),
('12234', '2024-02-20', 'Abnormal Body Moments his i', ''),
('12234', '2024-02-20', 'Abnormal Body Moments his i', ''),
('12234', '2024-02-20', 'Abnormal Body Moments his i', ''),
('12234', '2024-02-20', 'Abnormal Body Moments his i', ''),
('12234', '2024-02-20', 'Abnormal Body Moments his i', ''),
('12234', '2024-02-20', 'Abnormal Body Moments his i', ''),
('12234', '2024-02-20', 'Abnormal Body Moments his i', ''),
('12234', '2024-02-20', 'Abnormal Body Moments his i', ''),
('12234', '2024-02-20', 'Abnormal Body Moments his i', ''),
('12234', '2024-02-20', 'Abnormal Body Moments his i', ''),
('12234', '2024-02-20', 'Abnormal Body Moments his i', ''),
('12234', '2024-02-20', 'Abnormal Body Moments his i', ''),
('12234', '2024-02-20', 'Abnormal Body Moments his i', ''),
('12234', '2024-02-20', 'Abnormal Body Moments his i', ''),
('12234', '2024-02-20', 'Abnormal Body Moments his i', ''),
('12234', '2024-02-29', '', 'Yes'),
('12234', '2024-02-29', '1', 'Yes'),
('12234', '2024-02-29', 'das', 'Yes'),
('12234', '2024-02-29', 'das', 'Yes'),
('12234', '2024-02-29', 'dasd', 'Yes'),
('12234', '2024-02-29', 'ok', 'No'),
('12234', '2024-02-29', 'okkk', 'No'),
('12234', '2024-02-29', 'ok', 'No'),
('12234', '2024-02-29', '1432', 'No'),
('12234', '2024-02-29', 'hello', 'No'),
('12234', '2024-02-29', 'hello', 'No'),
('12234', '2024-03-08', '', 'Yes'),
('12234', '2024-03-08', '1', 'Yes'),
('12234', '2024-03-08', 'das', 'Yes'),
('12234', '2024-03-08', 'das', 'Yes'),
('12234', '2024-03-08', 'dasd', 'Yes'),
('12234', '2024-03-08', 'ok', 'No'),
('12234', '2024-03-08', 'okkk', 'No'),
('12234', '2024-03-08', 'ok', 'No'),
('12234', '2024-03-08', '1432', 'No'),
('12234', '2024-03-08', 'hello', 'No'),
('12234', '2024-03-08', 'hello', ''),
('12234', '2024-02-29', '', 'No'),
('12234', '2024-02-29', '1', 'No'),
('12234', '2024-02-29', 'das', 'No'),
('12234', '2024-02-29', 'das', 'No'),
('12234', '2024-02-29', 'dasd', 'No'),
('12234', '2024-02-29', 'ok', 'Yes'),
('12234', '2024-02-29', 'okkk', 'Yes'),
('12234', '2024-02-29', 'ok', 'Yes'),
('12234', '2024-02-29', '1432', 'Yes'),
('12234', '2024-02-29', 'hello', 'Yes'),
('12234', '2024-02-29', 'hello', ''),
('12234', '2024-02-29', '', 'Yes'),
('12234', '2024-02-29', '1', 'Yes'),
('12234', '2024-02-29', 'das', 'No'),
('12234', '2024-02-29', 'das', 'Yes'),
('12234', '2024-02-29', 'dasd', 'No'),
('12234', '2024-02-29', 'ok', 'Yes'),
('12234', '2024-02-29', 'okkk', 'Yes'),
('12234', '2024-02-29', 'ok', 'No'),
('12234', '2024-02-29', '1432', 'No'),
('12234', '2024-02-29', 'hello', 'Yes'),
('12234', '2024-02-29', 'hello', 'Yes'),
('12234', '2024-02-29', '', 'Yes'),
('12234', '2024-02-29', '1', ''),
('12234', '2024-02-29', 'das', ''),
('12234', '2024-02-29', 'das', ''),
('12234', '2024-02-29', 'dasd', ''),
('12234', '2024-02-29', 'ok', ''),
('12234', '2024-02-29', 'okkk', ''),
('12234', '2024-02-29', 'ok', ''),
('12234', '2024-02-29', '1432', ''),
('12234', '2024-02-29', 'hello', ''),
('12234', '2024-02-29', 'hello', ''),
('55555', '2024-04-09', 'Not Drinking', 'Yes'),
('55555', '2024-04-09', 'Unconsciousness', 'Yes'),
('55555', '2024-04-09', 'Lethargy', 'No'),
('55555', '2024-04-09', 'Convulsions', 'Yes'),
('55555', '2024-04-09', 'Vomits Everything', 'No'),
('55555', '2024-04-09', 'Abnormal Body Movements', 'Yes'),
('55555', '2024-04-09', 'Fast Breathing', 'No'),
('55555', '2024-04-09', 'Fever with rash', 'Yes'),
('55555', '2024-04-09', 'Fatigue', 'Yes'),
('55555', '2024-04-09', 'Ear with discharge/pain', 'No'),
('55555', '2024-04-09', 'Ear with discharge/pain', 'No'),
('12234', '2024-05-15', '', 'Yes'),
('12234', '2024-05-15', '1', 'Yes'),
('12234', '2024-05-15', 'das', 'Yes'),
('12234', '2024-05-15', 'das', 'Yes'),
('12234', '2024-05-15', 'dasd', 'Yes'),
('12234', '2024-05-15', 'ok', 'Yes'),
('12234', '2024-05-15', 'okkk', 'Yes'),
('12234', '2024-05-15', 'ok', 'Yes'),
('12234', '2024-05-15', '1432', 'Yes'),
('12234', '2024-05-15', 'hello', 'Yes'),
('12234', '2024-05-15', 'hello', 'Yes'),
('55555', '2024-05-08', 'Not Drinking', 'Yes'),
('55555', '2024-05-08', 'Unconsciousness', 'Yes'),
('55555', '2024-05-08', 'Lethargy', 'Yes'),
('55555', '2024-05-08', 'Convulsions', 'Yes'),
('55555', '2024-05-08', 'Vomits Everything', 'Yes'),
('55555', '2024-05-08', 'Abnormal Body Movements', 'No'),
('55555', '2024-05-08', 'Fast Breathing', 'No'),
('55555', '2024-05-08', 'Fever with rash', 'No'),
('55555', '2024-05-08', 'Fatigue', 'No'),
('55555', '2024-05-08', 'Ear with discharge/pain', 'No'),
('55555', '2024-05-08', 'Ear with discharge/pain', 'No');

-- --------------------------------------------------------

--
-- Table structure for table `report_time`
--

CREATE TABLE `report_time` (
  `id` text NOT NULL,
  `report_time` text NOT NULL,
  `date` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `report_time`
--

INSERT INTO `report_time` (`id`, `report_time`, `date`) VALUES
('12234', '1', '2023-11-10'),
('12234', '2', '2023-11-12'),
('733720', '1', '2023-11-10'),
('90909', '1', '2023-12-12'),
('18911', 'dasd', '2023-10-10'),
('18911', 'dasd', '2023-10-10'),
('123456789', '9:30 Am', '30-01-2024'),
('12234', '', ''),
('123456789', '', '09-02-2024'),
('123456789', '', '09-02-2024'),
('123456789', '', '10-02-2024'),
('123456789', '', '15-02-2024'),
('123456789', '', '17-02-2024'),
('20251', '9:30', '18-02-2024'),
('123456', '9:30', '28-02-2024'),
('123456789', '9:20', '29-02-2024'),
('55555', '', '10-04-2024'),
('123456789', '10 Am', '17-04-2024'),
('123456789', '11 Am', '24-04-2024');

-- --------------------------------------------------------

--
-- Table structure for table `sample`
--

CREATE TABLE `sample` (
  `id` text NOT NULL,
  `name` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sample`
--

INSERT INTO `sample` (`id`, `name`) VALUES
('191', 'king');

-- --------------------------------------------------------

--
-- Table structure for table `treatment`
--

CREATE TABLE `treatment` (
  `id` text NOT NULL,
  `Head_to_toe_examination` text NOT NULL,
  `General_Examination` text NOT NULL,
  `Systematic_Examination` text NOT NULL,
  `Treatment_given` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `treatment`
--

INSERT INTO `treatment` (`id`, `Head_to_toe_examination`, `General_Examination`, `Systematic_Examination`, `Treatment_given`) VALUES
('949194', 'amar chanbdra hiv patients , doctor told they shouldnt have hopes on their lives', 'amar chanbdra hiv patients , doctor told they shouldnt have hopes on their lives', 'amar chanbdra hiv patients , doctor told they shouldnt have hopes on their lives', 'amar chanbdra hiv patients , doctor told they shouldnt have hopes on their lives'),
('123', '1', '1', '1', '1'),
('205', 'fe', '1212', '121', 'ds'),
('12', '1', '1', '1', '1'),
('20251', '12', '21', '12', '12'),
('143', '1', '1', '1', '1'),
('143', '1', '1', '1', '1'),
('123456', 'wq', 'w', 'qwq', 'w'),
('1234', '1', '1', '1', '1'),
('1234', '1', '1', '1', '1'),
('1234', '1', '1', '1', '1'),
('1234', '1', '1', '1', '1'),
('733720', '1', '1', '1', '1'),
('1432', '1', '1', '1', '1'),
('1432', '1', '1', '1', '1'),
('1432', '1', '1', '1', '1'),
('010101', '1', '1', '1', '1'),
('010101', '1', '1', '1', '1'),
('010101', '1', '1', '1', '1'),
('12234', '   he is diagnosed with the serious disordet thathe is diagnosed with the serious disordet that', '   he is diagnosed with the serious disordet thathe is diagnosed with the serious disordet that', '   he is diagnosed with the serious disordet thathe is diagnosed with the serious disordet that', '   he is diagnosed with the serious disordet thathe is diagnosed with the serious disordet that'),
('55555', 'Yes Having ', 'Done ', 'Yet to dooo', 'Yes');

-- --------------------------------------------------------

--
-- Table structure for table `vitals_at_admission`
--

CREATE TABLE `vitals_at_admission` (
  `id` text NOT NULL,
  `Heart_rate` text NOT NULL,
  `Temperature` text NOT NULL,
  `CRT` text NOT NULL,
  `RR` text NOT NULL,
  `SPO2` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `vitals_at_admission`
--

INSERT INTO `vitals_at_admission` (`id`, `Heart_rate`, `Temperature`, `CRT`, `RR`, `SPO2`) VALUES
('949194', 'lm', 'ok', 'lok', 'oko', 'ok'),
('123', '1', '1', '1', '1', '1'),
('205', '1212', '1212', 'dw', '12', '12'),
('12', '1', '1', '1', '1', '1'),
('20251', '12', '12', '12', '121', '12'),
('143', '1', '1', '1', '1', '1'),
('143', '1', '1', '1', '1', '1'),
('123456', 'wqwqw', 'wqwq', 'wqw', 'we', 'qw'),
('1234', '1', '1', '1', '1', '1'),
('1234', '1', '1', '1', '1', '1'),
('1234', '1', '1', '1', '1', '1'),
('1234', '1', '1', '1', '1', '1'),
('733720', '1', '1', '1', '1', '1'),
('1432', '1', '1', '1', '1', '1'),
('1432', '1', '1', '1', '1', '1'),
('1432', '1', '1', '1', '1', '1'),
('010101', '1', '1', '1', '1', '1'),
('010101', '1', '1', '1', '1', '1'),
('010101', '1', '1', '1', '1', '1'),
('12234', '   23', '   23', '   23', '   23', '   23'),
('55555', '70', '30', '20', '11', '21');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
